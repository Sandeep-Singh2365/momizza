(function ($) {
  'use strict';

  const cfg = window.MomizzaConfig || {};
  const q = (s, c = document) => c.querySelector(s);
  const qa = (s, c = document) => Array.from(c.querySelectorAll(s));

  function initMobileNav() {
    const button = q('.momizza-menu-toggle');
    const nav = q('#momizza-mobile-nav');
    if (!button || !nav) return;
    button.addEventListener('click', () => {
      const open = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!open));
      nav.hidden = open;
    });
    qa('a', nav).forEach((link) => link.addEventListener('click', () => {
      button.setAttribute('aria-expanded', 'false');
      nav.hidden = true;
    }));
  }

  function initCategoryScroll() {
    qa('.momizza-category-nav a').forEach((link) => {
      link.addEventListener('click', (event) => {
        const id = link.getAttribute('href');
        if (!id || id.charAt(0) !== '#') return;
        const target = q(id);
        if (!target) return;
        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        history.replaceState(null, '', id);
      });
    });
  }

  function setCartOpen(open) {
    const overlay = q('[data-cart-overlay]');
    if (!overlay) return;
    overlay.hidden = !open;
    document.body.classList.toggle('momizza-cart-open', open);
    if (open) {
      const close = q('.momizza-cart-close', overlay);
      if (close) setTimeout(() => close.focus(), 20);
    }
  }

  function initCartDrawer() {
    document.addEventListener('click', (event) => {
      const trigger = event.target.closest('.momizza-cart-trigger');
      if (trigger) {
        event.preventDefault();
        setCartOpen(true);
        return;
      }
      const close = event.target.closest('.momizza-cart-close');
      if (close) {
        event.preventDefault();
        setCartOpen(false);
        return;
      }
      const overlay = event.target.matches('[data-cart-overlay]') ? event.target : null;
      if (overlay) setCartOpen(false);
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') setCartOpen(false);
    });
  }

  function applyCartState(state) {
    if (!state) return;
    qa('.momizza-cart-count').forEach((el) => { el.textContent = String(state.count || 0); });
    qa('.momizza-cart-total').forEach((el) => { el.innerHTML = state.total || ''; });
    const floating = q('.momizza-floating-cart');
    if (floating) floating.classList.toggle('is-empty', !state.count);
    const mini = q('[data-mini-cart]');
    if (mini && typeof state.miniCart === 'string') mini.innerHTML = state.miniCart;
  }

  async function postAjax(action, data) {
    const body = new URLSearchParams({ action, nonce: cfg.nonce || '', ...data });
    const response = await fetch(cfg.ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    });
    const json = await response.json();
    if (!json || !json.success) {
      const msg = json && json.data && json.data.message ? json.data.message : (cfg.errorText || 'Something went wrong.');
      throw new Error(msg);
    }
    return json.data;
  }

  function initMenuAddToCart() {
    if (!cfg.wooActive) return;
    document.addEventListener('click', async (event) => {
      const button = event.target.closest('.momizza-add-btn[data-product-id]');
      if (!button) return;
      event.preventDefault();
      if (button.classList.contains('is-busy')) return;
      const original = button.innerHTML;
      button.classList.add('is-busy');
      button.textContent = cfg.addingText || 'Adding…';
      try {
        const state = await postAjax('momizza_add_to_cart', {
          product_id: button.dataset.productId || '',
          variation_id: button.dataset.variationId || '',
          variation: button.dataset.variation || ''
        });
        applyCartState(state);
        button.classList.add('is-added');
        button.textContent = cfg.addedText || 'Added ✓';
        setTimeout(() => {
          button.innerHTML = original;
          button.classList.remove('is-added');
        }, 1100);
      } catch (error) {
        button.innerHTML = original;
        window.alert(error.message || cfg.errorText || 'Could not add this item.');
      } finally {
        button.classList.remove('is-busy');
      }
    });
  }

  async function refreshCartState() {
    if (!cfg.wooActive) return;
    try {
      const state = await postAjax('momizza_cart_state', {});
      applyCartState(state);
    } catch (e) {
      // WooCommerce's native fragments can still update the UI.
    }
  }

  function hookWooEvents() {
    if (!$ || !cfg.wooActive) return;
    $(document.body).on('added_to_cart removed_from_cart wc_fragments_refreshed updated_wc_div', function () {
      refreshCartState();
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initMobileNav();
    initCategoryScroll();
    initCartDrawer();
    initMenuAddToCart();
    hookWooEvents();
  });
})(window.jQuery);
