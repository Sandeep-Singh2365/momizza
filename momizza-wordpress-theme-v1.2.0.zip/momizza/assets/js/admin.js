(function($){
  function updatePriceUI(){
    var type = $('input[name="product_type"]:checked').val();
    $('.momizza-price-simple').toggle(type !== 'variable');
    $('.momizza-price-variable').toggle(type === 'variable');
  }
  $(document).on('change','input[name="product_type"]',updatePriceUI);
  updatePriceUI();

  $('#momizza-add-variation').on('click',function(){
    var tpl=document.getElementById('momizza-variation-template');
    if(tpl){ $('#momizza-variation-rows').append(tpl.content.cloneNode(true)); }
  });
  $(document).on('click','.momizza-remove-variation',function(){
    if(window.confirm(MomizzaAdmin.confirmDeleteVariation)){ $(this).closest('.momizza-variation-row').remove(); }
  });
  $(document).on('click','.momizza-confirm-product-delete',function(e){
    if(!window.confirm(MomizzaAdmin.confirmDeleteProduct)){ e.preventDefault(); }
  });
  $(document).on('click','.momizza-confirm-category-delete',function(e){
    if(!window.confirm(MomizzaAdmin.confirmDeleteCategory)){ e.preventDefault(); }
  });

  $(document).on('click','.momizza-print-order',function(){ window.print(); });

  $(document).on('click','.momizza-media-picker__button',function(e){
    e.preventDefault();
    var $picker=$(this).closest('.momizza-media-picker');
    var mediaType=$picker.data('media-type') || 'image';
    var library = mediaType === 'application/pdf' ? {type:'application/pdf'} : {type:'image'};
    var frame=wp.media({title:mediaType==='image'?MomizzaAdmin.chooseImage:MomizzaAdmin.chooseFile,button:{text:MomizzaAdmin.useFile},multiple:false,library:library});
    frame.on('select',function(){
      var file=frame.state().get('selection').first().toJSON();
      var $input=$picker.find('input[type="hidden"]');
      if($input.attr('name') === 'image_id' || $input.attr('name') === 'thumbnail_id'){$input.val(file.id);}else{$input.val(file.url);}
      var html = mediaType === 'image' ? '<img src="'+file.url+'" alt="">' : '<span class="dashicons dashicons-media-document"></span><small>'+file.filename+'</small>';
      $picker.find('.momizza-media-picker__preview').html(html);
    });
    frame.open();
  });
  $(document).on('click','.momizza-media-picker__remove',function(e){
    e.preventDefault();
    var $picker=$(this).closest('.momizza-media-picker');
    $picker.find('input[type="hidden"]').val('');
    $picker.find('.momizza-media-picker__preview').html('<span class="dashicons dashicons-format-image"></span><small>No file selected</small>');
  });

  function syncHoursRow(input){
    var disabled=!input.checked;
    $(input).closest('.momizza-hours-row').find('input[type="time"]').prop('disabled',disabled).css('opacity',disabled?.45:1);
  }
  $(document).on('change','.momizza-hours-row .momizza-toggle input',function(){ syncHoursRow(this); });
  $('.momizza-hours-row .momizza-toggle input').each(function(){ syncHoursRow(this); });
})(jQuery);
