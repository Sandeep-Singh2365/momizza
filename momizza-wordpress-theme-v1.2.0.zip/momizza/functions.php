<?php
/**
 * Momizza theme bootstrap.
 *
 * @package Momizza
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MOMIZZA_VERSION', '1.2.0' );
define( 'MOMIZZA_DIR', get_template_directory() );
define( 'MOMIZZA_URI', get_template_directory_uri() );

require_once MOMIZZA_DIR . '/inc/helpers.php';
require_once MOMIZZA_DIR . '/inc/setup.php';
require_once MOMIZZA_DIR . '/inc/customizer.php';
require_once MOMIZZA_DIR . '/inc/acf-fields.php';
require_once MOMIZZA_DIR . '/inc/woocommerce.php';
require_once MOMIZZA_DIR . '/inc/admin.php';
