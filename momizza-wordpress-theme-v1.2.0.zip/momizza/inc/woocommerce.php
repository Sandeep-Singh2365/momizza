<?php
/** WooCommerce integration: cart drawer, menu AJAX, wrappers and placeholders. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function momizza_woocommerce_placeholder( $src ) {
    return MOMIZZA_URI . '/assets/images/product-placeholder.jpg';
}
add_filter( 'woocommerce_placeholder_img_src', 'momizza_woocommerce_placeholder' );

function momizza_cart_state_data() {
    if ( class_exists( 'WooCommerce' ) && null === WC()->cart && function_exists( 'wc_load_cart' ) ) { wc_load_cart(); }
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
        return array( 'count' => 0, 'total' => '', 'miniCart' => '' );
    }
    ob_start();
    woocommerce_mini_cart();
    $mini = ob_get_clean();
    return array(
        'count'    => WC()->cart->get_cart_contents_count(),
        'total'    => WC()->cart->get_cart_total(),
        'miniCart' => $mini,
    );
}

function momizza_ajax_cart_state() {
    check_ajax_referer( 'momizza_cart', 'nonce' );
    wp_send_json_success( momizza_cart_state_data() );
}
add_action( 'wp_ajax_momizza_cart_state', 'momizza_ajax_cart_state' );
add_action( 'wp_ajax_nopriv_momizza_cart_state', 'momizza_ajax_cart_state' );

function momizza_ajax_add_to_cart() {
    check_ajax_referer( 'momizza_cart', 'nonce' );
    if ( class_exists( 'WooCommerce' ) && null === WC()->cart && function_exists( 'wc_load_cart' ) ) { wc_load_cart(); }
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
        wp_send_json_error( array( 'message' => 'WooCommerce is not available.' ), 400 );
    }

    $product_id   = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
    $variation_id = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;
    $variation    = array();

    if ( ! empty( $_POST['variation'] ) ) {
        $decoded = json_decode( wp_unslash( $_POST['variation'] ), true );
        if ( is_array( $decoded ) ) {
            foreach ( $decoded as $key => $value ) {
                $variation[ sanitize_key( $key ) ] = sanitize_text_field( $value );
            }
        }
    }

    $product = wc_get_product( $product_id );
    if ( ! $product || ! $product->is_purchasable() ) {
        wp_send_json_error( array( 'message' => 'This item is not purchasable.' ), 400 );
    }

    if ( $product->is_type( 'variable' ) && ! $variation_id ) {
        wp_send_json_error( array( 'message' => 'Please choose an option.' ), 400 );
    }

    $key = WC()->cart->add_to_cart( $product_id, 1, $variation_id, $variation );
    if ( ! $key ) {
        wp_send_json_error( array( 'message' => 'Could not add this item.' ), 400 );
    }

    WC()->cart->calculate_totals();
    wp_send_json_success( momizza_cart_state_data() );
}
add_action( 'wp_ajax_momizza_add_to_cart', 'momizza_ajax_add_to_cart' );
add_action( 'wp_ajax_nopriv_momizza_add_to_cart', 'momizza_ajax_add_to_cart' );

function momizza_cart_fragments( $fragments ) {
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
        return $fragments;
    }
    $count = WC()->cart->get_cart_contents_count();
    $fragments['span.momizza-cart-count'] = '<span class="momizza-cart-count">' . esc_html( $count ) . '</span>';
    $fragments['span.momizza-cart-total'] = '<span class="momizza-cart-total">' . wp_kses_post( WC()->cart->get_cart_total() ) . '</span>';
    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'momizza_cart_fragments' );

function momizza_woocommerce_wrapper_start() {
    echo '<main class="momizza-main"><div class="momizza-container momizza-woo-container">';
}
function momizza_woocommerce_wrapper_end() {
    echo '</div></main>';
}
function momizza_change_woo_wrappers() {
    if ( ! class_exists( 'WooCommerce' ) ) { return; }
    remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
    remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
    add_action( 'woocommerce_before_main_content', 'momizza_woocommerce_wrapper_start', 10 );
    add_action( 'woocommerce_after_main_content', 'momizza_woocommerce_wrapper_end', 10 );
}
add_action( 'wp', 'momizza_change_woo_wrappers' );

function momizza_remove_woo_sidebar() {
    remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
}
add_action( 'wp', 'momizza_remove_woo_sidebar' );

function momizza_loop_thumbnail_fallback() {
    global $product;
    if ( ! $product ) { return; }
    if ( $product->get_image_id() ) {
        echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail' ) );
        return;
    }
    $terms = get_the_terms( $product->get_id(), 'product_cat' );
    $slug  = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->slug : 'product';
    printf( '<img src="%1$s" alt="%2$s" loading="lazy" width="600" height="450">', esc_url( momizza_category_image_url( $slug ) ), esc_attr( $product->get_name() ) );
}
function momizza_replace_loop_thumbnail() {
    if ( ! class_exists( 'WooCommerce' ) ) { return; }
    remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
    add_action( 'woocommerce_before_shop_loop_item_title', 'momizza_loop_thumbnail_fallback', 10 );
}
add_action( 'wp', 'momizza_replace_loop_thumbnail' );


/** Restaurant ordering controls managed from Momizza → Ordering. */
function momizza_enabled_order_modes() {
    $modes = array();
    if ( 'no' !== momizza_opt( 'enable_takeaway', 'yes' ) ) { $modes['takeaway'] = __( 'Takeaway', 'momizza' ); }
    if ( 'no' !== momizza_opt( 'enable_dine_in', 'yes' ) ) { $modes['dine-in'] = __( 'Dine-in', 'momizza' ); }
    if ( 'no' !== momizza_opt( 'enable_delivery', 'yes' ) ) { $modes['delivery'] = __( 'Delivery', 'momizza' ); }
    if ( ! $modes ) { $modes['takeaway'] = __( 'Takeaway', 'momizza' ); }
    return $modes;
}

function momizza_restaurant_is_open_now() {
    $day   = strtolower( wp_date( 'l' ) );
    $hours = trim( (string) momizza_opt( 'hours_' . $day, 'Closed' ) );
    if ( ! $hours || false !== stripos( $hours, 'closed' ) ) { return false; }
    $parts = preg_split( '/\s+-\s+/', $hours );
    if ( 2 !== count( $parts ) ) { return true; }
    try {
        $tz    = wp_timezone();
        $date  = wp_date( 'Y-m-d' );
        $opens = new DateTimeImmutable( $date . ' ' . trim( $parts[0] ), $tz );
        $closes = new DateTimeImmutable( $date . ' ' . trim( $parts[1] ), $tz );
        if ( $closes <= $opens ) { $closes = $closes->modify( '+1 day' ); }
        $now = current_datetime();
        return $now >= $opens && $now <= $closes;
    } catch ( Exception $e ) {
        return true;
    }
}

function momizza_online_ordering_available() {
    if ( 'no' === momizza_opt( 'accept_online_orders', 'yes' ) ) { return false; }
    if ( 'yes' === momizza_opt( 'enforce_open_hours', 'no' ) && ! momizza_restaurant_is_open_now() ) { return false; }
    return true;
}

/** When the kitchen pauses online ordering, keep the menu browseable but stop new cart purchases. */
function momizza_pause_purchasing( $purchasable, $product ) {
    if ( is_admin() && ! wp_doing_ajax() ) { return $purchasable; }
    return momizza_online_ordering_available() ? $purchasable : false;
}
add_filter( 'woocommerce_is_purchasable', 'momizza_pause_purchasing', 20, 2 );
add_filter( 'woocommerce_variation_is_purchasable', 'momizza_pause_purchasing', 20, 2 );

function momizza_validate_ordering_rules() {
    if ( ! momizza_online_ordering_available() ) {
        $message = ( 'yes' === momizza_opt( 'enforce_open_hours', 'no' ) && 'no' !== momizza_opt( 'accept_online_orders', 'yes' ) )
            ? __( 'Online ordering is closed outside restaurant opening hours. Please call the restaurant if you need help.', 'momizza' )
            : __( 'Online ordering is temporarily paused. Please call the restaurant to order.', 'momizza' );
        wc_add_notice( $message, 'error' );
        return;
    }
    $minimum = (float) momizza_opt( 'minimum_order', '0' );
    if ( $minimum > 0 && WC()->cart && (float) WC()->cart->get_subtotal() < $minimum ) {
        wc_add_notice( sprintf( __( 'The minimum online order is %s.', 'momizza' ), wp_strip_all_tags( wc_price( $minimum ) ) ), 'error' );
    }
}
add_action( 'woocommerce_check_cart_items', 'momizza_validate_ordering_rules' );

/** Preserve the original order-mode choice on both modern Checkout Blocks and classic checkout. */
function momizza_register_checkout_block_fields() {
    if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
        return;
    }
    woocommerce_register_additional_checkout_field(
        array(
            'id'          => 'momizza/order-mode',
            'label'       => __( 'Order mode', 'momizza' ),
            'placeholder' => __( 'Choose dine-in, takeaway or delivery', 'momizza' ),
            'location'    => 'order',
            'type'        => 'select',
            'required'    => true,
            'options'     => array_map(
                static function( $value, $label ) { return array( 'value' => $value, 'label' => $label ); },
                array_keys( momizza_enabled_order_modes() ),
                array_values( momizza_enabled_order_modes() )
            ),
        )
    );
}
add_action( 'woocommerce_init', 'momizza_register_checkout_block_fields' );

function momizza_classic_checkout_mode_field( $checkout ) {
    if ( function_exists( 'woocommerce_register_additional_checkout_field' ) && function_exists( 'has_block' ) && has_block( 'woocommerce/checkout', get_queried_object_id() ) ) {
        return;
    }
    echo '<div class="momizza-checkout-mode"><h3>' . esc_html__( 'How should we prepare your order?', 'momizza' ) . '</h3>';
    woocommerce_form_field(
        'momizza_order_mode',
        array(
            'type'     => 'select',
            'class'    => array( 'form-row-wide' ),
            'label'    => __( 'Order mode', 'momizza' ),
            'required' => true,
            'options'  => array( '' => __( 'Choose an option', 'momizza' ) ) + momizza_enabled_order_modes(),
        ),
        $checkout->get_value( 'momizza_order_mode' )
    );
    echo '</div>';
}
add_action( 'woocommerce_after_order_notes', 'momizza_classic_checkout_mode_field' );

function momizza_validate_classic_checkout_mode() {
    $mode = isset( $_POST['momizza_order_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['momizza_order_mode'] ) ) : '';
    if ( ! $mode || ! isset( momizza_enabled_order_modes()[ $mode ] ) ) {
        wc_add_notice( __( 'Please choose an available order mode.', 'momizza' ), 'error' );
    }
}
add_action( 'woocommerce_checkout_process', 'momizza_validate_classic_checkout_mode' );

function momizza_save_classic_checkout_mode( $order, $data ) {
    if ( ! empty( $_POST['momizza_order_mode'] ) ) {
        $order->update_meta_data( '_momizza_order_mode', sanitize_text_field( wp_unslash( $_POST['momizza_order_mode'] ) ) );
    }
}
add_action( 'woocommerce_checkout_create_order', 'momizza_save_classic_checkout_mode', 10, 2 );

function momizza_admin_order_mode( $order ) {
    $mode = $order->get_meta( '_momizza_order_mode' );
    if ( ! $mode ) { $mode = $order->get_meta( '_wc_other/momizza/order-mode' ); }
    if ( ! $mode ) { $mode = $order->get_meta( 'momizza/order-mode' ); }
    if ( $mode ) {
        echo '<p><strong>' . esc_html__( 'Momizza order mode:', 'momizza' ) . '</strong> ' . esc_html( ucwords( str_replace( '-', ' ', $mode ) ) ) . '</p>';
    }
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'momizza_admin_order_mode' );
