<?php
/** ACF / ACF Pro integration. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function momizza_acf_register() {
    if ( function_exists( 'acf_add_options_page' ) ) {
        acf_add_options_page(
            array(
                'page_title' => 'Momizza Settings',
                'menu_title' => 'Momizza Settings',
                'menu_slug'  => 'momizza-settings',
                'capability' => 'edit_theme_options',
                'redirect'   => false,
                'icon_url'   => 'dashicons-food',
                'position'   => 59,
            )
        );
    }

    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return;
    }

    $defaults = momizza_defaults();
    $fields   = array();
    $add_text = function( $name, $label, $type = 'text' ) use ( &$fields, $defaults ) {
        $fields[] = array(
            'key'           => 'field_momizza_' . $name,
            'label'         => $label,
            'name'          => $name,
            'type'          => $type,
            'default_value' => $defaults[ $name ] ?? '',
            'rows'          => 'textarea' === $type ? 4 : 0,
        );
    };

    $fields[] = array( 'key' => 'field_momizza_tab_business', 'label' => 'Business', 'type' => 'tab' );
    foreach ( array(
        'brand_name' => 'Brand name', 'location_label' => 'Header location label', 'tagline' => 'Tagline', 'phone' => 'Phone',
        'whatsapp_number' => 'WhatsApp number', 'email' => 'Business email', 'address' => 'Address', 'gstin' => 'GSTIN',
        'map_url' => 'Google Maps URL', 'facebook_url' => 'Facebook URL', 'instagram_url' => 'Instagram URL', 'google_reviews_url' => 'Google reviews URL', 'hours_short' => 'Short hours summary',
        'hours_monday' => 'Monday hours', 'hours_tuesday' => 'Tuesday hours', 'hours_wednesday' => 'Wednesday hours', 'hours_thursday' => 'Thursday hours',
        'hours_friday' => 'Friday hours', 'hours_saturday' => 'Saturday hours', 'hours_sunday' => 'Sunday hours',
    ) as $name => $label ) { $add_text( $name, $label, 'text' ); }

    $fields[] = array( 'key' => 'field_momizza_logo_image', 'label' => 'Website logo override', 'name' => 'logo_image', 'type' => 'image', 'return_format' => 'url', 'preview_size' => 'medium' );

    $fields[] = array( 'key' => 'field_momizza_tab_home', 'label' => 'Home', 'type' => 'tab' );
    foreach ( array(
        'hero_eyebrow' => 'Hero eyebrow', 'hero_title' => 'Hero title line 1', 'hero_title_accent' => 'Hero title accent line',
        'hero_primary_label' => 'Primary button label', 'hero_secondary_label' => 'Secondary button label',
    ) as $name => $label ) { $add_text( $name, $label ); }
    $add_text( 'hero_text', 'Hero paragraph', 'textarea' );
    $fields[] = array( 'key' => 'field_momizza_hero_image', 'label' => 'Hero image', 'name' => 'hero_image', 'type' => 'image', 'return_format' => 'url', 'preview_size' => 'medium' );

    $fields[] = array( 'key' => 'field_momizza_tab_menu', 'label' => 'Menu & Ordering', 'type' => 'tab' );
    foreach ( array( 'menu_pdf_label' => 'Menu PDF button label', 'menu_intro_eyebrow' => 'Menu eyebrow', 'menu_intro_title' => 'Menu title' ) as $name => $label ) { $add_text( $name, $label ); }
    $add_text( 'menu_intro_text', 'Menu intro', 'textarea' );
    $fields[] = array( 'key' => 'field_momizza_menu_pdf', 'label' => 'Menu PDF', 'name' => 'menu_pdf', 'type' => 'file', 'return_format' => 'url', 'mime_types' => 'pdf' );
    foreach ( array(
        'accept_online_orders' => 'Accept online orders',
        'enable_takeaway' => 'Enable takeaway',
        'enable_dine_in' => 'Enable dine-in',
        'enable_delivery' => 'Enable delivery',
        'enforce_open_hours' => 'Stop orders outside opening hours',
    ) as $name => $label ) {
        $fields[] = array( 'key' => 'field_momizza_' . $name, 'label' => $label, 'name' => $name, 'type' => 'select', 'choices' => array( 'yes' => 'Yes', 'no' => 'No' ), 'default_value' => $defaults[ $name ] ?? 'yes', 'ui' => 1 );
    }
    $add_text( 'prep_time', 'Typical preparation time' );
    $add_text( 'minimum_order', 'Minimum online order (₹)' );
    $add_text( 'delivery_note', 'Delivery note', 'textarea' );

    $fields[] = array( 'key' => 'field_momizza_tab_about', 'label' => 'Our Story', 'type' => 'tab' );
    $add_text( 'about_eyebrow', 'Eyebrow' );
    $add_text( 'about_title', 'Title' );
    $add_text( 'about_p1', 'Paragraph 1', 'textarea' );
    $add_text( 'about_p2', 'Paragraph 2', 'textarea' );
    $add_text( 'about_p3', 'Paragraph 3', 'textarea' );
    $fields[] = array( 'key' => 'field_momizza_kitchen_image', 'label' => 'Story image', 'name' => 'kitchen_image', 'type' => 'image', 'return_format' => 'url', 'preview_size' => 'medium' );

    $fields[] = array( 'key' => 'field_momizza_tab_contact', 'label' => 'Contact', 'type' => 'tab' );
    $add_text( 'contact_eyebrow', 'Eyebrow' );
    $add_text( 'contact_title', 'Title' );
    $add_text( 'contact_form_shortcode', 'Contact Form 7 shortcode' );

    $fields[] = array( 'key' => 'field_momizza_tab_colors', 'label' => 'Colors', 'type' => 'tab' );
    foreach ( array(
        'primary_color' => 'Signature red', 'accent_color' => 'Golden accent', 'background_color' => 'Background', 'card_color' => 'Card background',
        'foreground_color' => 'Cream text', 'muted_color' => 'Muted text', 'border_color' => 'Borders',
    ) as $name => $label ) {
        $fields[] = array( 'key' => 'field_momizza_' . $name, 'label' => $label, 'name' => $name, 'type' => 'color_picker', 'default_value' => $defaults[ $name ] );
    }

    acf_add_local_field_group(
        array(
            'key'      => 'group_momizza_settings',
            'title'    => 'Momizza Theme Settings',
            'fields'   => $fields,
            'location' => array(
                array(
                    array( 'param' => 'options_page', 'operator' => '==', 'value' => 'momizza-settings' ),
                ),
            ),
        )
    );
}
add_action( 'acf/init', 'momizza_acf_register' );
