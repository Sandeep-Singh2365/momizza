<?php
/** Structured fallback menu generated from Momizza_Menu_Booklet.md. */
return [
    [
        'title' => 'Pizza Classic Range',
        'slug' => 'pizza-classic-range',
        'note' => '',
        'items' => [
            [
                'name' => 'Double Cheese Margherita',
                'description' => 'Only cheese pizza',
                'options' => [
                    ['label' => 'Regular', 'price' => 189, 'display' => '₹189'],
                    ['label' => 'Medium', 'price' => 319, 'display' => '₹319'],
                    ['label' => 'Large', 'price' => 449, 'display' => '₹449'],
                ],
            ],
            [
                'name' => 'Farm Fresh Choice',
                'description' => 'Onion, capsicum, tomato, mushroom',
                'options' => [
                    ['label' => 'Regular', 'price' => 189, 'display' => '₹189'],
                    ['label' => 'Medium', 'price' => 319, 'display' => '₹319'],
                    ['label' => 'Large', 'price' => 449, 'display' => '₹449'],
                ],
            ],
            [
                'name' => 'Spicy Delight',
                'description' => 'Capsicum, jalapeno, mushroom',
                'options' => [
                    ['label' => 'Regular', 'price' => 189, 'display' => '₹189'],
                    ['label' => 'Medium', 'price' => 319, 'display' => '₹319'],
                    ['label' => 'Large', 'price' => 449, 'display' => '₹449'],
                ],
            ],
            [
                'name' => 'Paneer Makhani',
                'description' => 'Paneer, capsicum, makhani sauce',
                'options' => [
                    ['label' => 'Regular', 'price' => 189, 'display' => '₹189'],
                    ['label' => 'Medium', 'price' => 319, 'display' => '₹319'],
                    ['label' => 'Large', 'price' => 449, 'display' => '₹449'],
                ],
            ],
            [
                'name' => 'Achari Do Payaza',
                'description' => 'Onion, jalapeno, red paprika',
                'options' => [
                    ['label' => 'Regular', 'price' => 189, 'display' => '₹189'],
                    ['label' => 'Medium', 'price' => 319, 'display' => '₹319'],
                    ['label' => 'Large', 'price' => 449, 'display' => '₹449'],
                ],
            ],
        ],
    ],
    [
        'title' => 'Pizza Signature Range',
        'slug' => 'pizza-signature-range',
        'note' => '',
        'items' => [
            [
                'name' => 'Paneer Special',
                'description' => 'Paneer, capsicum, red paprika',
                'options' => [
                    ['label' => 'Regular', 'price' => 239, 'display' => '₹239'],
                    ['label' => 'Medium', 'price' => 399, 'display' => '₹399'],
                    ['label' => 'Large', 'price' => 519, 'display' => '₹519'],
                ],
            ],
            [
                'name' => 'Paneer Tadka',
                'description' => 'Paneer, capsicum, jalapeno',
                'options' => [
                    ['label' => 'Regular', 'price' => 239, 'display' => '₹239'],
                    ['label' => 'Medium', 'price' => 399, 'display' => '₹399'],
                    ['label' => 'Large', 'price' => 519, 'display' => '₹519'],
                ],
            ],
            [
                'name' => 'Deluxe Veggie',
                'description' => 'Onion, capsicum, corn, mushroom, paneer',
                'options' => [
                    ['label' => 'Regular', 'price' => 239, 'display' => '₹239'],
                    ['label' => 'Medium', 'price' => 399, 'display' => '₹399'],
                    ['label' => 'Large', 'price' => 519, 'display' => '₹519'],
                ],
            ],
            [
                'name' => 'Black & White',
                'description' => 'Capsicum, corn, onion, paneer, black olive',
                'options' => [
                    ['label' => 'Regular', 'price' => 239, 'display' => '₹239'],
                    ['label' => 'Medium', 'price' => 399, 'display' => '₹399'],
                    ['label' => 'Large', 'price' => 519, 'display' => '₹519'],
                ],
            ],
            [
                'name' => 'Tandoori Pizza',
                'description' => 'Onion, capsicum, jalapeno, tandoori sauce',
                'options' => [
                    ['label' => 'Regular', 'price' => 239, 'display' => '₹239'],
                    ['label' => 'Medium', 'price' => 399, 'display' => '₹399'],
                    ['label' => 'Large', 'price' => 519, 'display' => '₹519'],
                ],
            ],
            [
                'name' => 'Green Mexican',
                'description' => 'Jalapeno, onion, capsicum & tomato sprinkled with Mexican',
                'options' => [
                    ['label' => 'Regular', 'price' => 239, 'display' => '₹239'],
                    ['label' => 'Medium', 'price' => 399, 'display' => '₹399'],
                    ['label' => 'Large', 'price' => 519, 'display' => '₹519'],
                ],
            ],
        ],
    ],
    [
        'title' => 'Pizza Supreme Range',
        'slug' => 'pizza-supreme-range',
        'note' => '',
        'items' => [
            [
                'name' => 'Kadai Paneer',
                'description' => 'Paneer, onion, capsicum, tomato, mushroom & extra cheese',
                'options' => [
                    ['label' => 'Regular', 'price' => 279, 'display' => '₹279'],
                    ['label' => 'Medium', 'price' => 499, 'display' => '₹499'],
                    ['label' => 'Large', 'price' => 619, 'display' => '₹619'],
                ],
            ],
            [
                'name' => 'Mix Veggies',
                'description' => 'Tomato, capsicum, corn, onion, mushroom, black olives & extra cheese',
                'options' => [
                    ['label' => 'Regular', 'price' => 279, 'display' => '₹279'],
                    ['label' => 'Medium', 'price' => 499, 'display' => '₹499'],
                    ['label' => 'Large', 'price' => 619, 'display' => '₹619'],
                ],
            ],
            [
                'name' => 'Veggie Desire',
                'description' => 'Capsicum, corn, mushroom, paneer, black olives, jalapeno, red paprika & extra cheese',
                'options' => [
                    ['label' => 'Regular', 'price' => 279, 'display' => '₹279'],
                    ['label' => 'Medium', 'price' => 499, 'display' => '₹499'],
                    ['label' => 'Large', 'price' => 619, 'display' => '₹619'],
                ],
            ],
            [
                'name' => 'Spicy Veg Heaven',
                'description' => 'Mushroom, capsicum, onion, jalapeno, red paprika, corn, paneer & extra cheese',
                'options' => [
                    ['label' => 'Regular', 'price' => 279, 'display' => '₹279'],
                    ['label' => 'Medium', 'price' => 499, 'display' => '₹499'],
                    ['label' => 'Large', 'price' => 619, 'display' => '₹619'],
                ],
            ],
        ],
    ],
    [
        'title' => 'Make Your Own Pizza',
        'slug' => 'make-your-own-pizza',
        'note' => '',
        'items' => [
            [
                'name' => 'Make Your Own Pizza',
                'description' => 'Choose your size and build it your way.',
                'options' => [
                    ['label' => 'Regular', 'price' => 149, 'display' => '₹149'],
                    ['label' => 'Medium', 'price' => 259, 'display' => '₹259'],
                    ['label' => 'Large', 'price' => 399, 'display' => '₹399'],
                ],
            ],
        ],
    ],
    [
        'title' => 'Burgers',
        'slug' => 'burgers',
        'note' => 'Burger Combo includes Burger + French Fries + Small Coke',
        'items' => [
            [
                'name' => 'Aloo Tikki Burger',
                'description' => '',
                'options' => [
                    ['label' => 'Burger Only', 'price' => 39, 'display' => '₹39'],
                    ['label' => 'Combo', 'price' => 129, 'display' => '₹129'],
                ],
            ],
            [
                'name' => 'Vegi Burger',
                'description' => '',
                'options' => [
                    ['label' => 'Burger Only', 'price' => 59, 'display' => '₹59'],
                    ['label' => 'Combo', 'price' => 139, 'display' => '₹139'],
                ],
            ],
            [
                'name' => 'Cheesy Burger',
                'description' => '',
                'options' => [
                    ['label' => 'Burger Only', 'price' => 79, 'display' => '₹79'],
                    ['label' => 'Combo', 'price' => 169, 'display' => '₹169'],
                ],
            ],
            [
                'name' => 'Tandoori Burger',
                'description' => '',
                'options' => [
                    ['label' => 'Burger Only', 'price' => 79, 'display' => '₹79'],
                    ['label' => 'Combo', 'price' => 169, 'display' => '₹169'],
                ],
            ],
            [
                'name' => 'Paneer-E-Zaika',
                'description' => '',
                'options' => [
                    ['label' => 'Burger Only', 'price' => 129, 'display' => '₹129'],
                    ['label' => 'Combo', 'price' => 219, 'display' => '₹219'],
                ],
            ],
            [
                'name' => 'Momizza Special Burger',
                'description' => '',
                'options' => [
                    ['label' => 'Burger Only', 'price' => 149, 'display' => '₹149'],
                    ['label' => 'Combo', 'price' => 239, 'display' => '₹239'],
                ],
            ],
        ],
    ],
    [
        'title' => 'Sandwiches',
        'slug' => 'sandwiches',
        'note' => 'Sandwich Combo includes Sandwich + French Fries + Small Coke',
        'items' => [
            [
                'name' => 'Grilled Sandwich',
                'description' => '',
                'options' => [
                    ['label' => 'Sandwich Only', 'price' => 89, 'display' => '₹89'],
                    ['label' => 'Combo', 'price' => 169, 'display' => '₹169'],
                ],
            ],
            [
                'name' => 'Cheesy Grilled Sandwich',
                'description' => '',
                'options' => [
                    ['label' => 'Sandwich Only', 'price' => 109, 'display' => '₹109'],
                    ['label' => 'Combo', 'price' => 199, 'display' => '₹199'],
                ],
            ],
            [
                'name' => 'Paneer & Corn Sandwich',
                'description' => '',
                'options' => [
                    ['label' => 'Sandwich Only', 'price' => 109, 'display' => '₹109'],
                    ['label' => 'Combo', 'price' => 199, 'display' => '₹199'],
                ],
            ],
            [
                'name' => 'Special Sandwich',
                'description' => '',
                'options' => [
                    ['label' => 'Sandwich Only', 'price' => 129, 'display' => '₹129'],
                    ['label' => 'Combo', 'price' => 219, 'display' => '₹219'],
                ],
            ],
        ],
    ],
    [
        'title' => 'Fries',
        'slug' => 'fries',
        'note' => '',
        'items' => [
            [
                'name' => 'French Fries',
                'description' => '',
                'options' => [
                    ['label' => 'Small', 'price' => 69, 'display' => '₹69'],
                    ['label' => 'Large', 'price' => 129, 'display' => '₹129'],
                ],
            ],
            [
                'name' => 'Masala Fries',
                'description' => '',
                'options' => [
                    ['label' => 'Small', 'price' => 89, 'display' => '₹89'],
                    ['label' => 'Large', 'price' => 149, 'display' => '₹149'],
                ],
            ],
            [
                'name' => 'Spicy Peri Peri Fries',
                'description' => '',
                'options' => [
                    ['label' => 'Small', 'price' => 99, 'display' => '₹99'],
                    ['label' => 'Large', 'price' => 159, 'display' => '₹159'],
                ],
            ],
            [
                'name' => 'Cheesy Saucy Fries',
                'description' => '',
                'options' => [
                    ['label' => 'Small', 'price' => 109, 'display' => '₹109'],
                    ['label' => 'Large', 'price' => 169, 'display' => '₹169'],
                ],
            ],
            [
                'name' => 'Masala Veggi Crispors',
                'description' => '',
                'options' => [
                    ['label' => 'Small', 'price' => null, 'display' => '—'],
                    ['label' => 'Large', 'price' => 109, 'display' => '₹109'],
                ],
            ],
        ],
    ],
    [
        'title' => 'Baked Pastas',
        'slug' => 'baked-pastas',
        'note' => '',
        'items' => [
            [
                'name' => 'Red Sauce Pasta',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
            [
                'name' => 'White Sauce Pasta',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
            [
                'name' => 'Tandoori Pasta',
                'description' => '',
                'price' => 119,
                'display' => '₹119',
            ],
            [
                'name' => 'Makhani Pasta',
                'description' => '',
                'price' => 119,
                'display' => '₹119',
            ],
            [
                'name' => "Momizza's Special Pasta",
                'description' => '',
                'price' => 129,
                'display' => '₹129',
            ],
        ],
    ],
    [
        'title' => 'Subs & Sides',
        'slug' => 'subs-sides',
        'note' => '',
        'items' => [
            [
                'name' => 'Cheesy Zingy Parcel',
                'description' => '',
                'price' => 49,
                'display' => '₹49',
            ],
            [
                'name' => 'Paneer Parcel',
                'description' => '',
                'price' => 59,
                'display' => '₹59',
            ],
            [
                'name' => 'Veggies Fingers (6 Pc)',
                'description' => '',
                'price' => 89,
                'display' => '₹89',
            ],
            [
                'name' => 'Masala American Corn',
                'description' => '',
                'price' => 89,
                'display' => '₹89',
            ],
            [
                'name' => 'Mix Salad',
                'description' => '',
                'price' => 119,
                'display' => '₹119',
            ],
            [
                'name' => 'Calzone',
                'description' => '',
                'price' => 119,
                'display' => '₹119',
            ],
            [
                'name' => 'Taco',
                'description' => '',
                'price' => 119,
                'display' => '₹119',
            ],
        ],
    ],
    [
        'title' => 'Shakes & Drinks',
        'slug' => 'shakes-drinks',
        'note' => '',
        'items' => [
            [
                'name' => 'Hot Coffee',
                'description' => '',
                'price' => 69,
                'display' => '₹69',
            ],
            [
                'name' => 'Vanilla Shake',
                'description' => '',
                'price' => 89,
                'display' => '₹89',
            ],
            [
                'name' => 'Cold Coffee',
                'description' => '',
                'price' => 89,
                'display' => '₹89',
            ],
            [
                'name' => 'Mango Shake',
                'description' => '',
                'price' => 99,
                'display' => '₹99',
            ],
            [
                'name' => 'Strawberry Shake',
                'description' => '',
                'price' => 99,
                'display' => '₹99',
            ],
            [
                'name' => 'Chocolate Shake',
                'description' => '',
                'price' => 99,
                'display' => '₹99',
            ],
            [
                'name' => 'Oreo Shake',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
            [
                'name' => 'Butter Scotch Shake',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
            [
                'name' => 'Special Shake',
                'description' => '',
                'price' => 119,
                'display' => '₹119',
            ],
            [
                'name' => 'Coke Glass',
                'description' => '',
                'price' => 30,
                'display' => '₹30',
            ],
            [
                'name' => 'Coke / Pepsi',
                'description' => '',
                'price' => null,
                'display' => 'MRP',
            ],
            [
                'name' => 'Fruit Drinks',
                'description' => '',
                'price' => null,
                'display' => 'MRP',
            ],
            [
                'name' => 'Mineral Water',
                'description' => '',
                'price' => null,
                'display' => 'MRP',
            ],
        ],
    ],
    [
        'title' => 'Mojitos',
        'slug' => 'mojitos',
        'note' => '',
        'items' => [
            [
                'name' => 'Mint Mojito',
                'description' => '',
                'price' => 99,
                'display' => '₹99',
            ],
            [
                'name' => 'Green Apple Mojito',
                'description' => '',
                'price' => 99,
                'display' => '₹99',
            ],
            [
                'name' => 'Strawberry Mojito',
                'description' => '',
                'price' => 99,
                'display' => '₹99',
            ],
            [
                'name' => 'Mango Mojito',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
            [
                'name' => 'Masala Mango Mojito',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
            [
                'name' => 'Blue Curacao Mojito',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
        ],
    ],
    [
        'title' => 'Bread & Dips',
        'slug' => 'bread-dips',
        'note' => '',
        'items' => [
            [
                'name' => 'Garlic Bread (Twisted)',
                'description' => '',
                'price' => 89,
                'display' => '₹89',
            ],
            [
                'name' => 'Stuff Garlic Bread',
                'description' => '',
                'price' => 129,
                'display' => '₹129',
            ],
            [
                'name' => 'Paneer Stuff Garlic Bread',
                'description' => '',
                'price' => 139,
                'display' => '₹139',
            ],
            [
                'name' => 'Cheesy Dip',
                'description' => '',
                'price' => 25,
                'display' => '₹25',
            ],
            [
                'name' => 'Spicy Dip',
                'description' => '',
                'price' => 25,
                'display' => '₹25',
            ],
            [
                'name' => 'Chilly Dip',
                'description' => '',
                'price' => 25,
                'display' => '₹25',
            ],
        ],
    ],
    [
        'title' => 'Wraps',
        'slug' => 'wraps',
        'note' => '',
        'items' => [
            [
                'name' => 'Italian Wrap',
                'description' => '',
                'price' => 99,
                'display' => '₹99',
            ],
            [
                'name' => 'Cheesy Wrap',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
            [
                'name' => 'Spicy Paneer Wrap',
                'description' => '',
                'price' => 119,
                'display' => '₹119',
            ],
            [
                'name' => 'Makhani Paneer Wrap',
                'description' => '',
                'price' => 119,
                'display' => '₹119',
            ],
        ],
    ],
    [
        'title' => 'Desserts',
        'slug' => 'desserts',
        'note' => '',
        'items' => [
            [
                'name' => 'Vanilla Ice Cream',
                'description' => '',
                'price' => 49,
                'display' => '₹49',
            ],
            [
                'name' => 'Chocolate Ice Cream',
                'description' => '',
                'price' => 59,
                'display' => '₹59',
            ],
            [
                'name' => 'Strawberry Ice Cream',
                'description' => '',
                'price' => 59,
                'display' => '₹59',
            ],
            [
                'name' => 'Chocolate Brownie',
                'description' => '',
                'price' => 109,
                'display' => '₹109',
            ],
        ],
    ],
    [
        'title' => 'Momos',
        'slug' => 'momos',
        'note' => '',
        'items' => [
            [
                'name' => 'Veg Momo',
                'description' => '',
                'price' => 100,
                'display' => '₹100',
            ],
            [
                'name' => 'Paneer Momo',
                'description' => '',
                'price' => 140,
                'display' => '₹140',
            ],
            [
                'name' => 'Cheese Momo',
                'description' => '',
                'price' => 150,
                'display' => '₹150',
            ],
            [
                'name' => 'Jhol Momo',
                'description' => '',
                'price' => 200,
                'display' => '₹200',
            ],
            [
                'name' => 'Kurkure Momo',
                'description' => '',
                'price' => 200,
                'display' => '₹200',
            ],
            [
                'name' => 'Cheese Kurkure Momo',
                'description' => '',
                'price' => 225,
                'display' => '₹225',
            ],
        ],
    ],
    [
        'title' => 'Pan Pastas',
        'slug' => 'pan-pastas',
        'note' => '',
        'items' => [
            [
                'name' => 'White Sauce Pasta',
                'description' => '',
                'price' => 240,
                'display' => '₹240',
            ],
            [
                'name' => 'Red Sauce Pasta',
                'description' => '',
                'price' => 249,
                'display' => '₹249',
            ],
            [
                'name' => 'Mix Pasta',
                'description' => '',
                'price' => 249,
                'display' => '₹249',
            ],
            [
                'name' => 'Cheese Pasta',
                'description' => '',
                'price' => 299,
                'display' => '₹299',
            ],
        ],
    ],
    [
        'title' => 'Manchurian, Rice & Noodles',
        'slug' => 'manchurian-rice-noodles',
        'note' => '',
        'items' => [
            [
                'name' => 'Dry Manchurian',
                'description' => '',
                'price' => 159,
                'display' => '₹159',
            ],
            [
                'name' => 'Semi Gravy Manchurian',
                'description' => '',
                'price' => 169,
                'display' => '₹169',
            ],
            [
                'name' => 'Gravy Manchurian',
                'description' => '',
                'price' => 189,
                'display' => '₹189',
            ],
            [
                'name' => 'Veg Fried Rice',
                'description' => '',
                'price' => 159,
                'display' => '₹159',
            ],
            [
                'name' => 'Schezwan Fried Rice',
                'description' => '',
                'price' => 189,
                'display' => '₹189',
            ],
            [
                'name' => 'Paneer Fried Rice',
                'description' => '',
                'price' => 199,
                'display' => '₹199',
            ],
            [
                'name' => 'Veg Hakka Noodles',
                'description' => '',
                'price' => 159,
                'display' => '₹159',
            ],
            [
                'name' => 'Schezwan Veg Noodles',
                'description' => '',
                'price' => 169,
                'display' => '₹169',
            ],
            [
                'name' => 'Paneer Noodles',
                'description' => '',
                'price' => 189,
                'display' => '₹189',
            ],
        ],
    ],
    [
        'title' => 'Rolls',
        'slug' => 'rolls',
        'note' => '',
        'items' => [
            [
                'name' => 'Veg Roll',
                'description' => '',
                'price' => 80,
                'display' => '₹80',
            ],
            [
                'name' => 'Spring Roll',
                'description' => '',
                'price' => 90,
                'display' => '₹90',
            ],
            [
                'name' => 'Cheese Roll',
                'description' => '',
                'price' => 110,
                'display' => '₹110',
            ],
            [
                'name' => 'Paneer Roll',
                'description' => '',
                'price' => 120,
                'display' => '₹120',
            ],
            [
                'name' => 'Cheese Paneer Roll',
                'description' => '',
                'price' => 140,
                'display' => '₹140',
            ],
        ],
    ],
    [
        'title' => 'Snacks',
        'slug' => 'snacks',
        'note' => '',
        'items' => [
            [
                'name' => 'Chili Potato',
                'description' => '',
                'price' => 149,
                'display' => '₹149',
            ],
            [
                'name' => 'Honey Chili Potato',
                'description' => '',
                'price' => 179,
                'display' => '₹179',
            ],
            [
                'name' => 'Chili Paneer',
                'description' => '',
                'price' => 189,
                'display' => '₹189',
            ],
            [
                'name' => 'Cheese Chili',
                'description' => '',
                'price' => 199,
                'display' => '₹199',
            ],
            [
                'name' => 'Honey Chili Cauliflower',
                'description' => '',
                'price' => null,
                'display' => '—',
            ],
        ],
    ],
    [
        'title' => 'Combos',
        'slug' => 'combos',
        'note' => '',
        'items' => [
            [
                'name' => 'Veg Fried Rice + Manchurian',
                'description' => '',
                'price' => 229,
                'display' => '₹229',
            ],
            [
                'name' => 'Schezwan Rice + Manchurian',
                'description' => '',
                'price' => 249,
                'display' => '₹249',
            ],
            [
                'name' => 'Honey Chili Potato + Veg Fried Rice',
                'description' => '',
                'price' => 259,
                'display' => '₹259',
            ],
            [
                'name' => 'Cheese Chili + Fried Rice',
                'description' => '',
                'price' => 269,
                'display' => '₹269',
            ],
            [
                'name' => 'Chili Paneer + Fried Rice',
                'description' => '',
                'price' => 269,
                'display' => '₹269',
            ],
        ],
    ],
];