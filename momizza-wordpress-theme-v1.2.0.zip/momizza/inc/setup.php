<?php
/** Theme setup and assets. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function momizza_setup() {
    load_theme_textdomain( 'momizza', MOMIZZA_DIR . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'assets/css/app.css' );
    add_theme_support( 'custom-logo', array( 'height' => 240, 'width' => 240, 'flex-height' => true, 'flex-width' => true ) );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    register_nav_menus(
        array(
            'primary' => __( 'Primary Menu', 'momizza' ),
            'footer'  => __( 'Footer Menu', 'momizza' ),
        )
    );
}
add_action( 'after_setup_theme', 'momizza_setup' );

function momizza_enqueue_assets() {
    wp_enqueue_style(
        'momizza-fonts',
        'https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&family=Bebas+Neue&family=Pacifico&display=swap',
        array(),
        null
    );
    wp_enqueue_style( 'momizza-style', get_stylesheet_uri(), array( 'momizza-fonts' ), MOMIZZA_VERSION );

    if ( class_exists( 'WooCommerce' ) ) {
        wp_enqueue_script( 'wc-cart-fragments' );
        wp_enqueue_script( 'wc-add-to-cart' );
    }

    wp_enqueue_script( 'momizza-app', MOMIZZA_URI . '/assets/js/app.js', array( 'jquery' ), MOMIZZA_VERSION, true );
    wp_localize_script(
        'momizza-app',
        'MomizzaConfig',
        array(
            'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'momizza_cart' ),
            'wooActive'   => class_exists( 'WooCommerce' ),
            'cartUrl'     => class_exists( 'WooCommerce' ) ? wc_get_cart_url() : '',
            'checkoutUrl' => class_exists( 'WooCommerce' ) ? wc_get_checkout_url() : '',
            'addingText'  => __( 'Adding…', 'momizza' ),
            'addedText'   => __( 'Added ✓', 'momizza' ),
            'errorText'   => __( 'Could not add this item. Please try again.', 'momizza' ),
        )
    );
}
add_action( 'wp_enqueue_scripts', 'momizza_enqueue_assets' );

function momizza_register_elementor_locations( $elementor_theme_manager ) {
    $elementor_theme_manager->register_all_core_location();
}
add_action( 'elementor/theme/register_locations', 'momizza_register_elementor_locations' );

function momizza_body_classes( $classes ) {
    $classes[] = 'momizza-theme';
    if ( class_exists( 'WooCommerce' ) ) {
        $classes[] = 'momizza-woocommerce';
    }
    return $classes;
}
add_filter( 'body_class', 'momizza_body_classes' );

function momizza_resource_hints( $urls, $relation_type ) {
    if ( 'preconnect' === $relation_type ) {
        $urls[] = 'https://fonts.googleapis.com';
        $urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous' );
    }
    return $urls;
}
add_filter( 'wp_resource_hints', 'momizza_resource_hints', 10, 2 );
