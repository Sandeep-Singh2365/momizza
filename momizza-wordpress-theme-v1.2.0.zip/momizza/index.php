<?php get_header(); ?>
<main class="momizza-main momizza-default-page"><div class="momizza-container momizza-editor-content">
<h1><?php bloginfo( 'name' ); ?></h1>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?><article <?php post_class(); ?>><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></article><?php endwhile; the_posts_pagination(); else : ?><p>No content found.</p><?php endif; ?>
</div></main>
<?php get_footer(); ?>
