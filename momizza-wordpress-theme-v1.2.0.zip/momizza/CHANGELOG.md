# Changelog

## 1.2.0
- Added restaurant-first Momizza Control Panel as a top-level WordPress admin area.
- Added Dashboard, Orders, Menu Products, Categories, Business Info, Opening Hours, Website & Design, Ordering, Payments, and Help & System pages.
- Added a simplified **Momizza Manager** staff role and automatic redirect to the Momizza dashboard.
- Added order search, order print support, customer call shortcut, status changes, and internal order notes.
- Added simple/variable menu item editor with image, categories, price, variation prices, per-option availability, visibility, featured state, order, and trash action.
- Added category image editing and safe category deletion.
- Added editable logo override to the simple control panel, Customizer, and ACF Pro settings.
- Added Instagram default: https://www.instagram.com/momizza2026?utm_source=qr
- Added optional automatic closing of online ordering outside restaurant opening hours.
- Added Razorpay control panel integration for the official WooCommerce gateway settings, including test/live key detection and secret masking.
- Added WooCommerce Checkout Blocks order-mode metadata compatibility.
- Confirmed paired/second pizza prices are ignored; only structured single prices are used.

## 1.0.0
- Initial WordPress/WooCommerce conversion from the supplied Lovable project.
