<?php
/** Our Story page template (slug: about). */
get_header();
if ( have_posts() ) { the_post(); }
if ( momizza_is_elementor_built() ) { the_content(); get_footer(); return; }
$title_parts = explode( ',', (string) momizza_opt( 'about_title' ), 2 );
?>
<main class="momizza-main">
    <section class="momizza-about momizza-container">
        <div class="momizza-about__copy">
            <p class="momizza-eyebrow"><?php echo esc_html( momizza_opt( 'about_eyebrow' ) ); ?></p>
            <h1><?php echo esc_html( $title_parts[0] ); ?><?php if ( isset( $title_parts[1] ) ) : ?><br><span><?php echo esc_html( trim( $title_parts[1] ) ); ?></span><?php endif; ?></h1>
            <div class="momizza-prose">
                <p><?php echo esc_html( momizza_opt( 'about_p1' ) ); ?></p>
                <p><?php echo esc_html( momizza_opt( 'about_p2' ) ); ?></p>
                <p><?php echo esc_html( momizza_opt( 'about_p3' ) ); ?></p>
            </div>
            <a class="momizza-btn momizza-btn--outline momizza-btn--large" href="<?php echo esc_url( home_url( '/menu/' ) ); ?>">Browse the menu</a>
        </div>
        <img class="momizza-about__image" src="<?php echo esc_url( momizza_kitchen_url() ); ?>" alt="Momizza kitchen" width="1200" height="1408" loading="lazy">
    </section>
    <section class="momizza-values">
        <div class="momizza-container momizza-values__grid">
            <article><h2>Fresh daily</h2><p>Fresh ingredients, sauces, fillings and toppings prepared for service.</p></article>
            <article><h2>Big choice</h2><p>Pizza, momos, burgers, sandwiches, Chinese, drinks, desserts and more.</p></article>
            <article><h2>Made with love</h2><p>100% real cheese and a menu built around comfort-food cravings.</p></article>
        </div>
    </section>
    <?php if ( trim( get_the_content() ) ) : ?><section class="momizza-section momizza-container momizza-editor-content"><?php the_content(); ?></section><?php endif; ?>
</main>
<?php get_footer(); ?>
