<?php
get_header();
?>
<main class="momizza-main momizza-default-page"><div class="momizza-container momizza-editor-content">
<?php
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {
    while ( have_posts() ) : the_post(); ?><h1><?php the_title(); ?></h1><?php the_content(); ?><?php endwhile;
}
?>
</div></main>
<?php get_footer(); ?>
