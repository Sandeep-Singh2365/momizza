<?php
/** WooCommerce fallback template. */
get_header();
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( is_singular( 'product' ) ? 'single' : 'archive' ) ) {
    woocommerce_content();
}
get_footer();
