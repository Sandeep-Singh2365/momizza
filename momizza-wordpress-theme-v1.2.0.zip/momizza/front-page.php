<?php
/** Front page */
get_header();
if ( have_posts() ) { the_post(); }
if ( momizza_is_elementor_built() ) {
    the_content();
    get_footer();
    return;
}
?>
<main class="momizza-main">
    <section class="momizza-hero">
        <img class="momizza-hero__image" src="<?php echo esc_url( momizza_hero_url() ); ?>" alt="Fresh Momizza food" width="1600" height="1104" fetchpriority="high">
        <div class="momizza-hero__veil"></div>
        <div class="momizza-container momizza-hero__content">
            <img class="momizza-hero__logo" src="<?php echo esc_url( momizza_logo_url() ); ?>" alt="<?php echo esc_attr( momizza_opt( 'brand_name' ) ); ?> logo" width="160" height="160">
            <p class="momizza-eyebrow"><?php echo esc_html( momizza_opt( 'hero_eyebrow' ) ); ?></p>
            <h1><?php echo esc_html( momizza_opt( 'hero_title' ) ); ?><br><span><?php echo esc_html( momizza_opt( 'hero_title_accent' ) ); ?></span></h1>
            <p class="momizza-hero__copy"><?php echo esc_html( momizza_opt( 'hero_text' ) ); ?></p>
            <div class="momizza-hero__actions">
                <a class="momizza-btn momizza-btn--primary momizza-btn--large" href="<?php echo esc_url( momizza_phone_href() ); ?>"><?php echo esc_html( momizza_opt( 'hero_primary_label' ) ); ?></a>
                <a class="momizza-btn momizza-btn--outline momizza-btn--large" href="<?php echo esc_url( home_url( '/menu/' ) ); ?>"><?php echo esc_html( momizza_opt( 'hero_secondary_label' ) ); ?></a>
            </div>
        </div>
    </section>

    <section class="momizza-strip">
        <div class="momizza-container momizza-strip__grid">
            <article><?php echo momizza_svg_icon( 'flame', 'momizza-strip__icon' ); ?><div><h3>Made to order</h3><p>Freshly prepared when you ask.</p></div></article>
            <article><?php echo momizza_svg_icon( 'leaf', 'momizza-strip__icon' ); ?><div><h3>Fresh ingredients</h3><p>100% real cheese · made with love.</p></div></article>
            <article><?php echo momizza_svg_icon( 'clock', 'momizza-strip__icon' ); ?><div><h3>Open 6 days</h3><p><?php echo esc_html( momizza_opt( 'hours_short' ) ); ?></p></div></article>
        </div>
    </section>

    <section class="momizza-section momizza-container">
        <div class="momizza-section-head">
            <h2>Counter <span>favourites</span></h2>
            <a href="<?php echo esc_url( home_url( '/menu/' ) ); ?>">Full menu →</a>
        </div>
        <div class="momizza-favourites">
            <?php
            $rendered = false;
            if ( class_exists( 'WooCommerce' ) ) {
                $products = wc_get_products( array( 'limit' => 6, 'status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC' ) );
                if ( $products ) {
                    $rendered = true;
                    foreach ( $products as $product ) {
                        ?>
                        <a class="momizza-favourite-card" href="<?php echo esc_url( $product->get_permalink() ); ?>">
                            <span><?php echo esc_html( $product->get_name() ); ?></span>
                            <strong><?php echo wp_kses_post( $product->get_price_html() ); ?></strong>
                        </a>
                        <?php
                    }
                }
            }
            if ( ! $rendered ) {
                $fallback = array(
                    array( 'Double Cheese Margherita', '₹189+' ),
                    array( 'Paneer Special', '₹239+' ),
                    array( 'Veg Momo', '₹100' ),
                    array( 'Cheese Kurkure Momo', '₹225' ),
                    array( 'Aloo Tikki Burger', '₹39+' ),
                    array( 'Veg Fried Rice + Manchurian', '₹229' ),
                );
                foreach ( $fallback as $item ) {
                    echo '<a class="momizza-favourite-card" href="' . esc_url( home_url( '/menu/' ) ) . '"><span>' . esc_html( $item[0] ) . '</span><strong>' . esc_html( $item[1] ) . '</strong></a>';
                }
            }
            ?>
        </div>
        <?php if ( trim( get_the_content() ) ) : ?><div class="momizza-editor-content"><?php the_content(); ?></div><?php endif; ?>
    </section>

    <section class="momizza-cta">
        <div class="momizza-container momizza-cta__inner">
            <h2>Hungry now?</h2>
            <p>Ring the kitchen and we’ll start cooking. Dine-in, takeaway and delivery options can be managed through WooCommerce.</p>
            <a class="momizza-btn momizza-btn--primary momizza-btn--large" href="<?php echo esc_url( momizza_phone_href() ); ?>"><?php echo esc_html( momizza_opt( 'phone' ) ); ?></a>
        </div>
    </section>
</main>
<?php get_footer(); ?>
