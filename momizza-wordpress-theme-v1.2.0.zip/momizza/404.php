<?php get_header(); ?>
<main class="momizza-main momizza-not-found"><div class="momizza-container"><p class="momizza-eyebrow">404</p><h1>That plate is empty.</h1><p>We couldn’t find this page.</p><a class="momizza-btn momizza-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">Back home</a></div></main>
<?php get_footer(); ?>
