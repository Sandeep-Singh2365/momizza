<?php
/** Menu page template (slug: menu). */
get_header();
if ( have_posts() ) { the_post(); }
if ( momizza_is_elementor_built() ) { the_content(); get_footer(); return; }

$menu_data    = momizza_menu_data();
$has_products = class_exists( 'WooCommerce' ) && (bool) wc_get_products( array( 'limit' => 1, 'status' => 'publish', 'return' => 'ids' ) );

if ( $has_products ) {
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
    if ( is_wp_error( $terms ) ) { $terms = array(); }
}
?>
<main class="momizza-main">
    <section class="momizza-page-hero">
        <div class="momizza-container">
            <p class="momizza-eyebrow"><?php echo esc_html( momizza_opt( 'menu_intro_eyebrow' ) ); ?></p>
            <?php $menu_title = (string) momizza_opt( 'menu_intro_title' ); $parts = preg_split( '/\s+(?=wrap\s*&\s*fire$)/i', $menu_title, 2 ); ?>
            <h1><?php echo esc_html( $parts[0] ?? $menu_title ); ?><?php if ( isset( $parts[1] ) ) : ?> <span><?php echo esc_html( $parts[1] ); ?></span><?php endif; ?></h1>
            <p><?php echo esc_html( momizza_opt( 'menu_intro_text' ) ); ?> <?php if ( ! $has_products ) : ?>Online cart buttons become active after importing the bundled WooCommerce products CSV.<?php endif; ?></p>
            <div class="momizza-page-hero__actions">
                <a class="momizza-btn momizza-btn--outline" href="<?php echo esc_url( momizza_menu_pdf_url() ); ?>" download><?php echo momizza_svg_icon( 'download', 'momizza-icon' ); ?><?php echo esc_html( momizza_opt( 'menu_pdf_label' ) ); ?></a>
                <a class="momizza-btn momizza-btn--primary" href="<?php echo esc_url( momizza_phone_href() ); ?>">Call <?php echo esc_html( momizza_opt( 'phone' ) ); ?></a>
            </div>
        </div>
    </section>

    <div class="momizza-container momizza-menu-wrap">
        <nav class="momizza-category-nav" aria-label="Menu categories">
            <?php if ( $has_products && $terms ) : ?>
                <?php foreach ( $terms as $term ) : ?><a href="#<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></a><?php endforeach; ?>
            <?php else : ?>
                <?php foreach ( $menu_data as $section ) : ?><a href="#<?php echo esc_attr( $section['slug'] ); ?>"><?php echo esc_html( $section['title'] ); ?></a><?php endforeach; ?>
            <?php endif; ?>
        </nav>

        <div class="momizza-menu-grid">
            <?php if ( $has_products && $terms ) : ?>
                <?php foreach ( $terms as $term ) :
                    $products = wc_get_products( array( 'category' => array( $term->slug ), 'limit' => -1, 'status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC' ) );
                    if ( ! $products ) { continue; }
                    ?>
                    <section class="momizza-menu-section" id="<?php echo esc_attr( $term->slug ); ?>">
                        <h2><span><?php echo esc_html( $term->name ); ?></span><i></i></h2>
                        <?php
                        $section_note = $term->description;
                        if ( ! $section_note ) {
                            foreach ( $menu_data as $fallback_section ) {
                                if ( $fallback_section['slug'] === $term->slug ) { $section_note = $fallback_section['note']; break; }
                            }
                        }
                        if ( $section_note ) : ?><p class="momizza-menu-note"><?php echo esc_html( $section_note ); ?></p><?php endif; ?>
                        <ul>
                            <?php foreach ( $products as $product ) : ?>
                                <li class="momizza-menu-item">
                                    <div class="momizza-menu-item__text">
                                        <p class="momizza-menu-item__name"><?php echo esc_html( $product->get_name() ); ?></p>
                                        <?php if ( $product->get_short_description() ) : ?><p class="momizza-menu-item__desc"><?php echo esc_html( wp_strip_all_tags( $product->get_short_description() ) ); ?></p><?php endif; ?>
                                        <?php if ( ! $product->is_type( 'variable' ) ) : ?>
                                            <p class="momizza-menu-item__price"><?php echo $product->get_price() !== '' ? wp_kses_post( $product->get_price_html() ) : esc_html( get_post_meta( $product->get_id(), 'momizza_display_price', true ) ?: 'Ask for price' ); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="momizza-menu-item__actions">
                                        <?php if ( $product->is_type( 'variable' ) ) : ?>
                                            <div class="momizza-option-list" aria-label="Options for <?php echo esc_attr( $product->get_name() ); ?>">
                                                <?php foreach ( $product->get_available_variations() as $variation ) :
                                                    if ( empty( $variation['variation_is_active'] ) || empty( $variation['variation_is_visible'] ) ) { continue; }
                                                    $labels = array();
                                                    foreach ( $variation['attributes'] as $attr => $value ) { if ( $value ) { $labels[] = ucwords( str_replace( '-', ' ', $value ) ); } }
                                                    $label = implode( ' · ', $labels );
                                                    ?>
                                                    <button type="button" class="momizza-add-btn momizza-add-btn--option" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" data-variation-id="<?php echo esc_attr( $variation['variation_id'] ); ?>" data-variation="<?php echo esc_attr( wp_json_encode( $variation['attributes'] ) ); ?>">
                                                        <span><?php echo esc_html( $label ?: 'Choose' ); ?></span><strong><?php echo wp_kses_post( wc_price( $variation['display_price'] ) ); ?></strong>
                                                    </button>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php elseif ( $product->is_purchasable() && $product->is_in_stock() && '' !== $product->get_price() ) : ?>
                                            <button type="button" class="momizza-add-btn" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>">Add</button>
                                        <?php else : ?>
                                            <a class="momizza-add-btn" href="<?php echo esc_url( momizza_phone_href() ); ?>">Order</a>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </section>
                <?php endforeach; ?>
            <?php else : ?>
                <?php foreach ( $menu_data as $section ) : ?>
                    <section class="momizza-menu-section" id="<?php echo esc_attr( $section['slug'] ); ?>">
                        <h2><span><?php echo esc_html( $section['title'] ); ?></span><i></i></h2>
                        <?php if ( $section['note'] ) : ?><p class="momizza-menu-note"><?php echo esc_html( $section['note'] ); ?></p><?php endif; ?>
                        <ul>
                            <?php foreach ( $section['items'] as $item ) : ?>
                                <li class="momizza-menu-item">
                                    <div class="momizza-menu-item__text">
                                        <p class="momizza-menu-item__name"><?php echo esc_html( $item['name'] ); ?></p>
                                        <?php if ( $item['description'] ) : ?><p class="momizza-menu-item__desc"><?php echo esc_html( $item['description'] ); ?></p><?php endif; ?>
                                        <?php if ( isset( $item['price'] ) || array_key_exists( 'price', $item ) ) : ?><p class="momizza-menu-item__price"><?php echo esc_html( $item['price'] ? '₹' . $item['price'] : $item['display'] ); ?></p><?php endif; ?>
                                    </div>
                                    <div class="momizza-menu-item__actions">
                                        <?php if ( ! empty( $item['options'] ) ) : ?>
                                            <div class="momizza-option-list momizza-option-list--readonly">
                                                <?php foreach ( $item['options'] as $option ) : ?>
                                                    <span class="momizza-price-chip"><span><?php echo esc_html( $option['label'] ); ?></span><strong><?php echo esc_html( $option['display'] ); ?></strong></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else : ?>
                                            <a class="momizza-add-btn" href="<?php echo esc_url( momizza_whatsapp_url( 'Hi Momizza, I would like to order ' . $item['name'] ) ); ?>" target="_blank" rel="noopener">Order</a>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </section>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php if ( trim( get_the_content() ) ) : ?><div class="momizza-editor-content"><?php the_content(); ?></div><?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
