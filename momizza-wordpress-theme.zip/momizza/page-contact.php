<?php
/** Visit/contact page template (slug: contact). */
get_header();
if ( have_posts() ) { the_post(); }
if ( momizza_is_elementor_built() ) { the_content(); get_footer(); return; }
?>
<main class="momizza-main">
    <section class="momizza-contact momizza-container">
        <p class="momizza-eyebrow"><?php echo esc_html( momizza_opt( 'contact_eyebrow' ) ); ?></p>
        <h1>Come <span>eat with us</span></h1>
        <div class="momizza-contact-grid">
            <a class="momizza-surface-card" href="<?php echo esc_url( momizza_opt( 'map_url' ) ); ?>" target="_blank" rel="noopener">
                <?php echo momizza_svg_icon( 'map', 'momizza-card-icon' ); ?><h2>Address</h2><p><?php echo esc_html( momizza_opt( 'address' ) ); ?></p><strong>Open in maps →</strong>
            </a>
            <a class="momizza-surface-card" href="<?php echo esc_url( momizza_phone_href() ); ?>">
                <?php echo momizza_svg_icon( 'phone', 'momizza-card-icon' ); ?><h2>Order by phone</h2><p>Dine-in, takeaway and order enquiries.</p><strong><?php echo esc_html( momizza_opt( 'phone' ) ); ?></strong>
            </a>
            <div class="momizza-surface-card">
                <?php echo momizza_svg_icon( 'clock', 'momizza-card-icon' ); ?><h2>Timings</h2>
                <dl class="momizza-hours">
                    <?php foreach ( momizza_hours_rows() as $day => $hours ) : ?><div><dt><?php echo esc_html( $day ); ?></dt><dd><?php echo esc_html( $hours ); ?></dd></div><?php endforeach; ?>
                </dl>
            </div>
            <a class="momizza-surface-card" href="<?php echo esc_url( momizza_opt( 'facebook_url' ) ); ?>" target="_blank" rel="noopener">
                <?php echo momizza_svg_icon( 'globe', 'momizza-card-icon' ); ?><h2>Online</h2><p><?php echo esc_html( momizza_opt( 'tagline' ) ); ?></p><strong>Facebook →</strong>
            </a>
        </div>

        <?php $cf7 = trim( (string) momizza_opt( 'contact_form_shortcode' ) ); ?>
        <?php if ( $cf7 ) : ?>
            <div class="momizza-contact-form momizza-surface-card">
                <div><p class="momizza-eyebrow">Message us</p><h2>Send an enquiry</h2></div>
                <div><?php echo do_shortcode( $cf7 ); ?></div>
            </div>
        <?php endif; ?>
        <?php if ( trim( get_the_content() ) ) : ?><div class="momizza-editor-content"><?php the_content(); ?></div><?php endif; ?>
    </section>
</main>
<?php get_footer(); ?>
