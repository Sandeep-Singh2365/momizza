<?php
/** Footer */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<?php $momizza_elementor_footer = function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( 'footer' ); ?>
<?php if ( ! $momizza_elementor_footer ) : ?>
<footer class="momizza-footer">
    <div class="momizza-container momizza-footer__grid">
        <div>
            <img class="momizza-footer__logo" src="<?php echo esc_url( momizza_logo_url() ); ?>" alt="<?php echo esc_attr( momizza_opt( 'brand_name' ) ); ?>" width="72" height="72" loading="lazy">
            <p><?php echo esc_html( momizza_opt( 'tagline' ) ); ?></p>
        </div>
        <div>
            <h3>Find us</h3>
            <address><?php echo esc_html( momizza_opt( 'address' ) ); ?></address>
            <p><?php echo esc_html( momizza_opt( 'hours_short' ) ); ?></p>
            <a href="<?php echo esc_url( momizza_opt( 'map_url' ) ); ?>" target="_blank" rel="noopener">View on Google Maps</a>
        </div>
        <div>
            <h3>Order</h3>
            <a class="momizza-footer__phone" href="<?php echo esc_url( momizza_phone_href() ); ?>"><?php echo esc_html( momizza_opt( 'phone' ) ); ?></a>
            <a href="<?php echo esc_url( momizza_menu_pdf_url() ); ?>" download>Download menu PDF</a>
            <?php if ( momizza_opt( 'facebook_url' ) ) : ?>
                <a href="<?php echo esc_url( momizza_opt( 'facebook_url' ) ); ?>" target="_blank" rel="noopener">Facebook</a>
            <?php endif; ?>
        </div>
    </div>
    <p class="momizza-footer__bottom">© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( momizza_opt( 'brand_name' ) ); ?> · <?php echo esc_html( momizza_opt( 'location_label' ) ); ?></p>
</footer>
<?php endif; ?>
<?php
if ( class_exists( 'WooCommerce' ) && ! is_cart() && ! is_checkout() ) {
    get_template_part( 'template-parts/cart', 'drawer' );
}
wp_footer();
?>
</body>
</html>
