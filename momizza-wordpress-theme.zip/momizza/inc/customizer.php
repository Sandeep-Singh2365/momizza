<?php
/** WordPress Customizer controls. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function momizza_customize_register( $wp_customize ) {
    $defaults = momizza_defaults();

    $wp_customize->add_section(
        'momizza_business',
        array(
            'title'       => __( 'Momizza - Business Details', 'momizza' ),
            'priority'    => 30,
            'description' => __( 'Global contact information used throughout the theme. ACF Pro Options values override these when present.', 'momizza' ),
        )
    );

    $business_fields = array(
        'brand_name'     => 'Brand name',
        'location_label' => 'Header location label',
        'tagline'        => 'Tagline',
        'phone'          => 'Phone',
        'address'        => 'Address',
        'map_url'        => 'Google Maps URL',
        'facebook_url'   => 'Facebook URL',
        'hours_short'    => 'Short hours summary',
    );

    foreach ( $business_fields as $key => $label ) {
        $wp_customize->add_setting( 'momizza_' . $key, array( 'default' => $defaults[ $key ], 'sanitize_callback' => in_array( $key, array( 'map_url', 'facebook_url' ), true ) ? 'esc_url_raw' : 'sanitize_text_field' ) );
        $wp_customize->add_control( 'momizza_' . $key, array( 'section' => 'momizza_business', 'label' => __( $label, 'momizza' ), 'type' => 'text' ) );
    }

    foreach ( array( 'monday','tuesday','wednesday','thursday','friday','saturday','sunday' ) as $day ) {
        $key = 'hours_' . $day;
        $wp_customize->add_setting( 'momizza_' . $key, array( 'default' => $defaults[ $key ], 'sanitize_callback' => 'sanitize_text_field' ) );
        $wp_customize->add_control( 'momizza_' . $key, array( 'section' => 'momizza_business', 'label' => ucfirst( $day ) . ' hours', 'type' => 'text' ) );
    }

    $wp_customize->add_section( 'momizza_content', array( 'title' => __( 'Momizza - Content & Integrations', 'momizza' ), 'priority' => 31 ) );
    $text_fields = array(
        'hero_eyebrow'           => 'Hero eyebrow',
        'hero_title'             => 'Hero title line 1',
        'hero_title_accent'      => 'Hero title accent line',
        'hero_text'              => 'Hero paragraph',
        'hero_primary_label'     => 'Hero primary button label',
        'hero_secondary_label'   => 'Hero secondary button label',
        'menu_pdf_label'         => 'Menu PDF button label',
        'menu_intro_eyebrow'     => 'Menu page eyebrow',
        'menu_intro_title'       => 'Menu page title',
        'menu_intro_text'        => 'Menu page intro',
        'about_eyebrow'          => 'About eyebrow',
        'about_title'            => 'About title',
        'about_p1'               => 'About paragraph 1',
        'about_p2'               => 'About paragraph 2',
        'about_p3'               => 'About paragraph 3',
        'contact_eyebrow'        => 'Contact eyebrow',
        'contact_title'          => 'Contact title',
        'contact_form_shortcode' => 'Contact Form 7 shortcode',
    );
    foreach ( $text_fields as $key => $label ) {
        $long = in_array( $key, array( 'hero_text', 'menu_intro_text', 'about_p1', 'about_p2', 'about_p3' ), true );
        $wp_customize->add_setting( 'momizza_' . $key, array( 'default' => $defaults[ $key ], 'sanitize_callback' => $long ? 'sanitize_textarea_field' : 'sanitize_text_field' ) );
        $wp_customize->add_control( 'momizza_' . $key, array( 'section' => 'momizza_content', 'label' => __( $label, 'momizza' ), 'type' => $long ? 'textarea' : 'text' ) );
    }

    $wp_customize->add_setting( 'momizza_hero_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'momizza_hero_image', array( 'section' => 'momizza_content', 'label' => __( 'Hero image', 'momizza' ) ) ) );
    $wp_customize->add_setting( 'momizza_kitchen_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'momizza_kitchen_image', array( 'section' => 'momizza_content', 'label' => __( 'Our Story image', 'momizza' ) ) ) );
    $wp_customize->add_setting( 'momizza_menu_pdf', array( 'sanitize_callback' => 'esc_url_raw' ) );
    $wp_customize->add_control( new WP_Customize_Upload_Control( $wp_customize, 'momizza_menu_pdf', array( 'section' => 'momizza_content', 'label' => __( 'Menu PDF', 'momizza' ) ) ) );

    $wp_customize->add_section( 'momizza_theme_colors', array( 'title' => __( 'Momizza - Theme Colors', 'momizza' ), 'priority' => 32 ) );
    $colors = array(
        'primary_color'    => 'Signature red',
        'accent_color'     => 'Golden accent',
        'background_color' => 'Background',
        'card_color'       => 'Card background',
        'foreground_color' => 'Cream text',
        'muted_color'      => 'Muted text',
        'border_color'     => 'Borders',
    );
    foreach ( $colors as $key => $label ) {
        $wp_customize->add_setting( 'momizza_' . $key, array( 'default' => $defaults[ $key ], 'sanitize_callback' => 'sanitize_hex_color' ) );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'momizza_' . $key, array( 'section' => 'momizza_theme_colors', 'label' => __( $label, 'momizza' ) ) ) );
    }
}
add_action( 'customize_register', 'momizza_customize_register' );

function momizza_custom_properties() {
    $props = array(
        '--momizza-primary'    => momizza_opt( 'primary_color' ),
        '--momizza-accent'     => momizza_opt( 'accent_color' ),
        '--momizza-bg'         => momizza_opt( 'background_color' ),
        '--momizza-card'       => momizza_opt( 'card_color' ),
        '--momizza-foreground' => momizza_opt( 'foreground_color' ),
        '--momizza-muted'      => momizza_opt( 'muted_color' ),
        '--momizza-border'     => momizza_opt( 'border_color' ),
    );
    echo '<style id="momizza-custom-properties">:root{';
    foreach ( $props as $prop => $value ) {
        if ( $value ) {
            echo esc_html( $prop ) . ':' . esc_html( $value ) . ';';
        }
    }
    echo '}</style>';
}
add_action( 'wp_head', 'momizza_custom_properties', 30 );
