<?php
/** Small admin handoff page. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function momizza_admin_menu() {
    add_theme_page( 'Momizza Setup', 'Momizza Setup', 'edit_theme_options', 'momizza-setup', 'momizza_admin_page' );
}
add_action( 'admin_menu', 'momizza_admin_menu' );

function momizza_admin_page() {
    $theme = wp_get_theme();
    ?>
    <div class="wrap">
        <h1>Momizza Theme Setup</h1>
        <p><strong>Theme version:</strong> <?php echo esc_html( $theme->get( 'Version' ) ); ?></p>
        <ol>
            <li>Install and activate WooCommerce. Optional: Elementor / Elementor Pro, ACF / ACF Pro, and Contact Form 7.</li>
            <li>Import the bundled WooCommerce CSV from <code>Products → Import</code>: <code>data/momizza-woocommerce-products.csv</code>.</li>
            <li>Create or confirm pages with slugs <code>menu</code>, <code>about</code>, and <code>contact</code>. Set a static Home page in <code>Settings → Reading</code>.</li>
            <li>Set your Primary Menu in <code>Appearance → Menus</code>. If no menu is assigned, the theme shows Home, Menu, Our Story and Visit automatically.</li>
            <li>Edit global content in <code>Appearance → Customize</code>. With ACF Pro active, a richer <code>Momizza Settings</code> options page is also available.</li>
            <li>The attached menu PDF is already bundled and linked. Replace it from the Customizer or ACF Pro whenever needed.</li>
        </ol>
        <p><strong>Elementor:</strong> edit any page with Elementor to take over that page's content. Elementor Pro Theme Builder locations are registered for header/footer overrides.</p>
        <p><strong>Contact Form 7:</strong> paste a form shortcode into the Contact Form setting in the Customizer or ACF Pro options.</p>
        <p><strong>WooCommerce:</strong> Cart and Checkout are styled without overriding WooCommerce core templates, reducing breakage during Woo updates.</p>
    </div>
    <?php
}
