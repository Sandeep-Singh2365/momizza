<?php
/** Global WooCommerce cart drawer. */
if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) { return; }
$count = WC()->cart->get_cart_contents_count();
?>
<button type="button" class="momizza-floating-cart momizza-cart-trigger<?php echo $count ? '' : ' is-empty'; ?>" aria-label="Open cart">
    <span class="momizza-floating-cart__left"><?php echo momizza_svg_icon( 'bag', 'momizza-icon' ); ?> <span><span class="momizza-cart-count"><?php echo esc_html( $count ); ?></span> items</span></span>
    <span><span class="momizza-cart-total"><?php echo wp_kses_post( WC()->cart->get_cart_total() ); ?></span> · Cart</span>
</button>
<div class="momizza-cart-overlay" data-cart-overlay hidden>
    <aside class="momizza-cart-drawer" role="dialog" aria-modal="true" aria-labelledby="momizza-cart-title">
        <div class="momizza-cart-drawer__head">
            <h2 id="momizza-cart-title">Your cart</h2>
            <button type="button" class="momizza-cart-close" aria-label="Close cart"><?php echo momizza_svg_icon( 'x', 'momizza-icon' ); ?></button>
        </div>
        <div class="momizza-mini-cart" data-mini-cart>
            <?php echo function_exists( 'momizza_render_mini_cart_html' ) ? momizza_render_mini_cart_html() : ''; ?>
        </div>
        <div class="momizza-cart-drawer__actions">
            <a class="momizza-btn momizza-btn--ghost" href="<?php echo esc_url( wc_get_cart_url() ); ?>">View cart</a>
            <a class="momizza-btn momizza-btn--primary" href="<?php echo esc_url( wc_get_checkout_url() ); ?>">Checkout</a>
        </div>
    </aside>
</div>
