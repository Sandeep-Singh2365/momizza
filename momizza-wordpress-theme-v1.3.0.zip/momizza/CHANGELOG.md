# Changelog

## 1.3.0
- Added inline +/- quantity steppers inside the modal cart.
- Added automatic quantity steppers on `/menu` and homepage Counter Favourites after an item/variation is in the cart; quantities stay synchronized across repeated product controls.
- Added secure AJAX quantity updates/removal with WooCommerce stock and purchasability checks.
- Added editable **Header text beside logo** (default `MOMIZZA`) separate from the Kharar location value, and kept it visible on mobile.
- Fixed Footer Menu rendering; Home, Menu, Our Story and Visit now appear automatically when no footer menu is assigned.
- Made the footer logo link to the homepage and replaced Facebook/Instagram text links with horizontal icon buttons.
- Improved classic and WooCommerce Blocks checkout field/label contrast, filled-field surfaces and focus states.
- Rebuilt homepage Counter Favourites as direct purchase controls instead of product-page links.
- Added a layman-friendly **Momizza → Counter Favourites** admin screen to enable, remove and order up to six homepage favourites.

## 1.2.0
- Added restaurant-first Momizza Control Panel as a top-level WordPress admin area.
- Added Dashboard, Orders, Menu Products, Categories, Business Info, Opening Hours, Website & Design, Ordering, Payments, and Help & System pages.
- Added a simplified **Momizza Manager** staff role and automatic redirect to the Momizza dashboard.
- Added order search, order print support, customer call shortcut, status changes, and internal order notes.
- Added simple/variable menu item editor with image, categories, price, variation prices, per-option availability, visibility, featured state, order, and trash action.
- Added category image editing and safe category deletion.
- Added editable logo override to the simple control panel, Customizer, and ACF Pro settings.
- Added Instagram default: https://www.instagram.com/momizza2026?utm_source=qr
- Added optional automatic closing of online ordering outside restaurant opening hours.
- Added Razorpay control panel integration for the official WooCommerce gateway settings, including test/live key detection and secret masking.
- Added WooCommerce Checkout Blocks order-mode metadata compatibility.
- Confirmed paired/second pizza prices are ignored; only structured single prices are used.

## 1.0.0
- Initial WordPress/WooCommerce conversion from the supplied Lovable project.
