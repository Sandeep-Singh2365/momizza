<?php
/**
 * Momizza Control Panel — a restaurant-first admin experience layered on WordPress/WooCommerce.
 *
 * @package Momizza
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Capability used across the restaurant control panel. */
function momizza_admin_capability() {
    return class_exists( 'WooCommerce' ) ? 'manage_woocommerce' : 'manage_options';
}

/** Give a non-technical restaurant manager a focused role without full Administrator access. */
function momizza_register_manager_role() {
    $shop_manager = get_role( 'shop_manager' );
    $role         = get_role( 'momizza_manager' );

    if ( ! $role ) {
        $role = add_role( 'momizza_manager', __( 'Momizza Manager', 'momizza' ), array( 'read' => true, 'upload_files' => true ) );
    }
    if ( $role && $shop_manager ) {
        foreach ( $shop_manager->capabilities as $cap => $grant ) {
            if ( $grant ) { $role->add_cap( $cap ); }
        }
        $role->add_cap( 'upload_files' );
    }
}
add_action( 'init', 'momizza_register_manager_role', 30 );

/** True only for the simplified staff role. Administrators keep normal WordPress access. */
function momizza_is_manager_user() {
    $user = wp_get_current_user();
    return $user && in_array( 'momizza_manager', (array) $user->roles, true );
}

/** Keep the day-to-day staff interface focused on the Momizza control panel. */
function momizza_manager_simplify_admin_menu() {
    if ( ! momizza_is_manager_user() ) { return; }
    foreach ( array(
        'index.php', 'edit.php', 'upload.php', 'edit.php?post_type=page', 'edit-comments.php',
        'themes.php', 'plugins.php', 'users.php', 'tools.php', 'options-general.php',
        'edit.php?post_type=product', 'woocommerce', 'elementor', 'edit.php?post_type=elementor_library',
    ) as $slug ) {
        remove_menu_page( $slug );
    }
}
add_action( 'admin_menu', 'momizza_manager_simplify_admin_menu', 999 );

/** Send restaurant managers straight to the useful dashboard instead of WordPress Home. */
function momizza_manager_admin_redirect() {
    if ( ! is_admin() || wp_doing_ajax() || ! momizza_is_manager_user() ) { return; }
    global $pagenow;
    if ( 'index.php' === $pagenow ) {
        wp_safe_redirect( admin_url( 'admin.php?page=momizza-dashboard' ) );
        exit;
    }
}
add_action( 'admin_init', 'momizza_manager_admin_redirect', 20 );

function momizza_manager_admin_bar( $bar ) {
    if ( ! momizza_is_manager_user() ) { return; }
    foreach ( array( 'wp-logo', 'comments', 'new-content', 'updates' ) as $node ) { $bar->remove_node( $node ); }
}
add_action( 'admin_bar_menu', 'momizza_manager_admin_bar', 999 );

/** Admin menu: everything a restaurant operator needs lives under one Momizza item. */
function momizza_admin_menu() {
    $cap = momizza_admin_capability();

    add_menu_page( 'Momizza Control Panel', 'Momizza', $cap, 'momizza-dashboard', 'momizza_admin_dashboard_page', 'dashicons-food', 2 );
    add_submenu_page( 'momizza-dashboard', 'Dashboard', 'Dashboard', $cap, 'momizza-dashboard', 'momizza_admin_dashboard_page' );
    add_submenu_page( 'momizza-dashboard', 'Orders', 'Orders', $cap, 'momizza-orders', 'momizza_admin_orders_page' );
    add_submenu_page( 'momizza-dashboard', 'Menu Products', 'Menu Products', $cap, 'momizza-menu', 'momizza_admin_products_page' );
    add_submenu_page( 'momizza-dashboard', 'Counter Favourites', 'Counter Favourites', $cap, 'momizza-favourites', 'momizza_admin_favourites_page' );
    add_submenu_page( 'momizza-dashboard', 'Menu Categories', 'Categories', $cap, 'momizza-categories', 'momizza_admin_categories_page' );
    add_submenu_page( 'momizza-dashboard', 'Business Information', 'Business Info', $cap, 'momizza-business', 'momizza_admin_business_page' );
    add_submenu_page( 'momizza-dashboard', 'Restaurant Hours', 'Opening Hours', $cap, 'momizza-hours', 'momizza_admin_hours_page' );
    add_submenu_page( 'momizza-dashboard', 'Website Content', 'Website & Design', $cap, 'momizza-website', 'momizza_admin_website_page' );
    add_submenu_page( 'momizza-dashboard', 'Ordering Settings', 'Ordering', $cap, 'momizza-ordering', 'momizza_admin_ordering_page' );
    add_submenu_page( 'momizza-dashboard', 'Payments', 'Payments', $cap, 'momizza-payments', 'momizza_admin_payments_page' );
    add_submenu_page( 'momizza-dashboard', 'Help & System Check', 'Help & System', $cap, 'momizza-help', 'momizza_admin_help_page' );
}
add_action( 'admin_menu', 'momizza_admin_menu' );

/** Load our admin UI only on Momizza screens. */
function momizza_admin_assets( $hook ) {
    if ( false === strpos( (string) $hook, 'momizza' ) ) { return; }
    wp_enqueue_media();
    wp_enqueue_style( 'momizza-admin', MOMIZZA_URI . '/assets/css/admin.css', array(), MOMIZZA_VERSION );
    wp_enqueue_script( 'momizza-admin', MOMIZZA_URI . '/assets/js/admin.js', array( 'jquery' ), MOMIZZA_VERSION, true );
    wp_localize_script( 'momizza-admin', 'MomizzaAdmin', array(
        'confirmDeleteVariation' => __( 'Remove this option?', 'momizza' ),
        'confirmDeleteProduct'   => __( 'Move this menu item to trash? You can restore it later from WooCommerce if needed.', 'momizza' ),
        'confirmDeleteCategory'  => __( 'Delete this category? Products will remain, but they will no longer belong to this category.', 'momizza' ),
        'chooseImage'            => __( 'Choose image', 'momizza' ),
        'chooseFile'             => __( 'Choose file', 'momizza' ),
        'useFile'                => __( 'Use this file', 'momizza' ),
    ) );
}
add_action( 'admin_enqueue_scripts', 'momizza_admin_assets' );

/** Utility: top shell. */
function momizza_admin_header( $title, $subtitle = '' ) {
    $logo = momizza_logo_url();
    ?>
    <div class="wrap momizza-admin">
        <div class="momizza-admin__masthead">
            <div class="momizza-admin__brand">
                <img src="<?php echo esc_url( $logo ); ?>" alt="Momizza" width="54" height="54">
                <div><span>Momizza Control Panel</span><h1><?php echo esc_html( $title ); ?></h1></div>
            </div>
            <a class="momizza-admin-btn momizza-admin-btn--ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener">View website ↗</a>
        </div>
        <?php if ( $subtitle ) : ?><p class="momizza-admin__subtitle"><?php echo esc_html( $subtitle ); ?></p><?php endif; ?>
        <?php momizza_admin_notice(); ?>
    <?php
}
function momizza_admin_footer() { echo '</div>'; }

function momizza_admin_notice() {
    if ( empty( $_GET['momizza_notice'] ) ) { return; }
    $notice = sanitize_text_field( wp_unslash( $_GET['momizza_notice'] ) );
    $map = array(
        'saved'             => array( 'success', 'Saved successfully.' ),
        'product-saved'     => array( 'success', 'Menu product saved.' ),
        'product-trashed'    => array( 'success', 'Menu product moved to trash.' ),
        'category-saved'    => array( 'success', 'Category saved.' ),
        'category-deleted'  => array( 'success', 'Category deleted.' ),
        'order-updated'     => array( 'success', 'Order status updated.' ),
        'payment-saved'     => array( 'success', 'Payment settings saved.' ),
        'payment-verified'  => array( 'success', 'Razorpay settings saved and webhook verification was requested.' ),
        'error'             => array( 'error', 'Something went wrong. Please try again.' ),
    );
    if ( isset( $map[ $notice ] ) ) {
        printf( '<div class="momizza-admin-notice momizza-admin-notice--%1$s">%2$s</div>', esc_attr( $map[ $notice ][0] ), esc_html( $map[ $notice ][1] ) );
    }
}

function momizza_admin_page_url( $page, $args = array() ) {
    return add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) );
}

function momizza_admin_money( $amount ) {
    if ( function_exists( 'wc_price' ) ) { return wp_kses_post( wc_price( (float) $amount ) ); }
    return '₹' . esc_html( number_format_i18n( (float) $amount, 0 ) );
}

function momizza_admin_order_mode_value( $order ) {
    if ( ! $order || ! is_a( $order, 'WC_Order' ) ) { return ''; }
    foreach ( array( '_momizza_order_mode', '_wc_other/momizza/order-mode', 'momizza/order-mode' ) as $key ) {
        $value = $order->get_meta( $key );
        if ( $value ) { return (string) $value; }
    }
    return '';
}

/** Canonical settings store used by the simple control panel. */
function momizza_admin_settings() {
    $saved = get_option( 'momizza_settings', array() );
    return is_array( $saved ) ? $saved : array();
}

function momizza_admin_field_schema() {
    return array(
        'business' => array(
            'brand_name'       => 'text',
            'header_brand_text'=> 'text',
            'location_label'   => 'text',
            'tagline'          => 'text',
            'phone'            => 'text',
            'whatsapp_number'  => 'text',
            'email'            => 'email',
            'address'          => 'textarea',
            'map_url'          => 'url',
            'facebook_url'     => 'url',
            'instagram_url'    => 'url',
            'google_reviews_url' => 'url',
            'gstin'            => 'text',
        ),
        'website' => array(
            'logo_image'             => 'url',
            'hero_eyebrow'           => 'text',
            'hero_title'             => 'text',
            'hero_title_accent'      => 'text',
            'hero_text'              => 'textarea',
            'hero_primary_label'     => 'text',
            'hero_secondary_label'   => 'text',
            'hero_image'             => 'url',
            'menu_pdf_label'         => 'text',
            'menu_pdf'               => 'url',
            'menu_intro_eyebrow'     => 'text',
            'menu_intro_title'       => 'text',
            'menu_intro_text'        => 'textarea',
            'about_eyebrow'          => 'text',
            'about_title'            => 'text',
            'about_p1'               => 'textarea',
            'about_p2'               => 'textarea',
            'about_p3'               => 'textarea',
            'kitchen_image'          => 'url',
            'contact_eyebrow'        => 'text',
            'contact_title'          => 'text',
            'contact_form_shortcode' => 'shortcode',
            'primary_color'          => 'color',
            'accent_color'           => 'color',
            'background_color'       => 'color',
            'card_color'             => 'color',
            'foreground_color'       => 'color',
            'muted_color'            => 'color',
            'border_color'           => 'color',
        ),
        'ordering' => array(
            'accept_online_orders' => 'yesno',
            'enable_takeaway'      => 'yesno',
            'enable_dine_in'       => 'yesno',
            'enable_delivery'      => 'yesno',
            'prep_time'            => 'text',
            'delivery_note'        => 'textarea',
            'minimum_order'        => 'decimal',
            'enforce_open_hours'   => 'yesno',
        ),
    );
}

function momizza_admin_sanitize_value( $value, $type ) {
    switch ( $type ) {
        case 'email': return sanitize_email( $value );
        case 'url': return esc_url_raw( $value );
        case 'textarea': return sanitize_textarea_field( $value );
        case 'shortcode': return sanitize_text_field( $value );
        case 'color': return sanitize_hex_color( $value );
        case 'decimal': return function_exists( 'wc_format_decimal' ) ? wc_format_decimal( $value ) : (string) max( 0, (float) $value );
        case 'yesno': return 'yes' === $value ? 'yes' : 'no';
        default: return sanitize_text_field( $value );
    }
}

/** Generic settings save endpoint. */
function momizza_admin_save_settings() {
    if ( ! current_user_can( momizza_admin_capability() ) ) { wp_die( 'Not allowed.' ); }
    check_admin_referer( 'momizza_save_settings' );
    $section = isset( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : '';
    $schema  = momizza_admin_field_schema();
    if ( ! isset( $schema[ $section ] ) ) { wp_die( 'Unknown settings section.' ); }

    $saved = momizza_admin_settings();
    foreach ( $schema[ $section ] as $key => $type ) {
        $raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : ( 'yesno' === $type ? 'no' : '' );
        $saved[ $key ] = momizza_admin_sanitize_value( $raw, $type );
    }
    update_option( 'momizza_settings', $saved, false );

    $redirect = isset( $_POST['redirect_page'] ) ? sanitize_key( wp_unslash( $_POST['redirect_page'] ) ) : 'momizza-dashboard';
    wp_safe_redirect( momizza_admin_page_url( $redirect, array( 'momizza_notice' => 'saved' ) ) );
    exit;
}
add_action( 'admin_post_momizza_save_settings', 'momizza_admin_save_settings' );

/** Hours have a friendlier open/closed + time UI but retain the theme's readable strings. */
function momizza_admin_save_hours() {
    if ( ! current_user_can( momizza_admin_capability() ) ) { wp_die( 'Not allowed.' ); }
    check_admin_referer( 'momizza_save_hours' );
    $saved = momizza_admin_settings();
    $days  = array( 'monday','tuesday','wednesday','thursday','friday','saturday','sunday' );
    $short = array();
    foreach ( $days as $day ) {
        $open = isset( $_POST[ 'open_' . $day ] );
        if ( ! $open ) {
            $saved[ 'hours_' . $day ] = 'Closed';
            continue;
        }
        $from = isset( $_POST[ 'from_' . $day ] ) ? sanitize_text_field( wp_unslash( $_POST[ 'from_' . $day ] ) ) : '09:00';
        $to   = isset( $_POST[ 'to_' . $day ] ) ? sanitize_text_field( wp_unslash( $_POST[ 'to_' . $day ] ) ) : '21:00';
        $from_ts = strtotime( '2000-01-01 ' . $from );
        $to_ts   = strtotime( '2000-01-01 ' . $to );
        $saved[ 'hours_' . $day ] = ( $from_ts && $to_ts ) ? date_i18n( 'h:i A', $from_ts ) . ' - ' . date_i18n( 'h:i A', $to_ts ) : 'Closed';
        $short[] = ucfirst( substr( $day, 0, 3 ) ) . ' ' . ( $from_ts ? date_i18n( 'g A', $from_ts ) : $from ) . '-' . ( $to_ts ? date_i18n( 'g A', $to_ts ) : $to );
    }
    $saved['hours_short'] = implode( ' · ', $short );
    update_option( 'momizza_settings', $saved, false );
    wp_safe_redirect( momizza_admin_page_url( 'momizza-hours', array( 'momizza_notice' => 'saved' ) ) );
    exit;
}
add_action( 'admin_post_momizza_save_hours', 'momizza_admin_save_hours' );

function momizza_admin_parse_hours( $value ) {
    if ( ! $value || false !== stripos( $value, 'closed' ) ) { return array( false, '09:00', '21:00' ); }
    $parts = preg_split( '/\s+-\s+/', $value );
    if ( 2 !== count( $parts ) ) { return array( true, '09:00', '21:00' ); }
    return array( true, date( 'H:i', strtotime( $parts[0] ) ), date( 'H:i', strtotime( $parts[1] ) ) );
}

/** Dashboard helpers. */
function momizza_admin_order_stats() {
    $out = array( 'today_count' => 0, 'today_revenue' => 0, 'active_count' => 0, 'recent' => array() );
    if ( ! function_exists( 'wc_get_orders' ) ) { return $out; }
    $tz    = wp_timezone();
    $start = new DateTimeImmutable( 'today', $tz );
    $end   = $start->modify( '+1 day' );
    $today = wc_get_orders( array(
        'limit'        => 200,
        'date_created' => $start->format( 'Y-m-d H:i:s' ) . '...' . $end->format( 'Y-m-d H:i:s' ),
        'status'       => array_keys( wc_get_order_statuses() ),
    ) );
    foreach ( $today as $order ) {
        if ( $order->has_status( array( 'cancelled', 'failed', 'refunded' ) ) ) { continue; }
        $out['today_count']++;
        $out['today_revenue'] += (float) $order->get_total();
    }
    $active = wc_get_orders( array( 'limit' => 100, 'status' => array( 'pending', 'on-hold', 'processing' ) ) );
    $out['active_count'] = count( $active );
    $out['recent'] = wc_get_orders( array( 'limit' => 8, 'orderby' => 'date', 'order' => 'DESC' ) );
    return $out;
}

function momizza_admin_store_status() {
    $accepting = 'no' !== momizza_opt( 'accept_online_orders', 'yes' );
    if ( ! $accepting ) { return array( false, 'Online ordering paused' ); }
    $day = strtolower( wp_date( 'l' ) );
    $hours = (string) momizza_opt( 'hours_' . $day, 'Closed' );
    if ( false !== stripos( $hours, 'closed' ) ) { return array( false, 'Closed today' ); }
    $parsed = momizza_admin_parse_hours( $hours );
    $now = wp_date( 'H:i' );
    $is_open = $parsed[0] && $now >= $parsed[1] && $now <= $parsed[2];
    return array( $is_open, $is_open ? 'Open now' : 'Outside opening hours' );
}

function momizza_admin_dashboard_page() {
    momizza_admin_header( 'Dashboard', 'Today at a glance — orders, menu, payments and the fastest shortcuts.' );
    $stats = momizza_admin_order_stats();
    $products = function_exists( 'wc_get_products' ) ? wc_get_products( array( 'limit' => -1, 'return' => 'ids', 'status' => array( 'publish', 'draft' ) ) ) : array();
    list( $open, $open_label ) = momizza_admin_store_status();
    ?>
    <div class="momizza-admin-grid momizza-admin-grid--stats">
        <article class="momizza-stat"><span>Today's orders</span><strong><?php echo esc_html( $stats['today_count'] ); ?></strong><a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders' ) ); ?>">Manage orders →</a></article>
        <article class="momizza-stat"><span>Today's sales</span><strong><?php echo wp_kses_post( momizza_admin_money( $stats['today_revenue'] ) ); ?></strong><small>Excludes cancelled / failed / refunded</small></article>
        <article class="momizza-stat"><span>Needs attention</span><strong><?php echo esc_html( $stats['active_count'] ); ?></strong><small>Pending, on-hold or processing</small></article>
        <article class="momizza-stat"><span>Menu products</span><strong><?php echo esc_html( count( $products ) ); ?></strong><a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-menu' ) ); ?>">Edit menu →</a></article>
    </div>

    <div class="momizza-admin-grid momizza-admin-grid--main">
        <section class="momizza-admin-card">
            <div class="momizza-admin-card__head"><div><h2>Quick actions</h2><p>Common jobs, without hunting through WordPress.</p></div></div>
            <div class="momizza-quick-actions">
                <a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-menu', array( 'action' => 'new' ) ) ); ?>"><span class="dashicons dashicons-plus-alt2"></span><strong>Add menu item</strong><small>Name, price, options and photo</small></a>
                <a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders' ) ); ?>"><span class="dashicons dashicons-list-view"></span><strong>Open orders</strong><small>Update cooking / completed status</small></a>
                <a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-hours' ) ); ?>"><span class="dashicons dashicons-clock"></span><strong>Change timings</strong><small>Open, close or adjust a day</small></a>
                <a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-ordering' ) ); ?>"><span class="dashicons dashicons-controls-pause"></span><strong>Pause orders</strong><small>Emergency stop for online ordering</small></a>
                <a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-payments' ) ); ?>"><span class="dashicons dashicons-money-alt"></span><strong>Payment setup</strong><small>Razorpay test/live keys</small></a>
                <a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-business' ) ); ?>"><span class="dashicons dashicons-store"></span><strong>Business details</strong><small>Phone, address, maps and socials</small></a>
            </div>
        </section>

        <aside class="momizza-admin-card">
            <div class="momizza-store-status <?php echo $open ? 'is-open' : 'is-closed'; ?>"><i></i><div><small>Restaurant status</small><strong><?php echo esc_html( $open_label ); ?></strong></div></div>
            <dl class="momizza-simple-list">
                <div><dt>Location</dt><dd><?php echo esc_html( momizza_opt( 'location_label' ) ); ?></dd></div>
                <div><dt>Phone</dt><dd><?php echo esc_html( momizza_opt( 'phone' ) ); ?></dd></div>
                <div><dt>Preparation</dt><dd><?php echo esc_html( momizza_opt( 'prep_time', '25-35 min' ) ); ?></dd></div>
                <div><dt>Online orders</dt><dd><?php echo 'no' !== momizza_opt( 'accept_online_orders', 'yes' ) ? 'Enabled' : 'Paused'; ?></dd></div>
            </dl>
        </aside>
    </div>

    <section class="momizza-admin-card">
        <div class="momizza-admin-card__head"><div><h2>Recent orders</h2><p>The latest orders across all statuses.</p></div><a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders' ) ); ?>">View all →</a></div>
        <?php momizza_admin_render_orders_table( $stats['recent'], false ); ?>
    </section>
    <?php momizza_admin_footer();
}

/** Orders. */
function momizza_admin_render_orders_table( $orders, $show_actions = true ) {
    if ( ! function_exists( 'wc_get_order_statuses' ) ) { echo '<div class="momizza-empty">WooCommerce is required to manage orders.</div>'; return; }
    if ( ! $orders ) { echo '<div class="momizza-empty">No orders found.</div>'; return; }
    ?>
    <div class="momizza-table-wrap"><table class="momizza-table"><thead><tr><th>Order</th><th>Customer</th><th>Mode</th><th>Payment</th><th>Total</th><th>Status</th><th>Placed</th><?php if ( $show_actions ) : ?><th></th><?php endif; ?></tr></thead><tbody>
    <?php foreach ( $orders as $order ) :
        $mode = momizza_admin_order_mode_value( $order );
        $name = trim( $order->get_formatted_billing_full_name() );
        if ( ! $name ) { $name = 'Guest'; }
        $status = 'wc-' . $order->get_status();
        ?>
        <tr>
            <td><a class="momizza-order-link" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders', array( 'order_id' => $order->get_id() ) ) ); ?>">#<?php echo esc_html( $order->get_order_number() ); ?></a></td>
            <td><strong><?php echo esc_html( $name ); ?></strong><?php if ( $order->get_billing_phone() ) : ?><small><?php echo esc_html( $order->get_billing_phone() ); ?></small><?php endif; ?></td>
            <td><?php echo esc_html( $mode ? ucwords( str_replace( '-', ' ', $mode ) ) : '—' ); ?></td>
            <td><?php echo esc_html( $order->get_payment_method_title() ?: '—' ); ?></td>
            <td><strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong></td>
            <td><span class="momizza-status momizza-status--<?php echo esc_attr( $order->get_status() ); ?>"><?php echo esc_html( wc_get_order_status_name( $status ) ); ?></span></td>
            <td><?php echo $order->get_date_created() ? esc_html( $order->get_date_created()->date_i18n( 'd M, g:i A' ) ) : '—'; ?></td>
            <?php if ( $show_actions ) : ?><td><a class="momizza-admin-btn momizza-admin-btn--small" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders', array( 'order_id' => $order->get_id() ) ) ); ?>">Open</a></td><?php endif; ?>
        </tr>
    <?php endforeach; ?>
    </tbody></table></div>
    <?php
}

function momizza_admin_orders_page() {
    if ( ! function_exists( 'wc_get_orders' ) ) { momizza_admin_header( 'Orders' ); echo '<div class="momizza-empty">Install and activate WooCommerce first.</div>'; momizza_admin_footer(); return; }

    $order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
    if ( $order_id ) { momizza_admin_order_detail_page( $order_id ); return; }

    momizza_admin_header( 'Orders', 'See every order, open the details, and move it through the kitchen.' );
    $status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
    $search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
    $paged  = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
    $args   = array( 'limit' => 25, 'page' => $paged, 'paginate' => true, 'orderby' => 'date', 'order' => 'DESC' );
    if ( $status ) { $args['status'] = $status; }
    if ( $search && function_exists( 'wc_order_search' ) ) {
        $ids = array_values( array_filter( array_map( 'absint', (array) wc_order_search( $search ) ) ) );
        $args['include'] = $ids ? $ids : array( 0 );
    }
    $result = wc_get_orders( $args );
    ?>
    <div class="momizza-filterbar momizza-filterbar--orders">
        <div class="momizza-filterbar__tabs"><a class="<?php echo ! $status ? 'is-active' : ''; ?>" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders', $search ? array( 's' => $search ) : array() ) ); ?>">All</a>
            <?php foreach ( array( 'pending','processing','on-hold','completed','cancelled','refunded','failed' ) as $st ) : ?><a class="<?php echo $status === $st ? 'is-active' : ''; ?>" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders', array_filter( array( 'status' => $st, 's' => $search ) ) ) ); ?>"><?php echo esc_html( wc_get_order_status_name( $st ) ); ?></a><?php endforeach; ?>
        </div>
        <form method="get" class="momizza-order-search"><input type="hidden" name="page" value="momizza-orders"><?php if ( $status ) : ?><input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>"><?php endif; ?><input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Order #, name, email or phone"><button class="momizza-admin-btn" type="submit">Search</button><?php if ( $search ) : ?><a class="momizza-admin-btn" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders', $status ? array( 'status' => $status ) : array() ) ); ?>">Clear</a><?php endif; ?></form>
    </div>
    <section class="momizza-admin-card momizza-admin-card--flush">
        <?php momizza_admin_render_orders_table( $result->orders, true ); ?>
    </section>
    <?php momizza_admin_pagination( $paged, (int) $result->max_num_pages, 'momizza-orders', array_filter( array( 'status' => $status, 's' => $search ) ) ); ?>
    <?php momizza_admin_footer();
}

function momizza_admin_order_detail_page( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( ! $order ) { momizza_admin_header( 'Order not found' ); echo '<div class="momizza-empty">This order could not be found.</div>'; momizza_admin_footer(); return; }
    momizza_admin_header( 'Order #' . $order->get_order_number(), 'Placed ' . ( $order->get_date_created() ? $order->get_date_created()->date_i18n( 'd M Y, g:i A' ) : '' ) );
    $mode = momizza_admin_order_mode_value( $order );
    ?>
    <p><a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-orders' ) ); ?>">← Back to all orders</a></p>
    <div class="momizza-admin-grid momizza-admin-grid--order">
        <section class="momizza-admin-card">
            <div class="momizza-admin-card__head"><div><h2>Items</h2><p><?php echo esc_html( $order->get_item_count() ); ?> item(s)</p></div><strong class="momizza-order-total"><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong></div>
            <div class="momizza-order-items">
                <?php foreach ( $order->get_items() as $item ) :
                    $product = $item->get_product();
                    $img = $product ? $product->get_image( array( 60, 60 ) ) : '';
                    ?>
                    <div class="momizza-order-item"><div class="momizza-order-item__image"><?php echo wp_kses_post( $img ); ?></div><div><strong><?php echo esc_html( $item->get_name() ); ?></strong><small>Qty <?php echo esc_html( $item->get_quantity() ); ?></small></div><b><?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?></b></div>
                <?php endforeach; ?>
            </div>
            <dl class="momizza-simple-list momizza-simple-list--totals">
                <?php foreach ( $order->get_order_item_totals() as $total ) : ?><div><dt><?php echo wp_kses_post( $total['label'] ); ?></dt><dd><?php echo wp_kses_post( $total['value'] ); ?></dd></div><?php endforeach; ?>
            </dl>
        </section>
        <aside>
            <section class="momizza-admin-card">
                <h2>Kitchen status</h2>
                <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
                    <?php wp_nonce_field( 'momizza_update_order_' . $order_id ); ?>
                    <input type="hidden" name="action" value="momizza_update_order_status"><input type="hidden" name="order_id" value="<?php echo esc_attr( $order_id ); ?>">
                    <label class="momizza-field"><span>Status</span><select name="order_status">
                        <?php foreach ( wc_get_order_statuses() as $key => $label ) : $val = str_replace( 'wc-', '', $key ); ?><option value="<?php echo esc_attr( $val ); ?>" <?php selected( $order->get_status(), $val ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
                    </select></label>
                    <label class="momizza-field"><span>Internal note (optional)</span><textarea name="order_note" rows="3" placeholder="Example: customer called; add extra ketchup"></textarea></label>
                    <button class="momizza-admin-btn momizza-admin-btn--primary" type="submit">Update order</button>
                </form>
            </section>
            <section class="momizza-admin-card">
                <div class="momizza-admin-card__head"><div><h2>Customer & fulfilment</h2><p>Everything the counter or delivery person needs.</p></div><button type="button" class="momizza-admin-btn momizza-print-order">Print order</button></div>
                <?php if ( $order->get_billing_phone() ) : ?><a class="momizza-admin-btn momizza-admin-btn--full" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $order->get_billing_phone() ) ); ?>">Call customer · <?php echo esc_html( $order->get_billing_phone() ); ?></a><?php endif; ?>
                <dl class="momizza-simple-list">
                    <div><dt>Name</dt><dd><?php echo esc_html( $order->get_formatted_billing_full_name() ?: 'Guest' ); ?></dd></div>
                    <div><dt>Phone</dt><dd><?php echo esc_html( $order->get_billing_phone() ?: '—' ); ?></dd></div>
                    <div><dt>Email</dt><dd><?php echo esc_html( $order->get_billing_email() ?: '—' ); ?></dd></div>
                    <div><dt>Order mode</dt><dd><?php echo esc_html( $mode ? ucwords( str_replace( '-', ' ', $mode ) ) : '—' ); ?></dd></div>
                    <div><dt>Payment</dt><dd><?php echo esc_html( $order->get_payment_method_title() ?: '—' ); ?></dd></div>
                    <div><dt>Address</dt><dd><?php echo wp_kses_post( $order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address() ?: '—' ); ?></dd></div>
                </dl>
            </section>
            <?php $order_notes = function_exists( 'wc_get_order_notes' ) ? wc_get_order_notes( array( 'order_id' => $order_id, 'limit' => 8 ) ) : array(); if ( $order_notes ) : ?>
            <section class="momizza-admin-card momizza-order-notes"><h2>Recent order notes</h2><?php foreach ( $order_notes as $order_note ) : ?><article><p><?php echo wp_kses_post( wpautop( $order_note->content ) ); ?></p><small><?php echo esc_html( $order_note->date_created ? $order_note->date_created->date_i18n( 'd M, g:i A' ) : '' ); ?> · <?php echo esc_html( $order_note->added_by ?: 'System' ); ?></small></article><?php endforeach; ?></section>
            <?php endif; ?>
        </aside>
    </div>
    <?php momizza_admin_footer();
}

function momizza_admin_update_order_status() {
    if ( ! current_user_can( momizza_admin_capability() ) || ! function_exists( 'wc_get_order' ) ) { wp_die( 'Not allowed.' ); }
    $order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
    check_admin_referer( 'momizza_update_order_' . $order_id );
    $order = wc_get_order( $order_id );
    if ( ! $order ) { wp_die( 'Order not found.' ); }
    $status = isset( $_POST['order_status'] ) ? sanitize_key( wp_unslash( $_POST['order_status'] ) ) : '';
    if ( isset( wc_get_order_statuses()[ 'wc-' . $status ] ) ) { $order->update_status( $status ); }
    $note = isset( $_POST['order_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['order_note'] ) ) : '';
    if ( $note ) { $order->add_order_note( $note ); }
    wp_safe_redirect( momizza_admin_page_url( 'momizza-orders', array( 'order_id' => $order_id, 'momizza_notice' => 'order-updated' ) ) ); exit;
}
add_action( 'admin_post_momizza_update_order_status', 'momizza_admin_update_order_status' );

/** Products. */
function momizza_admin_products_page() {
    if ( ! function_exists( 'wc_get_products' ) ) { momizza_admin_header( 'Menu Products' ); echo '<div class="momizza-empty">Install and activate WooCommerce first.</div>'; momizza_admin_footer(); return; }
    $action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';
    $product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
    if ( 'new' === $action || ( 'edit' === $action && $product_id ) ) { momizza_admin_product_editor( $product_id ); return; }

    momizza_admin_header( 'Menu Products', 'Edit food items, prices, categories, photos, availability and size/combo options.' );
    $paged = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
    $search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
    $cat = isset( $_GET['category'] ) ? sanitize_title( wp_unslash( $_GET['category'] ) ) : '';
    $args = array( 'limit' => 30, 'page' => $paged, 'paginate' => true, 'status' => array( 'publish','draft','private' ), 'orderby' => 'menu_order', 'order' => 'ASC' );
    if ( $search ) { $args['s'] = $search; }
    if ( $cat ) { $args['category'] = array( $cat ); }
    $result = wc_get_products( $args );
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
    ?>
    <div class="momizza-toolbar">
        <form method="get"><input type="hidden" name="page" value="momizza-menu"><input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search menu items…"><select name="category"><option value="">All categories</option><?php foreach ( $terms as $term ) : ?><option value="<?php echo esc_attr( $term->slug ); ?>" <?php selected( $cat, $term->slug ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select><button class="momizza-admin-btn" type="submit">Filter</button></form>
        <a class="momizza-admin-btn momizza-admin-btn--primary" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-menu', array( 'action' => 'new' ) ) ); ?>">+ Add menu item</a>
    </div>
    <section class="momizza-admin-card momizza-admin-card--flush"><div class="momizza-table-wrap"><table class="momizza-table"><thead><tr><th>Item</th><th>Category</th><th>Price / options</th><th>Availability</th><th>Type</th><th></th></tr></thead><tbody>
    <?php if ( $result->products ) : foreach ( $result->products as $product ) :
        $cats = wc_get_product_category_list( $product->get_id(), ', ' );
        $price = $product->get_price_html();
        ?>
        <tr><td><div class="momizza-product-cell"><?php echo wp_kses_post( $product->get_image( array( 52,52 ) ) ); ?><div><strong><?php echo esc_html( $product->get_name() ); ?></strong><small><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $product->get_short_description() ), 10 ) ); ?></small></div></div></td>
        <td><?php echo wp_kses_post( $cats ?: 'Uncategorised' ); ?></td><td><strong><?php echo $price ? wp_kses_post( $price ) : esc_html( get_post_meta( $product->get_id(), 'momizza_display_price', true ) ?: 'No price' ); ?></strong></td>
        <td><span class="momizza-status <?php echo $product->is_in_stock() ? 'momizza-status--completed' : 'momizza-status--cancelled'; ?>"><?php echo $product->is_in_stock() ? 'Available' : 'Sold out'; ?></span><?php if ( 'publish' !== $product->get_status() ) : ?><small>Hidden from website</small><?php endif; ?></td>
        <td><?php echo esc_html( $product->is_type( 'variable' ) ? 'Options / sizes' : 'Single price' ); ?></td><td><a class="momizza-admin-btn momizza-admin-btn--small" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-menu', array( 'action' => 'edit', 'product_id' => $product->get_id() ) ) ); ?>">Edit</a></td></tr>
    <?php endforeach; else : ?><tr><td colspan="6"><div class="momizza-empty">No menu items found.</div></td></tr><?php endif; ?>
    </tbody></table></div></section>
    <?php momizza_admin_pagination( $paged, (int) $result->max_num_pages, 'momizza-menu', array_filter( array( 's' => $search, 'category' => $cat ) ) ); ?>
    <?php momizza_admin_footer();
}

function momizza_admin_product_editor( $product_id = 0 ) {
    $product = $product_id ? wc_get_product( $product_id ) : null;
    if ( $product_id && ! $product ) { momizza_admin_header( 'Menu item not found' ); echo '<div class="momizza-empty">This item could not be found.</div>'; momizza_admin_footer(); return; }
    $is_variable = $product && $product->is_type( 'variable' );
    $type = $is_variable ? 'variable' : 'simple';
    $image_id = $product ? $product->get_image_id() : 0;
    $image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'medium' ) : '';
    $cats = $product ? $product->get_category_ids() : array();
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
    $variations = array();
    if ( $is_variable ) {
        foreach ( $product->get_children() as $vid ) {
            $v = wc_get_product( $vid ); if ( ! $v ) { continue; }
            $attrs = $v->get_attributes(); $label = $attrs ? reset( $attrs ) : '';
            $variations[] = array( 'label' => $label, 'price' => $v->get_regular_price(), 'stock' => $v->is_in_stock() );
        }
    }
    momizza_admin_header( $product ? 'Edit ' . $product->get_name() : 'Add menu item', 'Keep it simple: choose a category, photo, price — or add multiple options such as Regular / Medium / Large.' );
    ?>
    <p><a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-menu' ) ); ?>">← Back to menu products</a></p>
    <form class="momizza-product-editor" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
        <?php wp_nonce_field( 'momizza_save_product' ); ?><input type="hidden" name="action" value="momizza_save_product"><input type="hidden" name="product_id" value="<?php echo esc_attr( $product_id ); ?>">
        <div class="momizza-admin-grid momizza-admin-grid--editor">
            <section>
                <div class="momizza-admin-card">
                    <h2>Basic details</h2>
                    <label class="momizza-field"><span>Item name <b>*</b></span><input type="text" name="product_name" required value="<?php echo esc_attr( $product ? $product->get_name() : '' ); ?>" placeholder="Example: Paneer Special"></label>
                    <label class="momizza-field"><span>Short description</span><textarea name="short_description" rows="3" placeholder="Ingredients or a one-line description"><?php echo esc_textarea( $product ? wp_strip_all_tags( $product->get_short_description() ) : '' ); ?></textarea></label>
                    <div class="momizza-field"><span>Category <b>*</b></span><div class="momizza-choice-grid"><?php foreach ( $terms as $term ) : ?><label><input type="checkbox" name="category_ids[]" value="<?php echo esc_attr( $term->term_id ); ?>" <?php checked( in_array( $term->term_id, $cats, true ) ); ?>><span><?php echo esc_html( $term->name ); ?></span></label><?php endforeach; ?></div><small>Need a new one? <a href="<?php echo esc_url( momizza_admin_page_url( 'momizza-categories' ) ); ?>">Add a category</a>.</small></div>
                </div>

                <div class="momizza-admin-card">
                    <h2>Pricing</h2>
                    <div class="momizza-type-switch"><label><input type="radio" name="product_type" value="simple" <?php checked( $type, 'simple' ); ?>><span><strong>Single price</strong><small>Burger, shake, momo, side, etc.</small></span></label><label><input type="radio" name="product_type" value="variable" <?php checked( $type, 'variable' ); ?>><span><strong>Multiple options</strong><small>Regular / Medium / Large, Item / Combo, etc.</small></span></label></div>
                    <div class="momizza-price-simple">
                        <label class="momizza-field"><span>Price (₹)</span><input type="number" min="0" step="0.01" name="regular_price" value="<?php echo esc_attr( $product && ! $is_variable ? $product->get_regular_price() : '' ); ?>" placeholder="149"></label>
                        <label class="momizza-field"><span>Display text when there is no fixed online price</span><input type="text" name="display_price" value="<?php echo esc_attr( $product ? get_post_meta( $product->get_id(), 'momizza_display_price', true ) : '' ); ?>" placeholder="Example: MRP or Ask for price"></label>
                    </div>
                    <div class="momizza-price-variable">
                        <p class="momizza-help-text">Each row becomes a selectable option on the menu page.</p>
                        <div id="momizza-variation-rows">
                            <?php if ( ! $variations ) { $variations[] = array( 'label' => 'Regular', 'price' => '', 'stock' => true ); } ?>
                            <?php foreach ( $variations as $row ) : ?>
                            <div class="momizza-variation-row"><input type="text" name="variation_label[]" value="<?php echo esc_attr( $row['label'] ); ?>" placeholder="Option name"><div class="momizza-money-input"><span>₹</span><input type="number" min="0" step="0.01" name="variation_price[]" value="<?php echo esc_attr( $row['price'] ); ?>" placeholder="Price"></div><select name="variation_stock[]" aria-label="Availability"><option value="1" <?php selected( ! empty( $row['stock'] ) ); ?>>Available</option><option value="0" <?php selected( empty( $row['stock'] ) ); ?>>Sold out</option></select><button type="button" class="button-link-delete momizza-remove-variation">Remove</button></div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="momizza-admin-btn" id="momizza-add-variation">+ Add another option</button>
                    </div>
                </div>
            </section>

            <aside>
                <div class="momizza-admin-card momizza-admin-card--sticky">
                    <h2>Photo & availability</h2>
                    <div class="momizza-media-picker" data-media-type="image"><div class="momizza-media-picker__preview"><?php if ( $image_url ) : ?><img src="<?php echo esc_url( $image_url ); ?>" alt=""><?php else : ?><span class="dashicons dashicons-format-image"></span><small>No photo selected</small><?php endif; ?></div><input type="hidden" name="image_id" value="<?php echo esc_attr( $image_id ); ?>"><button type="button" class="momizza-admin-btn momizza-media-picker__button">Choose photo</button><button type="button" class="button-link-delete momizza-media-picker__remove">Remove</button></div>
                    <label class="momizza-toggle"><input type="checkbox" name="in_stock" value="1" <?php checked( ! $product || $product->is_in_stock() ); ?>><span></span><div><strong>Available to order</strong><small>Turn off to mark this item sold out.</small></div></label>
                    <label class="momizza-toggle"><input type="checkbox" name="published" value="1" <?php checked( ! $product || 'publish' === $product->get_status() ); ?>><span></span><div><strong>Show on website</strong><small>Turn off to hide it without deleting it.</small></div></label>
                    <label class="momizza-toggle"><input type="checkbox" name="featured" value="1" <?php checked( $product && $product->is_featured() ); ?>><span></span><div><strong>Counter Favourite</strong><small>Turn on to make this item eligible for the homepage Counter Favourites section. Use Momizza → Counter Favourites to choose and order the final six.</small></div></label>
                    <label class="momizza-field"><span>Menu order</span><input type="number" min="0" name="menu_order" value="<?php echo esc_attr( $product ? $product->get_menu_order() : 0 ); ?>"><small>Smaller numbers appear first inside the category.</small></label>
                    <button class="momizza-admin-btn momizza-admin-btn--primary momizza-admin-btn--full" type="submit"><?php echo $product ? 'Save changes' : 'Create menu item'; ?></button>
                    <?php if ( $product ) : $delete_url = wp_nonce_url( add_query_arg( array( 'action' => 'momizza_delete_product', 'product_id' => $product->get_id() ), admin_url( 'admin-post.php' ) ), 'momizza_delete_product_' . $product->get_id() ); ?><a class="momizza-danger-link momizza-confirm-product-delete" href="<?php echo esc_url( $delete_url ); ?>">Move item to trash</a><?php endif; ?>
                </div>
            </aside>
        </div>
    </form>
    <template id="momizza-variation-template"><div class="momizza-variation-row"><input type="text" name="variation_label[]" placeholder="Option name"><div class="momizza-money-input"><span>₹</span><input type="number" min="0" step="0.01" name="variation_price[]" placeholder="Price"></div><select name="variation_stock[]" aria-label="Availability"><option value="1">Available</option><option value="0">Sold out</option></select><button type="button" class="button-link-delete momizza-remove-variation">Remove</button></div></template>
    <?php momizza_admin_footer();
}

function momizza_admin_save_product() {
    if ( ! current_user_can( momizza_admin_capability() ) || ! class_exists( 'WC_Product' ) ) { wp_die( 'Not allowed.' ); }
    check_admin_referer( 'momizza_save_product' );
    $product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
    $type = isset( $_POST['product_type'] ) && 'variable' === $_POST['product_type'] ? 'variable' : 'simple';
    $existing = $product_id ? wc_get_product( $product_id ) : null;

    if ( $existing && $existing->get_type() !== $type ) {
        wp_set_object_terms( $product_id, $type, 'product_type', false );
        clean_post_cache( $product_id );
        wc_delete_product_transients( $product_id );
        $product = 'variable' === $type ? new WC_Product_Variable( $product_id ) : new WC_Product_Simple( $product_id );
    } elseif ( $existing ) {
        $product = $existing;
    } else {
        $product = 'variable' === $type ? new WC_Product_Variable() : new WC_Product_Simple();
    }

    $name = isset( $_POST['product_name'] ) ? sanitize_text_field( wp_unslash( $_POST['product_name'] ) ) : '';
    if ( ! $name ) { wp_die( 'Item name is required.' ); }
    $product->set_name( $name );
    $product->set_short_description( isset( $_POST['short_description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['short_description'] ) ) : '' );
    $product->set_status( isset( $_POST['published'] ) ? 'publish' : 'draft' );
    $product->set_stock_status( isset( $_POST['in_stock'] ) ? 'instock' : 'outofstock' );
    $product->set_featured( isset( $_POST['featured'] ) );
    $product->set_menu_order( isset( $_POST['menu_order'] ) ? absint( $_POST['menu_order'] ) : 0 );
    $product->set_image_id( isset( $_POST['image_id'] ) ? absint( $_POST['image_id'] ) : 0 );
    $cat_ids = isset( $_POST['category_ids'] ) ? array_map( 'absint', (array) $_POST['category_ids'] ) : array();
    $product->set_category_ids( array_values( array_filter( $cat_ids ) ) );

    if ( 'simple' === $type ) {
        $price = isset( $_POST['regular_price'] ) ? wc_format_decimal( wp_unslash( $_POST['regular_price'] ) ) : '';
        $product->set_regular_price( $price ); $product->set_price( $price );
        $product->set_attributes( array() );
        $product_id = $product->save();
        if ( $existing && $existing->is_type( 'variable' ) ) { foreach ( $existing->get_children() as $vid ) { $v = wc_get_product( $vid ); if ( $v ) { $v->delete( true ); } } }
    } else {
        $labels = isset( $_POST['variation_label'] ) ? (array) wp_unslash( $_POST['variation_label'] ) : array();
        $prices = isset( $_POST['variation_price'] ) ? (array) wp_unslash( $_POST['variation_price'] ) : array();
        $stocks = isset( $_POST['variation_stock'] ) ? (array) wp_unslash( $_POST['variation_stock'] ) : array();
        $options = array(); $rows = array();
        foreach ( $labels as $i => $raw_label ) {
            $label = sanitize_text_field( $raw_label );
            $price = isset( $prices[ $i ] ) ? wc_format_decimal( $prices[ $i ] ) : '';
            if ( '' === $label ) { continue; }
            $stock = isset( $stocks[ $i ] ) && '0' === (string) $stocks[ $i ] ? false : true;
            $options[] = $label; $rows[] = array( 'label' => $label, 'price' => $price, 'stock' => $stock );
        }
        if ( ! $options ) { wp_die( 'Add at least one option for a multiple-option item.' ); }
        $attribute = new WC_Product_Attribute();
        $attribute->set_id( 0 ); $attribute->set_name( 'Option' ); $attribute->set_options( $options ); $attribute->set_position( 0 ); $attribute->set_visible( true ); $attribute->set_variation( true );
        $product->set_attributes( array( $attribute ) );
        $product_id = $product->save();

        $existing_map = array();
        foreach ( $product->get_children() as $vid ) { $v = wc_get_product( $vid ); if ( ! $v ) { continue; } $attrs = $v->get_attributes(); $label = $attrs ? reset( $attrs ) : ''; $existing_map[ strtolower( trim( $label ) ) ] = $v; }
        $kept = array();
        foreach ( $rows as $index => $row ) {
            $key = strtolower( trim( $row['label'] ) );
            $variation = isset( $existing_map[ $key ] ) ? $existing_map[ $key ] : new WC_Product_Variation();
            $variation->set_parent_id( $product_id );
            $variation->set_attributes( array( 'option' => $row['label'] ) );
            $variation->set_regular_price( $row['price'] ); $variation->set_price( $row['price'] );
            $variation->set_stock_status( isset( $_POST['in_stock'] ) && ! empty( $row['stock'] ) ? 'instock' : 'outofstock' );
            $variation->set_status( 'publish' ); $variation->set_menu_order( $index + 1 );
            $vid = $variation->save(); $kept[] = $vid;
        }
        foreach ( $product->get_children() as $vid ) { if ( ! in_array( $vid, $kept, true ) ) { $v = wc_get_product( $vid ); if ( $v ) { $v->delete( true ); } } }
        WC_Product_Variable::sync( $product_id ); wc_delete_product_transients( $product_id );
    }
    update_post_meta( $product_id, 'momizza_display_price', isset( $_POST['display_price'] ) ? sanitize_text_field( wp_unslash( $_POST['display_price'] ) ) : '' );
    wp_safe_redirect( momizza_admin_page_url( 'momizza-menu', array( 'action' => 'edit', 'product_id' => $product_id, 'momizza_notice' => 'product-saved' ) ) ); exit;
}
add_action( 'admin_post_momizza_save_product', 'momizza_admin_save_product' );

function momizza_admin_delete_product() {
    if ( ! current_user_can( momizza_admin_capability() ) ) { wp_die( 'Not allowed.' ); }
    $product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
    check_admin_referer( 'momizza_delete_product_' . $product_id );
    $product = $product_id && function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
    if ( ! $product ) { wp_die( 'Menu item not found.' ); }
    wp_trash_post( $product_id );
    wp_safe_redirect( momizza_admin_page_url( 'momizza-menu', array( 'momizza_notice' => 'product-trashed' ) ) );
    exit;
}
add_action( 'admin_post_momizza_delete_product', 'momizza_admin_delete_product' );


/** Homepage Counter Favourites — intentionally simple for non-technical staff. */
function momizza_admin_favourites_page() {
    if ( ! function_exists( 'wc_get_products' ) ) { momizza_admin_header( 'Counter Favourites' ); echo '<div class="momizza-empty">Install and activate WooCommerce first.</div>'; momizza_admin_footer(); return; }
    $products = wc_get_products( array( 'limit' => -1, 'status' => 'publish', 'orderby' => 'name', 'order' => 'ASC' ) );
    usort( $products, static function( $a, $b ) {
        $af = $a->is_featured() ? 0 : 1; $bf = $b->is_featured() ? 0 : 1;
        if ( $af !== $bf ) { return $af <=> $bf; }
        $ao = (int) get_post_meta( $a->get_id(), '_momizza_favourite_order', true );
        $bo = (int) get_post_meta( $b->get_id(), '_momizza_favourite_order', true );
        $ao = $ao > 0 ? $ao : 9999; $bo = $bo > 0 ? $bo : 9999;
        if ( $ao !== $bo ) { return $ao <=> $bo; }
        return strcasecmp( $a->get_name(), $b->get_name() );
    } );
    momizza_admin_header( 'Counter Favourites', 'Choose up to six homepage favourites. Customers can add them to cart directly — no product page opens.' );
    ?>
    <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
        <?php wp_nonce_field( 'momizza_save_favourites' ); ?><input type="hidden" name="action" value="momizza_save_favourites">
        <section class="momizza-admin-card momizza-admin-card--flush">
            <div class="momizza-table-wrap"><table class="momizza-table"><thead><tr><th>Show</th><th>Menu item</th><th>Price</th><th>Homepage order</th></tr></thead><tbody>
            <?php foreach ( $products as $product ) : $order = (int) get_post_meta( $product->get_id(), '_momizza_favourite_order', true ); ?>
                <tr>
                    <td><label class="momizza-toggle momizza-toggle--compact"><input type="checkbox" name="favourite_ids[]" value="<?php echo esc_attr( $product->get_id() ); ?>" <?php checked( $product->is_featured() ); ?>><span></span></label></td>
                    <td><div class="momizza-product-cell"><?php echo wp_kses_post( $product->get_image( array( 52,52 ) ) ); ?><div><strong><?php echo esc_html( $product->get_name() ); ?></strong><small><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $product->get_short_description() ), 10 ) ); ?></small></div></div></td>
                    <td><strong><?php echo wp_kses_post( $product->get_price_html() ?: '—' ); ?></strong></td>
                    <td><input class="momizza-favourite-order" type="number" min="1" max="99" name="favourite_order[<?php echo esc_attr( $product->get_id() ); ?>]" value="<?php echo esc_attr( $order ?: '' ); ?>" placeholder="1"><small>1 appears first. Only the first six enabled items are shown.</small></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table></div>
        </section>
        <div class="momizza-savebar"><button class="momizza-admin-btn momizza-admin-btn--primary" type="submit">Save Counter Favourites</button></div>
    </form>
    <?php momizza_admin_footer();
}

function momizza_admin_save_favourites() {
    if ( ! current_user_can( momizza_admin_capability() ) || ! function_exists( 'wc_get_products' ) ) { wp_die( 'Not allowed.' ); }
    check_admin_referer( 'momizza_save_favourites' );
    $selected = isset( $_POST['favourite_ids'] ) ? array_values( array_filter( array_map( 'absint', (array) $_POST['favourite_ids'] ) ) ) : array();
    $orders   = isset( $_POST['favourite_order'] ) ? (array) $_POST['favourite_order'] : array();
    $products = wc_get_products( array( 'limit' => -1, 'status' => array( 'publish', 'draft' ) ) );
    foreach ( $products as $product ) {
        $id = $product->get_id();
        $product->set_featured( in_array( $id, $selected, true ) );
        $product->save();
        $priority = isset( $orders[ $id ] ) ? absint( $orders[ $id ] ) : 0;
        if ( $priority ) { update_post_meta( $id, '_momizza_favourite_order', $priority ); }
        else { delete_post_meta( $id, '_momizza_favourite_order' ); }
    }
    update_option( 'momizza_favourites_configured', 'yes', false );
    wp_safe_redirect( momizza_admin_page_url( 'momizza-favourites', array( 'momizza_notice' => 'saved' ) ) );
    exit;
}
add_action( 'admin_post_momizza_save_favourites', 'momizza_admin_save_favourites' );

/** Categories. */
function momizza_admin_categories_page() {
    if ( ! taxonomy_exists( 'product_cat' ) ) { momizza_admin_header( 'Categories' ); echo '<div class="momizza-empty">WooCommerce is required.</div>'; momizza_admin_footer(); return; }
    $edit_id = isset( $_GET['term_id'] ) ? absint( $_GET['term_id'] ) : 0;
    $edit = $edit_id ? get_term( $edit_id, 'product_cat' ) : null;
    $thumb_id = $edit && ! is_wp_error( $edit ) ? absint( get_term_meta( $edit_id, 'thumbnail_id', true ) ) : 0;
    $thumb_url = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium' ) : '';
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
    $default_cat_id = absint( get_option( 'default_product_cat' ) );
    momizza_admin_header( 'Categories', 'Organise the menu into Pizza, Momos, Burgers, Drinks and any new sections you add later.' );
    ?>
    <div class="momizza-admin-grid momizza-admin-grid--categories">
        <section class="momizza-admin-card">
            <h2><?php echo $edit ? 'Edit category' : 'Add category'; ?></h2>
            <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><?php wp_nonce_field( 'momizza_save_category' ); ?><input type="hidden" name="action" value="momizza_save_category"><input type="hidden" name="term_id" value="<?php echo esc_attr( $edit_id ); ?>">
                <label class="momizza-field"><span>Category name <b>*</b></span><input type="text" name="name" required value="<?php echo esc_attr( $edit && ! is_wp_error( $edit ) ? $edit->name : '' ); ?>" placeholder="Example: Pizza Classic Range"></label>
                <label class="momizza-field"><span>Small note (optional)</span><textarea name="description" rows="3" placeholder="Example: Combo includes fries + small Coke"><?php echo esc_textarea( $edit && ! is_wp_error( $edit ) ? $edit->description : '' ); ?></textarea></label>
                <div class="momizza-media-picker" data-media-type="image"><span class="momizza-field-label">Category image</span><div class="momizza-media-picker__preview"><?php if ( $thumb_url ) : ?><img src="<?php echo esc_url( $thumb_url ); ?>" alt=""><?php else : ?><span class="dashicons dashicons-format-image"></span><small>No image selected</small><?php endif; ?></div><input type="hidden" name="thumbnail_id" value="<?php echo esc_attr( $thumb_id ); ?>"><button type="button" class="momizza-admin-btn momizza-media-picker__button">Choose image</button><button type="button" class="button-link-delete momizza-media-picker__remove">Remove</button></div>
                <button class="momizza-admin-btn momizza-admin-btn--primary" type="submit"><?php echo $edit ? 'Save category' : 'Add category'; ?></button><?php if ( $edit ) : ?> <a class="momizza-admin-btn" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-categories' ) ); ?>">Cancel</a><?php endif; ?>
            </form>
        </section>
        <section class="momizza-admin-card momizza-admin-card--flush"><div class="momizza-table-wrap"><table class="momizza-table"><thead><tr><th>Category</th><th>Products</th><th>Note</th><th></th></tr></thead><tbody><?php foreach ( $terms as $term ) : $tid = absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ); $url = $tid ? wp_get_attachment_image_url( $tid, 'thumbnail' ) : momizza_category_image_url( $term->slug ); ?><tr><td><div class="momizza-product-cell"><img src="<?php echo esc_url( $url ); ?>" alt="" width="48" height="48"><strong><?php echo esc_html( $term->name ); ?></strong></div></td><td><?php echo esc_html( $term->count ); ?></td><td><?php echo esc_html( wp_trim_words( $term->description, 12 ) ); ?></td><td><div class="momizza-row-actions"><a class="momizza-admin-btn momizza-admin-btn--small" href="<?php echo esc_url( momizza_admin_page_url( 'momizza-categories', array( 'term_id' => $term->term_id ) ) ); ?>">Edit</a><?php if ( (int) $term->term_id !== $default_cat_id ) : $delete_url = wp_nonce_url( add_query_arg( array( 'action' => 'momizza_delete_category', 'term_id' => $term->term_id ), admin_url( 'admin-post.php' ) ), 'momizza_delete_category_' . $term->term_id ); ?><a class="momizza-danger-link momizza-confirm-category-delete" href="<?php echo esc_url( $delete_url ); ?>">Delete</a><?php endif; ?></div></td></tr><?php endforeach; ?></tbody></table></div></section>
    </div>
    <?php momizza_admin_footer();
}

function momizza_admin_save_category() {
    if ( ! current_user_can( momizza_admin_capability() ) ) { wp_die( 'Not allowed.' ); }
    check_admin_referer( 'momizza_save_category' );
    $term_id = isset( $_POST['term_id'] ) ? absint( $_POST['term_id'] ) : 0;
    $name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
    $desc = isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '';
    if ( ! $name ) { wp_die( 'Category name is required.' ); }
    $result = $term_id ? wp_update_term( $term_id, 'product_cat', array( 'name' => $name, 'description' => $desc ) ) : wp_insert_term( $name, 'product_cat', array( 'description' => $desc ) );
    if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ) ); }
    $term_id = (int) $result['term_id'];
    update_term_meta( $term_id, 'thumbnail_id', isset( $_POST['thumbnail_id'] ) ? absint( $_POST['thumbnail_id'] ) : 0 );
    wp_safe_redirect( momizza_admin_page_url( 'momizza-categories', array( 'term_id' => $term_id, 'momizza_notice' => 'category-saved' ) ) ); exit;
}
add_action( 'admin_post_momizza_save_category', 'momizza_admin_save_category' );

function momizza_admin_delete_category() {
    if ( ! current_user_can( momizza_admin_capability() ) ) { wp_die( 'Not allowed.' ); }
    $term_id = isset( $_GET['term_id'] ) ? absint( $_GET['term_id'] ) : 0;
    check_admin_referer( 'momizza_delete_category_' . $term_id );
    if ( ! $term_id || $term_id === absint( get_option( 'default_product_cat' ) ) ) { wp_die( 'This category cannot be deleted.' ); }
    $result = wp_delete_term( $term_id, 'product_cat' );
    if ( is_wp_error( $result ) || ! $result ) { wp_die( 'Category could not be deleted.' ); }
    wp_safe_redirect( momizza_admin_page_url( 'momizza-categories', array( 'momizza_notice' => 'category-deleted' ) ) );
    exit;
}
add_action( 'admin_post_momizza_delete_category', 'momizza_admin_delete_category' );

/** Simple settings pages. */
function momizza_admin_business_page() {
    momizza_admin_header( 'Business Information', 'These details are used across the website, contact page and footer.' );
    ?>
    <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><?php wp_nonce_field( 'momizza_save_settings' ); ?><input type="hidden" name="action" value="momizza_save_settings"><input type="hidden" name="section" value="business"><input type="hidden" name="redirect_page" value="momizza-business">
    <div class="momizza-admin-grid momizza-admin-grid--form">
        <section class="momizza-admin-card"><h2>Restaurant details</h2>
            <?php momizza_admin_text_field( 'brand_name', 'Brand name', 'Momizza' ); momizza_admin_text_field( 'header_brand_text', 'Header text beside logo', 'MOMIZZA', 'Shown beside the logo on desktop, tablet and mobile.'); momizza_admin_text_field( 'location_label', 'Location / town', 'Kharar', 'Used for location references such as the footer.'); momizza_admin_text_field( 'tagline', 'Tagline' ); momizza_admin_text_field( 'phone', 'Main phone', '+91 96468 11102' ); momizza_admin_text_field( 'whatsapp_number', 'WhatsApp number', '+91 96468 11102', 'Leave blank to use the main phone.' ); momizza_admin_text_field( 'email', 'Business email', '', '', 'email' ); momizza_admin_textarea_field( 'address', 'Full address' ); momizza_admin_text_field( 'gstin', 'GSTIN (optional)', '', 'For your internal reference / future invoice use.' ); ?>
        </section>
        <section class="momizza-admin-card"><h2>Maps & social links</h2>
            <?php momizza_admin_text_field( 'map_url', 'Google Maps link', '', '', 'url' ); momizza_admin_text_field( 'facebook_url', 'Facebook', '', '', 'url' ); momizza_admin_text_field( 'instagram_url', 'Instagram', '', '', 'url' ); momizza_admin_text_field( 'google_reviews_url', 'Google reviews link (optional)', '', 'Useful for a future “Review us” button.', 'url' ); ?>
            <div class="momizza-admin-callout"><strong>Tip</strong><p>Paste complete links beginning with https://. The Instagram link is already pre-filled with your Momizza 2026 profile.</p></div>
        </section>
    </div><div class="momizza-savebar"><button class="momizza-admin-btn momizza-admin-btn--primary" type="submit">Save business information</button></div></form>
    <?php momizza_admin_footer();
}

function momizza_admin_hours_page() {
    momizza_admin_header( 'Opening Hours', 'Turn a day on/off and choose the opening and closing time. The website updates automatically.' );
    $days = array( 'monday','tuesday','wednesday','thursday','friday','saturday','sunday' );
    ?>
    <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><?php wp_nonce_field( 'momizza_save_hours' ); ?><input type="hidden" name="action" value="momizza_save_hours">
        <section class="momizza-admin-card"><div class="momizza-hours-grid"><div class="momizza-hours-grid__head"><span>Day</span><span>Open?</span><span>Opens</span><span>Closes</span></div>
        <?php foreach ( $days as $day ) : list( $is_open, $from, $to ) = momizza_admin_parse_hours( momizza_opt( 'hours_' . $day ) ); ?><div class="momizza-hours-row"><strong><?php echo esc_html( ucfirst( $day ) ); ?></strong><label class="momizza-toggle momizza-toggle--compact"><input type="checkbox" name="open_<?php echo esc_attr( $day ); ?>" value="1" <?php checked( $is_open ); ?>><span></span></label><input type="time" name="from_<?php echo esc_attr( $day ); ?>" value="<?php echo esc_attr( $from ); ?>"><input type="time" name="to_<?php echo esc_attr( $day ); ?>" value="<?php echo esc_attr( $to ); ?>"></div><?php endforeach; ?>
        </div></section><div class="momizza-savebar"><button class="momizza-admin-btn momizza-admin-btn--primary" type="submit">Save opening hours</button></div>
    </form>
    <?php momizza_admin_footer();
}

function momizza_admin_website_page() {
    momizza_admin_header( 'Website & Design', 'Change the words, photos, downloadable menu and Momizza theme colours without opening Elementor.' );
    ?>
    <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><?php wp_nonce_field( 'momizza_save_settings' ); ?><input type="hidden" name="action" value="momizza_save_settings"><input type="hidden" name="section" value="website"><input type="hidden" name="redirect_page" value="momizza-website">
        <div class="momizza-admin-grid momizza-admin-grid--form">
            <section>
                <div class="momizza-admin-card"><h2>Brand logo</h2><p class="momizza-help-text">Upload a replacement logo here. Leave it empty to use the WordPress Site Logo or the bundled Momizza logo.</p><?php momizza_admin_media_url_field( 'logo_image', 'Website logo', 'image' ); ?></div>
                <div class="momizza-admin-card"><h2>Homepage hero</h2><?php momizza_admin_text_field( 'hero_eyebrow', 'Small heading' ); momizza_admin_text_field( 'hero_title', 'Main title line 1' ); momizza_admin_text_field( 'hero_title_accent', 'Main title accent line' ); momizza_admin_textarea_field( 'hero_text', 'Intro paragraph' ); ?><div class="momizza-two-cols"><?php momizza_admin_text_field( 'hero_primary_label', 'Primary button' ); momizza_admin_text_field( 'hero_secondary_label', 'Secondary button' ); ?></div><?php momizza_admin_media_url_field( 'hero_image', 'Hero food image', 'image' ); ?></div>
                <div class="momizza-admin-card"><h2>Menu page & PDF</h2><?php momizza_admin_text_field( 'menu_intro_eyebrow', 'Small heading' ); momizza_admin_text_field( 'menu_intro_title', 'Menu page title' ); momizza_admin_textarea_field( 'menu_intro_text', 'Menu intro' ); momizza_admin_text_field( 'menu_pdf_label', 'PDF button label' ); momizza_admin_media_url_field( 'menu_pdf', 'Downloadable menu PDF', 'application/pdf' ); ?></div>
                <div class="momizza-admin-card"><h2>Our story</h2><?php momizza_admin_text_field( 'about_eyebrow', 'Small heading' ); momizza_admin_text_field( 'about_title', 'Title' ); momizza_admin_textarea_field( 'about_p1', 'Paragraph 1' ); momizza_admin_textarea_field( 'about_p2', 'Paragraph 2' ); momizza_admin_textarea_field( 'about_p3', 'Paragraph 3' ); momizza_admin_media_url_field( 'kitchen_image', 'Story image', 'image' ); ?></div>
            </section>
            <aside>
                <div class="momizza-admin-card"><h2>Contact page</h2><?php momizza_admin_text_field( 'contact_eyebrow', 'Small heading' ); momizza_admin_text_field( 'contact_title', 'Title' ); momizza_admin_text_field( 'contact_form_shortcode', 'Contact Form 7 shortcode', '', 'Optional. Example: [contact-form-7 id="123" title="Contact"]' ); ?></div>
                <div class="momizza-admin-card"><h2>Theme colours</h2><p class="momizza-help-text">Defaults match the existing red / gold / charcoal Momizza identity.</p><?php foreach ( array( 'primary_color'=>'Signature red','accent_color'=>'Golden accent','background_color'=>'Page background','card_color'=>'Cards','foreground_color'=>'Main text','muted_color'=>'Muted text','border_color'=>'Borders' ) as $key=>$label ) : ?><label class="momizza-field momizza-color-field"><span><?php echo esc_html( $label ); ?></span><div><input type="color" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( momizza_opt( $key ) ); ?>"><code><?php echo esc_html( momizza_opt( $key ) ); ?></code></div></label><?php endforeach; ?></div>
            </aside>
        </div><div class="momizza-savebar"><button class="momizza-admin-btn momizza-admin-btn--primary" type="submit">Save website changes</button></div>
    </form>
    <?php momizza_admin_footer();
}

function momizza_admin_ordering_page() {
    momizza_admin_header( 'Ordering', 'Control whether online orders are accepted and which fulfilment choices customers can select.' );
    ?>
    <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><?php wp_nonce_field( 'momizza_save_settings' ); ?><input type="hidden" name="action" value="momizza_save_settings"><input type="hidden" name="section" value="ordering"><input type="hidden" name="redirect_page" value="momizza-ordering">
        <div class="momizza-admin-grid momizza-admin-grid--form">
            <section class="momizza-admin-card"><h2>Online ordering</h2>
                <?php momizza_admin_toggle_field( 'accept_online_orders', 'Accept online orders', 'Turn this off in an emergency, when the kitchen is overloaded, or when you are temporarily closed.', 'yes' ); ?>
                <?php momizza_admin_toggle_field( 'enforce_open_hours', 'Automatically stop orders outside opening hours', 'When enabled, the website remains visible but add-to-cart/checkout are disabled while the restaurant is closed.', 'no' ); ?>
                <hr><h3>Customer fulfilment choices</h3>
                <?php momizza_admin_toggle_field( 'enable_takeaway', 'Takeaway', 'Customer collects the food.', 'yes' ); momizza_admin_toggle_field( 'enable_dine_in', 'Dine-in', 'Customer is ordering for the restaurant.', 'yes' ); momizza_admin_toggle_field( 'enable_delivery', 'Delivery', 'Customer wants the order delivered.', 'yes' ); ?>
            </section>
            <section class="momizza-admin-card"><h2>Order information</h2><?php momizza_admin_text_field( 'prep_time', 'Typical preparation time', '25-35 min', 'Shown in the admin dashboard and available for future customer messaging.' ); momizza_admin_text_field( 'minimum_order', 'Minimum online order (₹)', '0', '0 means no minimum.', 'number' ); momizza_admin_textarea_field( 'delivery_note', 'Delivery note', 'Delivery availability and charges may depend on the location.' ); ?>
                <div class="momizza-admin-callout"><strong>Delivery charges</strong><p>For postcode/zone-based delivery fees, use WooCommerce shipping zones. This keeps tax, checkout totals and Razorpay amounts correct.</p><?php if ( class_exists( 'WooCommerce' ) ) : ?><a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=shipping' ) ); ?>">Open delivery / shipping setup →</a><?php endif; ?></div>
            </section>
        </div><div class="momizza-savebar"><button class="momizza-admin-btn momizza-admin-btn--primary" type="submit">Save ordering settings</button></div>
    </form>
    <?php momizza_admin_footer();
}

/** Razorpay. */
function momizza_admin_razorpay_settings() {
    $settings = get_option( 'woocommerce_razorpay_settings', array() );
    return is_array( $settings ) ? $settings : array();
}
function momizza_admin_razorpay_active() {
    if ( ! class_exists( 'WooCommerce' ) ) { return false; }
    if ( class_exists( 'WC_Razorpay' ) ) { return true; }
    $active = (array) get_option( 'active_plugins', array() );
    return in_array( 'woo-razorpay/woo-razorpay.php', $active, true );
}

function momizza_admin_payments_page() {
    momizza_admin_header( 'Payments', 'Connect Razorpay for UPI, cards, NetBanking and other payment methods through WooCommerce.' );
    $active = momizza_admin_razorpay_active(); $settings = momizza_admin_razorpay_settings();
    $key_id = isset( $settings['key_id'] ) ? (string) $settings['key_id'] : '';
    $mode = 0 === strpos( $key_id, 'rzp_test_' ) ? 'Test mode' : ( 0 === strpos( $key_id, 'rzp_live_' ) ? 'Live mode' : 'Not configured' );
    ?>
    <div class="momizza-admin-grid momizza-admin-grid--form">
        <section class="momizza-admin-card">
            <div class="momizza-integration-head"><div class="momizza-integration-logo">R</div><div><h2>Razorpay Payment Gateway</h2><p>Official WooCommerce integration</p></div><span class="momizza-status <?php echo $active ? 'momizza-status--completed' : 'momizza-status--cancelled'; ?>"><?php echo $active ? 'Plugin active' : 'Plugin required'; ?></span></div>
            <?php if ( ! $active ) : ?>
                <div class="momizza-admin-callout momizza-admin-callout--warning"><strong>One-time step required</strong><p>Install and activate the official “Razorpay for WooCommerce” plugin. Your Momizza payment page will then manage its basic gateway settings here.</p><a class="momizza-admin-btn momizza-admin-btn--primary" href="<?php echo esc_url( admin_url( 'plugin-install.php?s=Razorpay%20for%20WooCommerce&tab=search&type=term' ) ); ?>">Find Razorpay plugin</a></div>
            <?php endif; ?>
            <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" autocomplete="off"><?php wp_nonce_field( 'momizza_save_payments' ); ?><input type="hidden" name="action" value="momizza_save_payments">
                <?php momizza_admin_toggle_raw( 'razorpay_enabled', 'Enable Razorpay at checkout', 'Customers can choose Razorpay only when this is enabled.', ( $settings['enabled'] ?? 'no' ) === 'yes' ); ?>
                <label class="momizza-field"><span>Key ID</span><input type="text" name="key_id" value="<?php echo esc_attr( $key_id ); ?>" placeholder="rzp_test_…" autocomplete="off"><small>Your test key normally begins with <code>rzp_test_</code>.</small></label>
                <label class="momizza-field"><span>Key Secret</span><input type="password" name="key_secret" value="" placeholder="<?php echo ! empty( $settings['key_secret'] ) ? 'Saved — leave blank to keep it' : 'Paste Key Secret'; ?>" autocomplete="new-password"><small>For security, the saved secret is never shown back on this page.</small></label>
                <label class="momizza-field"><span>Checkout title</span><input type="text" name="title" value="<?php echo esc_attr( $settings['title'] ?? 'UPI, Cards, NetBanking' ); ?>"></label>
                <label class="momizza-field"><span>Checkout description</span><textarea name="description" rows="2"><?php echo esc_textarea( $settings['description'] ?? 'Pay securely via UPI, Credit/Debit Card, or Internet Banking through Razorpay.' ); ?></textarea></label>
                <label class="momizza-field"><span>Payment action</span><select name="payment_action"><option value="capture" <?php selected( $settings['payment_action'] ?? 'capture', 'capture' ); ?>>Authorize and Capture (recommended)</option><option value="authorize" <?php selected( $settings['payment_action'] ?? 'capture', 'authorize' ); ?>>Authorize only (manual capture)</option></select><small>Automatic capture is the normal restaurant workflow.</small></label>
                <button class="momizza-admin-btn momizza-admin-btn--primary" type="submit" <?php disabled( ! $active ); ?>>Save Razorpay settings</button>
            </form>
        </section>
        <aside>
            <section class="momizza-admin-card"><h2>Connection status</h2><dl class="momizza-simple-list"><div><dt>Gateway plugin</dt><dd><?php echo $active ? 'Ready' : 'Not active'; ?></dd></div><div><dt>Key mode</dt><dd><?php echo esc_html( $mode ); ?></dd></div><div><dt>Key ID</dt><dd><?php echo $key_id ? esc_html( substr( $key_id, 0, 12 ) . '••••' ) : 'Not added'; ?></dd></div><div><dt>Secret</dt><dd><?php echo ! empty( $settings['key_secret'] ) ? 'Saved securely in WordPress' : 'Not added'; ?></dd></div><div><dt>Gateway</dt><dd><?php echo ( $settings['enabled'] ?? 'no' ) === 'yes' ? 'Enabled' : 'Disabled'; ?></dd></div></dl>
                <?php if ( $active ) : ?><a class="momizza-admin-btn momizza-admin-btn--full" href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=razorpay' ) ); ?>">Advanced Razorpay settings ↗</a><?php endif; ?>
            </section>
            <section class="momizza-admin-card"><h2>Safe test-to-live workflow</h2><ol class="momizza-steps"><li><b>1</b><span>Enter your <strong>test</strong> Key ID + Secret here.</span></li><li><b>2</b><span>Place a complete test order from the website checkout.</span></li><li><b>3</b><span>Confirm the order and payment appear in both WooCommerce and Razorpay.</span></li><li><b>4</b><span>When ready to launch, replace them with your <strong>live</strong> keys.</span></li></ol></section>
        </aside>
    </div>
    <?php momizza_admin_footer();
}

function momizza_admin_save_payments() {
    if ( ! current_user_can( momizza_admin_capability() ) ) { wp_die( 'Not allowed.' ); }
    check_admin_referer( 'momizza_save_payments' );
    if ( ! momizza_admin_razorpay_active() ) { wp_safe_redirect( momizza_admin_page_url( 'momizza-payments', array( 'momizza_notice' => 'error' ) ) ); exit; }
    $settings = momizza_admin_razorpay_settings();
    $settings['enabled'] = isset( $_POST['razorpay_enabled'] ) ? 'yes' : 'no';
    $settings['key_id']  = isset( $_POST['key_id'] ) ? sanitize_text_field( wp_unslash( $_POST['key_id'] ) ) : '';
    $new_secret = isset( $_POST['key_secret'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['key_secret'] ) ) ) : '';
    if ( '' !== $new_secret ) { $settings['key_secret'] = $new_secret; }
    $settings['title'] = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : 'UPI, Cards, NetBanking';
    $settings['description'] = isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '';
    $settings['payment_action'] = isset( $_POST['payment_action'] ) && 'authorize' === $_POST['payment_action'] ? 'authorize' : 'capture';
    update_option( 'woocommerce_razorpay_settings', $settings );

    $verified = false;
    if ( class_exists( 'WC_Razorpay' ) && ! empty( $settings['key_id'] ) && ! empty( $settings['key_secret'] ) ) {
        try {
            $gateway = new WC_Razorpay( false );
            if ( method_exists( $gateway, 'init_settings' ) ) { $gateway->init_settings(); }
            if ( method_exists( $gateway, 'autoEnableWebhook' ) ) { ob_start(); $gateway->autoEnableWebhook(); ob_end_clean(); $verified = true; }
        } catch ( Throwable $e ) { $verified = false; }
    }
    wp_safe_redirect( momizza_admin_page_url( 'momizza-payments', array( 'momizza_notice' => $verified ? 'payment-verified' : 'payment-saved' ) ) ); exit;
}
add_action( 'admin_post_momizza_save_payments', 'momizza_admin_save_payments' );

/** Help / system status. */
function momizza_admin_help_page() {
    momizza_admin_header( 'Help & System', 'A simple launch checklist plus direct links when something needs attention.' );
    $woo = class_exists( 'WooCommerce' );
    $razor = momizza_admin_razorpay_active();
    $https = is_ssl();
    $currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '';
    $menu_page = get_page_by_path( 'menu' ); $cart_id = $woo ? wc_get_page_id( 'cart' ) : 0; $checkout_id = $woo ? wc_get_page_id( 'checkout' ) : 0;
    ?>
    <div class="momizza-admin-grid momizza-admin-grid--form">
        <section class="momizza-admin-card"><h2>System check</h2><div class="momizza-health-list">
            <?php momizza_admin_health_row( 'WooCommerce', $woo, $woo ? 'Active' : 'Install WooCommerce to manage products and orders.' ); ?>
            <?php momizza_admin_health_row( 'Razorpay plugin', $razor, $razor ? 'Active' : 'Install the official Razorpay for WooCommerce plugin.' ); ?>
            <?php momizza_admin_health_row( 'Secure HTTPS', $https, $https ? 'Website is using HTTPS.' : 'Enable SSL/HTTPS before accepting live payments.' ); ?>
            <?php momizza_admin_health_row( 'Currency', 'INR' === $currency, $currency ? 'Current currency: ' . $currency : 'WooCommerce not active.' ); ?>
            <?php momizza_admin_health_row( 'Menu page', (bool) $menu_page, $menu_page ? 'Found /menu/.' : 'Create a page with slug menu.' ); ?>
            <?php momizza_admin_health_row( 'Cart page', $cart_id > 0, $cart_id > 0 ? 'Configured.' : 'WooCommerce cart page needs configuration.' ); ?>
            <?php momizza_admin_health_row( 'Checkout page', $checkout_id > 0, $checkout_id > 0 ? 'Configured.' : 'WooCommerce checkout page needs configuration.' ); ?>
        </div></section>
        <section class="momizza-admin-card"><h2>What to use for what</h2><div class="momizza-guide-cards"><article><strong>Orders</strong><p>Use Momizza → Orders for the daily kitchen workflow.</p></article><article><strong>Menu</strong><p>Use Menu Products and Categories — no need to open WooCommerce Products. Use Counter Favourites to choose the six homepage highlights.</p></article><article><strong>Business details</strong><p>Use Business Info and Opening Hours. These values update the public website.</p></article><article><strong>Website text & photos</strong><p>Use Website & Design. Elementor remains available only for advanced redesign work.</p></article><article><strong>Payments</strong><p>Use Payments for Razorpay keys. Use the advanced link only for unusual gateway settings.</p></article></div></section>
    </div>
    <section class="momizza-admin-card"><h2>Useful advanced shortcuts</h2><div class="momizza-quick-actions"><?php if ( $woo ) : ?><a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=shipping' ) ); ?>"><span class="dashicons dashicons-location"></span><strong>Delivery zones</strong><small>Charges by area / postcode</small></a><a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=tax' ) ); ?>"><span class="dashicons dashicons-media-spreadsheet"></span><strong>Taxes</strong><small>GST / WooCommerce tax settings</small></a><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=shop_coupon' ) ); ?>"><span class="dashicons dashicons-tickets-alt"></span><strong>Coupons</strong><small>Discount codes and offers</small></a><?php endif; ?><?php if ( current_user_can( 'create_users' ) ) : ?><a href="<?php echo esc_url( admin_url( 'user-new.php' ) ); ?>"><span class="dashicons dashicons-groups"></span><strong>Add staff user</strong><small>Choose “Momizza Manager” role</small></a><?php endif; ?></div></section>
    <?php momizza_admin_footer();
}

function momizza_admin_health_row( $label, $ok, $text ) { ?><div class="momizza-health-row"><span class="dashicons <?php echo $ok ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"></span><div><strong><?php echo esc_html( $label ); ?></strong><small><?php echo esc_html( $text ); ?></small></div></div><?php }

/** Field renderers. */
function momizza_admin_text_field( $key, $label, $placeholder = '', $help = '', $type = 'text' ) {
    $value = momizza_opt( $key, '' );
    ?><label class="momizza-field"><span><?php echo esc_html( $label ); ?></span><input type="<?php echo esc_attr( $type ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>" placeholder="<?php echo esc_attr( $placeholder ); ?>"><?php if ( $help ) : ?><small><?php echo esc_html( $help ); ?></small><?php endif; ?></label><?php
}
function momizza_admin_textarea_field( $key, $label, $placeholder = '' ) { ?><label class="momizza-field"><span><?php echo esc_html( $label ); ?></span><textarea name="<?php echo esc_attr( $key ); ?>" rows="4" placeholder="<?php echo esc_attr( $placeholder ); ?>"><?php echo esc_textarea( momizza_opt( $key, '' ) ); ?></textarea></label><?php }
function momizza_admin_toggle_field( $key, $label, $help, $default = 'yes' ) { momizza_admin_toggle_raw( $key, $label, $help, 'yes' === momizza_opt( $key, $default ) ); }
function momizza_admin_toggle_raw( $name, $label, $help, $checked ) { ?><label class="momizza-toggle"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="yes" <?php checked( $checked ); ?>><span></span><div><strong><?php echo esc_html( $label ); ?></strong><small><?php echo esc_html( $help ); ?></small></div></label><?php }
function momizza_admin_media_url_field( $key, $label, $mime = 'image' ) {
    $url = momizza_opt( $key, '' );
    ?><div class="momizza-media-picker momizza-media-picker--url" data-media-type="<?php echo esc_attr( $mime ); ?>"><span class="momizza-field-label"><?php echo esc_html( $label ); ?></span><div class="momizza-media-picker__preview"><?php if ( $url && 'image' === $mime ) : ?><img src="<?php echo esc_url( $url ); ?>" alt=""><?php elseif ( $url ) : ?><span class="dashicons dashicons-media-document"></span><small><?php echo esc_html( wp_basename( $url ) ); ?></small><?php else : ?><span class="dashicons <?php echo 'image' === $mime ? 'dashicons-format-image' : 'dashicons-media-document'; ?>"></span><small>No file selected</small><?php endif; ?></div><input type="hidden" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $url ); ?>"><button type="button" class="momizza-admin-btn momizza-media-picker__button">Choose <?php echo 'image' === $mime ? 'image' : 'PDF'; ?></button><button type="button" class="button-link-delete momizza-media-picker__remove">Remove</button></div><?php
}
function momizza_admin_pagination( $current, $total, $page, $args = array() ) {
    if ( $total <= 1 ) { return; }
    echo '<div class="momizza-pagination">';
    for ( $i = 1; $i <= $total; $i++ ) { $url = momizza_admin_page_url( $page, array_merge( $args, array( 'paged' => $i ) ) ); printf( '<a class="%1$s" href="%2$s">%3$d</a>', $i === $current ? 'is-current' : '', esc_url( $url ), $i ); }
    echo '</div>';
}
