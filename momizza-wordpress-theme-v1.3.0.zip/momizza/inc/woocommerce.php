<?php
/** WooCommerce integration: cart drawer, menu AJAX, wrappers and placeholders. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function momizza_woocommerce_placeholder( $src ) {
    return MOMIZZA_URI . '/assets/images/product-placeholder.jpg';
}
add_filter( 'woocommerce_placeholder_img_src', 'momizza_woocommerce_placeholder' );

function momizza_cart_identity_key( $product_id, $variation_id = 0 ) {
    return absint( $product_id ) . ':' . absint( $variation_id );
}

function momizza_cart_items_state() {
    $items = array();
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) { return $items; }
    foreach ( WC()->cart->get_cart() as $cart_key => $cart_item ) {
        $product_id   = isset( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0;
        $variation_id = isset( $cart_item['variation_id'] ) ? absint( $cart_item['variation_id'] ) : 0;
        $identity     = momizza_cart_identity_key( $product_id, $variation_id );
        $qty          = isset( $cart_item['quantity'] ) ? (int) $cart_item['quantity'] : 0;
        if ( ! isset( $items[ $identity ] ) ) {
            $items[ $identity ] = array(
                'quantity'    => 0,
                'cartKey'     => (string) $cart_key,
                'productId'   => $product_id,
                'variationId' => $variation_id,
            );
        }
        $items[ $identity ]['quantity'] += $qty;
    }
    return $items;
}

function momizza_render_mini_cart_html() {
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) { return ''; }
    ob_start();
    $cart = WC()->cart->get_cart();
    if ( $cart ) : ?>
        <ul class="woocommerce-mini-cart cart_list product_list_widget">
            <?php foreach ( $cart as $cart_key => $cart_item ) :
                $product = isset( $cart_item['data'] ) && is_a( $cart_item['data'], 'WC_Product' ) ? $cart_item['data'] : false;
                if ( ! $product || ! $product->exists() || (int) $cart_item['quantity'] < 1 ) { continue; }
                $qty = (int) $cart_item['quantity'];
                ?>
                <li class="woocommerce-mini-cart-item mini_cart_item momizza-mini-cart-item">
                    <div class="momizza-mini-cart-item__main">
                        <span class="momizza-mini-cart-item__image"><?php echo wp_kses_post( $product->get_image( array( 58, 58 ) ) ); ?></span>
                        <div class="momizza-mini-cart-item__copy">
                            <strong><?php echo esc_html( $product->get_name() ); ?></strong>
                            <?php $meta = wc_get_formatted_cart_item_data( $cart_item, true ); if ( $meta ) : ?><div class="momizza-mini-cart-item__meta"><?php echo wp_kses_post( $meta ); ?></div><?php endif; ?>
                            <span class="momizza-mini-cart-item__unit-price"><?php echo wp_kses_post( WC()->cart->get_product_price( $product ) ); ?> each</span>
                        </div>
                    </div>
                    <div class="momizza-mini-cart-item__controls">
                        <div class="momizza-cart-qty" data-cart-key="<?php echo esc_attr( $cart_key ); ?>" data-quantity="<?php echo esc_attr( $qty ); ?>" aria-label="Quantity for <?php echo esc_attr( $product->get_name() ); ?>">
                            <button type="button" class="momizza-cart-qty__btn momizza-cart-qty__btn--minus" data-delta="-1" aria-label="Decrease quantity">−</button>
                            <span class="momizza-cart-qty__value" aria-live="polite"><?php echo esc_html( $qty ); ?></span>
                            <button type="button" class="momizza-cart-qty__btn momizza-cart-qty__btn--plus" data-delta="1" aria-label="Increase quantity">+</button>
                        </div>
                        <button type="button" class="momizza-cart-remove" data-cart-key="<?php echo esc_attr( $cart_key ); ?>" aria-label="Remove <?php echo esc_attr( $product->get_name() ); ?> from cart">Remove</button>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
        <p class="woocommerce-mini-cart__total total"><strong><?php esc_html_e( 'Subtotal:', 'woocommerce' ); ?></strong> <?php echo wp_kses_post( WC()->cart->get_cart_subtotal() ); ?></p>
    <?php else : ?>
        <p class="woocommerce-mini-cart__empty-message"><?php esc_html_e( 'No products in the cart.', 'woocommerce' ); ?></p>
    <?php endif;
    return ob_get_clean();
}

function momizza_cart_state_data() {
    if ( class_exists( 'WooCommerce' ) && null === WC()->cart && function_exists( 'wc_load_cart' ) ) { wc_load_cart(); }
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
        return array( 'count' => 0, 'total' => '', 'miniCart' => '', 'items' => array() );
    }
    return array(
        'count'    => WC()->cart->get_cart_contents_count(),
        'total'    => WC()->cart->get_cart_total(),
        'miniCart' => momizza_render_mini_cart_html(),
        'items'    => momizza_cart_items_state(),
    );
}

function momizza_ajax_cart_state() {
    check_ajax_referer( 'momizza_cart', 'nonce' );
    wp_send_json_success( momizza_cart_state_data() );
}
add_action( 'wp_ajax_momizza_cart_state', 'momizza_ajax_cart_state' );
add_action( 'wp_ajax_nopriv_momizza_cart_state', 'momizza_ajax_cart_state' );

function momizza_ajax_add_to_cart() {
    check_ajax_referer( 'momizza_cart', 'nonce' );
    if ( class_exists( 'WooCommerce' ) && null === WC()->cart && function_exists( 'wc_load_cart' ) ) { wc_load_cart(); }
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
        wp_send_json_error( array( 'message' => 'WooCommerce is not available.' ), 400 );
    }

    $product_id   = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
    $variation_id = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;
    $variation    = array();

    if ( ! empty( $_POST['variation'] ) ) {
        $decoded = json_decode( wp_unslash( $_POST['variation'] ), true );
        if ( is_array( $decoded ) ) {
            foreach ( $decoded as $key => $value ) {
                $variation[ sanitize_key( $key ) ] = sanitize_text_field( $value );
            }
        }
    }

    $product = wc_get_product( $product_id );
    if ( ! $product || ! $product->is_purchasable() ) {
        wp_send_json_error( array( 'message' => 'This item is not purchasable.' ), 400 );
    }

    if ( $product->is_type( 'variable' ) && ! $variation_id ) {
        wp_send_json_error( array( 'message' => 'Please choose an option.' ), 400 );
    }

    $key = WC()->cart->add_to_cart( $product_id, 1, $variation_id, $variation );
    if ( ! $key ) {
        wp_send_json_error( array( 'message' => 'Could not add this item.' ), 400 );
    }

    WC()->cart->calculate_totals();
    wp_send_json_success( momizza_cart_state_data() );
}
add_action( 'wp_ajax_momizza_add_to_cart', 'momizza_ajax_add_to_cart' );
add_action( 'wp_ajax_nopriv_momizza_add_to_cart', 'momizza_ajax_add_to_cart' );

function momizza_ajax_update_cart_item() {
    check_ajax_referer( 'momizza_cart', 'nonce' );
    if ( class_exists( 'WooCommerce' ) && null === WC()->cart && function_exists( 'wc_load_cart' ) ) { wc_load_cart(); }
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
        wp_send_json_error( array( 'message' => 'WooCommerce is not available.' ), 400 );
    }
    $cart_key = isset( $_POST['cart_key'] ) ? wc_clean( wp_unslash( $_POST['cart_key'] ) ) : '';
    $quantity = isset( $_POST['quantity'] ) ? max( 0, absint( $_POST['quantity'] ) ) : 0;
    $cart     = WC()->cart->get_cart();
    if ( ! $cart_key || ! isset( $cart[ $cart_key ] ) ) {
        wp_send_json_error( array( 'message' => 'This cart item could not be found. Please refresh the page.' ), 404 );
    }
    $current_quantity = isset( $cart[ $cart_key ]['quantity'] ) ? (int) $cart[ $cart_key ]['quantity'] : 0;
    $product = isset( $cart[ $cart_key ]['data'] ) && is_a( $cart[ $cart_key ]['data'], 'WC_Product' ) ? $cart[ $cart_key ]['data'] : false;
    if ( $quantity > $current_quantity && $product ) {
        if ( ! $product->is_purchasable() || ! $product->is_in_stock() ) {
            wp_send_json_error( array( 'message' => 'This item is not currently available to add.' ), 400 );
        }
        $max = (int) $product->get_max_purchase_quantity();
        if ( $max > 0 && $quantity > $max ) {
            wp_send_json_error( array( 'message' => sprintf( 'The maximum available quantity is %d.', $max ) ), 400 );
        }
        if ( method_exists( $product, 'has_enough_stock' ) && ! $product->has_enough_stock( $quantity ) ) {
            wp_send_json_error( array( 'message' => 'That quantity is not currently available.' ), 400 );
        }
    }
    if ( 0 === $quantity ) {
        WC()->cart->remove_cart_item( $cart_key );
    } else {
        $result = WC()->cart->set_quantity( $cart_key, $quantity, true );
        if ( false === $result ) { wp_send_json_error( array( 'message' => 'Could not update the quantity.' ), 400 ); }
    }
    WC()->cart->calculate_totals();
    wp_send_json_success( momizza_cart_state_data() );
}
add_action( 'wp_ajax_momizza_update_cart_item', 'momizza_ajax_update_cart_item' );
add_action( 'wp_ajax_nopriv_momizza_update_cart_item', 'momizza_ajax_update_cart_item' );

/** Render one menu/home purchase control that automatically becomes a quantity stepper after adding. */
function momizza_render_purchase_control( $product, $context = 'menu' ) {
    if ( ! $product || ! is_a( $product, 'WC_Product' ) ) { return; }
    $base_class = 'momizza-purchase-control momizza-purchase-control--' . sanitize_html_class( $context );
    if ( $product->is_type( 'variable' ) ) {
        echo '<div class="momizza-option-list" aria-label="Options for ' . esc_attr( $product->get_name() ) . '">';
        foreach ( $product->get_available_variations() as $variation ) {
            if ( empty( $variation['variation_is_active'] ) || empty( $variation['variation_is_visible'] ) ) { continue; }
            $labels = array();
            foreach ( $variation['attributes'] as $attr => $value ) { if ( $value ) { $labels[] = ucwords( str_replace( '-', ' ', $value ) ); } }
            $label = implode( ' · ', $labels );
            $json  = wp_json_encode( $variation['attributes'] );
            echo '<div class="' . esc_attr( $base_class . ' momizza-purchase-control--option' ) . '" data-product-id="' . esc_attr( $product->get_id() ) . '" data-variation-id="' . esc_attr( $variation['variation_id'] ) . '" data-variation="' . esc_attr( $json ) . '">';
            echo '<button type="button" class="momizza-add-btn momizza-add-btn--option"><span>' . esc_html( $label ?: 'Choose' ) . '</span><strong>' . wp_kses_post( wc_price( $variation['display_price'] ) ) . '</strong></button>';
            echo '<div class="momizza-inline-qty" hidden><button type="button" class="momizza-inline-qty__btn" data-delta="-1" aria-label="Decrease quantity">−</button><span class="momizza-inline-qty__value" aria-live="polite">0</span><button type="button" class="momizza-inline-qty__btn" data-delta="1" aria-label="Increase quantity">+</button></div>';
            echo '</div>';
        }
        echo '</div>';
        return;
    }
    if ( $product->is_purchasable() && $product->is_in_stock() && '' !== $product->get_price() ) {
        echo '<div class="' . esc_attr( $base_class ) . '" data-product-id="' . esc_attr( $product->get_id() ) . '" data-variation-id="0" data-variation="">';
        echo '<button type="button" class="momizza-add-btn">Add</button>';
        echo '<div class="momizza-inline-qty" hidden><button type="button" class="momizza-inline-qty__btn" data-delta="-1" aria-label="Decrease quantity">−</button><span class="momizza-inline-qty__value" aria-live="polite">0</span><button type="button" class="momizza-inline-qty__btn" data-delta="1" aria-label="Increase quantity">+</button></div>';
        echo '</div>';
    } else {
        echo '<a class="momizza-add-btn" href="' . esc_url( momizza_phone_href() ) . '">Order</a>';
    }
}

function momizza_cart_fragments( $fragments ) {
    if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
        return $fragments;
    }
    $count = WC()->cart->get_cart_contents_count();
    $fragments['span.momizza-cart-count'] = '<span class="momizza-cart-count">' . esc_html( $count ) . '</span>';
    $fragments['span.momizza-cart-total'] = '<span class="momizza-cart-total">' . wp_kses_post( WC()->cart->get_cart_total() ) . '</span>';
    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'momizza_cart_fragments' );

function momizza_woocommerce_wrapper_start() {
    echo '<main class="momizza-main"><div class="momizza-container momizza-woo-container">';
}
function momizza_woocommerce_wrapper_end() {
    echo '</div></main>';
}
function momizza_change_woo_wrappers() {
    if ( ! class_exists( 'WooCommerce' ) ) { return; }
    remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
    remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
    add_action( 'woocommerce_before_main_content', 'momizza_woocommerce_wrapper_start', 10 );
    add_action( 'woocommerce_after_main_content', 'momizza_woocommerce_wrapper_end', 10 );
}
add_action( 'wp', 'momizza_change_woo_wrappers' );

function momizza_remove_woo_sidebar() {
    remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
}
add_action( 'wp', 'momizza_remove_woo_sidebar' );

function momizza_loop_thumbnail_fallback() {
    global $product;
    if ( ! $product ) { return; }
    if ( $product->get_image_id() ) {
        echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail' ) );
        return;
    }
    $terms = get_the_terms( $product->get_id(), 'product_cat' );
    $slug  = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->slug : 'product';
    printf( '<img src="%1$s" alt="%2$s" loading="lazy" width="600" height="450">', esc_url( momizza_category_image_url( $slug ) ), esc_attr( $product->get_name() ) );
}
function momizza_replace_loop_thumbnail() {
    if ( ! class_exists( 'WooCommerce' ) ) { return; }
    remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
    add_action( 'woocommerce_before_shop_loop_item_title', 'momizza_loop_thumbnail_fallback', 10 );
}
add_action( 'wp', 'momizza_replace_loop_thumbnail' );


/** Restaurant ordering controls managed from Momizza → Ordering. */
function momizza_enabled_order_modes() {
    $modes = array();
    if ( 'no' !== momizza_opt( 'enable_takeaway', 'yes' ) ) { $modes['takeaway'] = __( 'Takeaway', 'momizza' ); }
    if ( 'no' !== momizza_opt( 'enable_dine_in', 'yes' ) ) { $modes['dine-in'] = __( 'Dine-in', 'momizza' ); }
    if ( 'no' !== momizza_opt( 'enable_delivery', 'yes' ) ) { $modes['delivery'] = __( 'Delivery', 'momizza' ); }
    if ( ! $modes ) { $modes['takeaway'] = __( 'Takeaway', 'momizza' ); }
    return $modes;
}

function momizza_restaurant_is_open_now() {
    $day   = strtolower( wp_date( 'l' ) );
    $hours = trim( (string) momizza_opt( 'hours_' . $day, 'Closed' ) );
    if ( ! $hours || false !== stripos( $hours, 'closed' ) ) { return false; }
    $parts = preg_split( '/\s+-\s+/', $hours );
    if ( 2 !== count( $parts ) ) { return true; }
    try {
        $tz    = wp_timezone();
        $date  = wp_date( 'Y-m-d' );
        $opens = new DateTimeImmutable( $date . ' ' . trim( $parts[0] ), $tz );
        $closes = new DateTimeImmutable( $date . ' ' . trim( $parts[1] ), $tz );
        if ( $closes <= $opens ) { $closes = $closes->modify( '+1 day' ); }
        $now = current_datetime();
        return $now >= $opens && $now <= $closes;
    } catch ( Exception $e ) {
        return true;
    }
}

function momizza_online_ordering_available() {
    if ( 'no' === momizza_opt( 'accept_online_orders', 'yes' ) ) { return false; }
    if ( 'yes' === momizza_opt( 'enforce_open_hours', 'no' ) && ! momizza_restaurant_is_open_now() ) { return false; }
    return true;
}

/** When the kitchen pauses online ordering, keep the menu browseable but stop new cart purchases. */
function momizza_pause_purchasing( $purchasable, $product ) {
    if ( is_admin() && ! wp_doing_ajax() ) { return $purchasable; }
    return momizza_online_ordering_available() ? $purchasable : false;
}
add_filter( 'woocommerce_is_purchasable', 'momizza_pause_purchasing', 20, 2 );
add_filter( 'woocommerce_variation_is_purchasable', 'momizza_pause_purchasing', 20, 2 );

function momizza_validate_ordering_rules() {
    if ( ! momizza_online_ordering_available() ) {
        $message = ( 'yes' === momizza_opt( 'enforce_open_hours', 'no' ) && 'no' !== momizza_opt( 'accept_online_orders', 'yes' ) )
            ? __( 'Online ordering is closed outside restaurant opening hours. Please call the restaurant if you need help.', 'momizza' )
            : __( 'Online ordering is temporarily paused. Please call the restaurant to order.', 'momizza' );
        wc_add_notice( $message, 'error' );
        return;
    }
    $minimum = (float) momizza_opt( 'minimum_order', '0' );
    if ( $minimum > 0 && WC()->cart && (float) WC()->cart->get_subtotal() < $minimum ) {
        wc_add_notice( sprintf( __( 'The minimum online order is %s.', 'momizza' ), wp_strip_all_tags( wc_price( $minimum ) ) ), 'error' );
    }
}
add_action( 'woocommerce_check_cart_items', 'momizza_validate_ordering_rules' );

/** Preserve the original order-mode choice on both modern Checkout Blocks and classic checkout. */
function momizza_register_checkout_block_fields() {
    if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
        return;
    }
    woocommerce_register_additional_checkout_field(
        array(
            'id'          => 'momizza/order-mode',
            'label'       => __( 'Order mode', 'momizza' ),
            'placeholder' => __( 'Choose dine-in, takeaway or delivery', 'momizza' ),
            'location'    => 'order',
            'type'        => 'select',
            'required'    => true,
            'options'     => array_map(
                static function( $value, $label ) { return array( 'value' => $value, 'label' => $label ); },
                array_keys( momizza_enabled_order_modes() ),
                array_values( momizza_enabled_order_modes() )
            ),
        )
    );
}
add_action( 'woocommerce_init', 'momizza_register_checkout_block_fields' );

function momizza_classic_checkout_mode_field( $checkout ) {
    if ( function_exists( 'woocommerce_register_additional_checkout_field' ) && function_exists( 'has_block' ) && has_block( 'woocommerce/checkout', get_queried_object_id() ) ) {
        return;
    }
    echo '<div class="momizza-checkout-mode"><h3>' . esc_html__( 'How should we prepare your order?', 'momizza' ) . '</h3>';
    woocommerce_form_field(
        'momizza_order_mode',
        array(
            'type'     => 'select',
            'class'    => array( 'form-row-wide' ),
            'label'    => __( 'Order mode', 'momizza' ),
            'required' => true,
            'options'  => array( '' => __( 'Choose an option', 'momizza' ) ) + momizza_enabled_order_modes(),
        ),
        $checkout->get_value( 'momizza_order_mode' )
    );
    echo '</div>';
}
add_action( 'woocommerce_after_order_notes', 'momizza_classic_checkout_mode_field' );

function momizza_validate_classic_checkout_mode() {
    $mode = isset( $_POST['momizza_order_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['momizza_order_mode'] ) ) : '';
    if ( ! $mode || ! isset( momizza_enabled_order_modes()[ $mode ] ) ) {
        wc_add_notice( __( 'Please choose an available order mode.', 'momizza' ), 'error' );
    }
}
add_action( 'woocommerce_checkout_process', 'momizza_validate_classic_checkout_mode' );

function momizza_save_classic_checkout_mode( $order, $data ) {
    if ( ! empty( $_POST['momizza_order_mode'] ) ) {
        $order->update_meta_data( '_momizza_order_mode', sanitize_text_field( wp_unslash( $_POST['momizza_order_mode'] ) ) );
    }
}
add_action( 'woocommerce_checkout_create_order', 'momizza_save_classic_checkout_mode', 10, 2 );

function momizza_admin_order_mode( $order ) {
    $mode = $order->get_meta( '_momizza_order_mode' );
    if ( ! $mode ) { $mode = $order->get_meta( '_wc_other/momizza/order-mode' ); }
    if ( ! $mode ) { $mode = $order->get_meta( 'momizza/order-mode' ); }
    if ( $mode ) {
        echo '<p><strong>' . esc_html__( 'Momizza order mode:', 'momizza' ) . '</strong> ' . esc_html( ucwords( str_replace( '-', ' ', $mode ) ) ) . '</p>';
    }
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'momizza_admin_order_mode' );
