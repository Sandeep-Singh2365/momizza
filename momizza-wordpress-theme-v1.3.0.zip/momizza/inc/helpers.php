<?php
/**
 * Shared helpers and editable defaults.
 *
 * @package Momizza
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function momizza_defaults() {
    return array(
        'brand_name'              => 'Momizza',
        'header_brand_text'       => 'MOMIZZA',
        'logo_image'              => '',
        'location_label'          => 'Kharar',
        'tagline'                 => 'Wrapped Like a Momo, Loved Like a Pizza',
        'phone'                   => '+91 96468 11102',
        'address'                 => 'Shop number 31, Shivjot Enclave, near Shivjot dhaba, Guru Teg Bahadur Nagar, Kharar, Punjab 140301',
        'map_url'                 => 'https://maps.app.goo.gl/BoK2RvrEhY4MmenB6',
        'facebook_url'            => 'https://www.facebook.com/share/1BrG8Wyjr',
        'instagram_url'           => 'https://www.instagram.com/momizza2026?utm_source=qr',
        'google_reviews_url'      => '',
        'email'                   => '',
        'whatsapp_number'         => '+91 96468 11102',
        'gstin'                   => '',
        'hours_short'             => 'Mon-Thu 9 AM-9 PM · Fri 9 AM-11 PM · Sat 11 AM-5 PM · Sun closed',
        'hours_monday'            => '09:00 AM - 09:00 PM',
        'hours_tuesday'           => '09:00 AM - 09:00 PM',
        'hours_wednesday'         => '09:00 AM - 09:00 PM',
        'hours_thursday'          => '09:00 AM - 09:00 PM',
        'hours_friday'            => '09:00 AM - 11:00 PM',
        'hours_saturday'          => '11:00 AM - 05:00 PM',
        'hours_sunday'            => 'Closed',
        'hero_eyebrow'            => 'Kharar · Punjab',
        'hero_title'              => 'Wrapped like a momo,',
        'hero_title_accent'       => 'loved like a pizza',
        'hero_text'               => 'One little kitchen in Kharar, doing pizza, momos, burgers, wraps, pasta, Chinese favourites and more — hot, generous and full of flavour.',
        'hero_primary_label'      => 'Call to order',
        'hero_secondary_label'    => 'See the menu',
        'menu_pdf_label'          => 'Download Menu PDF',
        'menu_intro_eyebrow'      => 'The card',
        'menu_intro_title'        => 'Everything we wrap & fire',
        'menu_intro_text'         => 'Choose your favourites, add them to your cart, and continue to checkout. Prices are in Indian rupees.',
        'about_eyebrow'           => 'Our story',
        'about_title'             => 'Two cravings, one counter',
        'about_p1'                => 'Momizza began with a simple argument in a small kitchen: momos or pizza? The answer turned out to be both. One is folded, steamed and dipped; the other is stretched, loaded and pulled apart. Comfort and indulgence, side by side.',
        'about_p2'                => 'So we built a counter that refuses to choose. Pizza shares the pass with momos, burgers, fries, wraps, pasta, Chinese favourites, shakes and combos. Everything is made to order with fresh ingredients and plenty of cheese.',
        'about_p3'                => 'Today you can find us at Shivjot Enclave in Kharar. The plan is still simple: make the food people actually crave, serve it hot, and make it easy to come back for the same favourite next week.',
        'contact_eyebrow'         => 'Visit us',
        'contact_title'           => 'Come eat with us',
        'contact_form_shortcode'  => '',
        'primary_color'           => '#e3261b',
        'accent_color'            => '#f0c72e',
        'background_color'        => '#191715',
        'card_color'              => '#26221f',
        'foreground_color'        => '#f7f0df',
        'muted_color'             => '#b9afa3',
        'border_color'            => '#3b342f',
        'accept_online_orders'    => 'yes',
        'enable_takeaway'         => 'yes',
        'enable_dine_in'          => 'yes',
        'enable_delivery'         => 'yes',
        'prep_time'               => '25-35 min',
        'delivery_note'           => 'Delivery availability and charges may depend on the location.',
        'minimum_order'           => '0',
        'enforce_open_hours'      => 'no',
    );
}

/**
 * Get a theme option. ACF Pro Options Page wins, then Customizer, then default.
 */
function momizza_opt( $key, $fallback = null ) {
    $defaults = momizza_defaults();
    $default  = null !== $fallback ? $fallback : ( $defaults[ $key ] ?? '' );

    // The layman-friendly Momizza Control Panel is the canonical settings source.
    $panel_settings = get_option( 'momizza_settings', array() );
    if ( is_array( $panel_settings ) && array_key_exists( $key, $panel_settings ) && '' !== $panel_settings[ $key ] && null !== $panel_settings[ $key ] ) {
        return $panel_settings[ $key ];
    }

    if ( function_exists( 'get_field' ) ) {
        $acf_value = get_field( $key, 'option' );
        if ( false !== $acf_value && null !== $acf_value && '' !== $acf_value ) {
            if ( is_array( $acf_value ) && isset( $acf_value['url'] ) ) {
                return $acf_value['url'];
            }
            return $acf_value;
        }
    }

    $theme_value = get_theme_mod( 'momizza_' . $key, '' );
    return '' !== $theme_value && null !== $theme_value ? $theme_value : $default;
}

function momizza_phone_href() {
    return 'tel:+' . preg_replace( '/\D+/', '', (string) momizza_opt( 'phone' ) );
}

function momizza_whatsapp_url( $text = '' ) {
    $whatsapp = (string) momizza_opt( 'whatsapp_number', '' );
    $number = preg_replace( '/\D+/', '', $whatsapp ?: (string) momizza_opt( 'phone' ) );
    $url    = 'https://wa.me/' . $number;
    if ( $text ) {
        $url .= '?text=' . rawurlencode( $text );
    }
    return $url;
}

function momizza_menu_pdf_url() {
    $custom = momizza_opt( 'menu_pdf', '' );
    if ( $custom ) {
        return $custom;
    }
    return MOMIZZA_URI . '/assets/downloads/Momizza-Menu.pdf';
}

function momizza_logo_url() {
    $panel_logo = momizza_opt( 'logo_image', '' );
    if ( $panel_logo ) {
        return $panel_logo;
    }
    $logo_id = get_theme_mod( 'custom_logo' );
    if ( $logo_id ) {
        $url = wp_get_attachment_image_url( $logo_id, 'full' );
        if ( $url ) {
            return $url;
        }
    }
    return MOMIZZA_URI . '/assets/images/momizza-logo.png';
}

function momizza_hero_url() {
    return momizza_opt( 'hero_image', MOMIZZA_URI . '/assets/images/hero-momizza.jpg' );
}

function momizza_kitchen_url() {
    return momizza_opt( 'kitchen_image', MOMIZZA_URI . '/assets/images/kitchen-momizza.jpg' );
}

function momizza_menu_data() {
    static $data = null;
    if ( null === $data ) {
        $data = require MOMIZZA_DIR . '/inc/menu-data.php';
    }
    return $data;
}

function momizza_category_image_url( $slug ) {
    $slug = sanitize_title( $slug );
    $file = MOMIZZA_DIR . '/assets/images/categories/' . $slug . '.jpg';
    if ( file_exists( $file ) ) {
        return MOMIZZA_URI . '/assets/images/categories/' . $slug . '.jpg';
    }
    return MOMIZZA_URI . '/assets/images/product-placeholder.jpg';
}

function momizza_is_elementor_built( $post_id = null ) {
    $post_id = $post_id ?: get_the_ID();
    if ( ! $post_id || ! did_action( 'elementor/loaded' ) ) {
        return false;
    }
    return 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true ) || (bool) get_post_meta( $post_id, '_elementor_data', true );
}

function momizza_hours_rows() {
    return array(
        'Monday'    => momizza_opt( 'hours_monday' ),
        'Tuesday'   => momizza_opt( 'hours_tuesday' ),
        'Wednesday' => momizza_opt( 'hours_wednesday' ),
        'Thursday'  => momizza_opt( 'hours_thursday' ),
        'Friday'    => momizza_opt( 'hours_friday' ),
        'Saturday'  => momizza_opt( 'hours_saturday' ),
        'Sunday'    => momizza_opt( 'hours_sunday' ),
    );
}

function momizza_svg_icon( $name, $class = '' ) {
    $class = esc_attr( $class );
    $icons = array(
        'menu' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
        'x' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M6 6l12 12M18 6L6 18"/></svg>',
        'phone' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.78 19.78 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.78 19.78 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.78.62 2.63a2 2 0 0 1-.45 2.11L8 9.73a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.85.29 1.73.5 2.63.62A2 2 0 0 1 22 16.92z"/></svg>',
        'bag' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M6 8h12l1 13H5L6 8zM9 8a3 3 0 0 1 6 0"/></svg>',
        'flame' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M12 22c4 0 7-2.7 7-6.5 0-3.2-2-5.6-5.1-8.8.1 2.4-1.2 3.9-2.4 4.8.2-3.8-2.2-6.4-4.4-8.5.1 3.2-2.1 5.3-2.1 8.9C5 18 8 22 12 22z"/></svg>',
        'leaf' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M20 4c-7 0-12 2-14 6-2.3 4.6 1.2 8.5 5 8 5-.6 7.5-6 9-14zM5 20c2.6-4.4 6-7.3 11-9"/></svg>',
        'clock' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
        'map' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2.5"/></svg>',
        'globe' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>',
        'facebook' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M14 8h3V4h-3c-3 0-5 2-5 5v3H7v4h3v5h4v-5h3l1-4h-4V9c0-.7.3-1 1-1z"/></svg>',
        'instagram' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h.01"/></svg>',
        'download' => '<svg viewBox="0 0 24 24" aria-hidden="true" class="' . $class . '"><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></svg>',
    );
    return $icons[ $name ] ?? '';
}
