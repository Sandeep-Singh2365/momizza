<?php
/** Front page */
get_header();
if ( have_posts() ) { the_post(); }
if ( momizza_is_elementor_built() ) {
    the_content();
    get_footer();
    return;
}
?>
<main class="momizza-main">
    <section class="momizza-hero">
        <img class="momizza-hero__image" src="<?php echo esc_url( momizza_hero_url() ); ?>" alt="Fresh Momizza food" width="1600" height="1104" fetchpriority="high">
        <div class="momizza-hero__veil"></div>
        <div class="momizza-container momizza-hero__content">
            <img class="momizza-hero__logo" src="<?php echo esc_url( momizza_logo_url() ); ?>" alt="<?php echo esc_attr( momizza_opt( 'brand_name' ) ); ?> logo" width="160" height="160">
            <p class="momizza-eyebrow"><?php echo esc_html( momizza_opt( 'hero_eyebrow' ) ); ?></p>
            <h1><?php echo esc_html( momizza_opt( 'hero_title' ) ); ?><br><span><?php echo esc_html( momizza_opt( 'hero_title_accent' ) ); ?></span></h1>
            <p class="momizza-hero__copy"><?php echo esc_html( momizza_opt( 'hero_text' ) ); ?></p>
            <div class="momizza-hero__actions">
                <a class="momizza-btn momizza-btn--primary momizza-btn--large" href="<?php echo esc_url( momizza_phone_href() ); ?>"><?php echo esc_html( momizza_opt( 'hero_primary_label' ) ); ?></a>
                <a class="momizza-btn momizza-btn--outline momizza-btn--large" href="<?php echo esc_url( home_url( '/menu/' ) ); ?>"><?php echo esc_html( momizza_opt( 'hero_secondary_label' ) ); ?></a>
            </div>
        </div>
    </section>

    <section class="momizza-strip">
        <div class="momizza-container momizza-strip__grid">
            <article><?php echo momizza_svg_icon( 'flame', 'momizza-strip__icon' ); ?><div><h3>Made to order</h3><p>Freshly prepared when you ask.</p></div></article>
            <article><?php echo momizza_svg_icon( 'leaf', 'momizza-strip__icon' ); ?><div><h3>Fresh ingredients</h3><p>100% real cheese · made with love.</p></div></article>
            <article><?php echo momizza_svg_icon( 'clock', 'momizza-strip__icon' ); ?><div><h3>Open 6 days</h3><p><?php echo esc_html( momizza_opt( 'hours_short' ) ); ?></p></div></article>
        </div>
    </section>

    <section class="momizza-section momizza-container">
        <div class="momizza-section-head">
            <h2>Counter <span>favourites</span></h2>
            <a href="<?php echo esc_url( home_url( '/menu/' ) ); ?>">Full menu →</a>
        </div>
        <div class="momizza-favourites">
            <?php
            $rendered = false;
            if ( class_exists( 'WooCommerce' ) ) {
                $all_products = wc_get_products( array( 'limit' => -1, 'status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC' ) );
                $products = array_values( array_filter( $all_products, static function( $product ) { return $product->is_featured(); } ) );
                if ( ! $products && 'yes' !== get_option( 'momizza_favourites_configured', '' ) ) {
                    $products = array_slice( $all_products, 0, 6 );
                }
                usort( $products, static function( $a, $b ) {
                    $ao = (int) get_post_meta( $a->get_id(), '_momizza_favourite_order', true );
                    $bo = (int) get_post_meta( $b->get_id(), '_momizza_favourite_order', true );
                    $ao = $ao > 0 ? $ao : 9999; $bo = $bo > 0 ? $bo : 9999;
                    if ( $ao !== $bo ) { return $ao <=> $bo; }
                    if ( $a->get_menu_order() !== $b->get_menu_order() ) { return $a->get_menu_order() <=> $b->get_menu_order(); }
                    return strcasecmp( $a->get_name(), $b->get_name() );
                } );
                $products = array_slice( $products, 0, 6 );
                if ( $products ) {
                    $rendered = true;
                    foreach ( $products as $product ) {
                        ?>
                        <article class="momizza-favourite-card">
                            <div class="momizza-favourite-card__top">
                                <span><?php echo esc_html( $product->get_name() ); ?></span>
                                <?php $favourite_price = $product->get_price_html(); if ( ! $favourite_price ) { $favourite_price = get_post_meta( $product->get_id(), 'momizza_display_price', true ); } ?>
                                <strong><?php echo $favourite_price ? wp_kses_post( $favourite_price ) : esc_html__( 'Ask', 'momizza' ); ?></strong>
                            </div>
                            <div class="momizza-favourite-card__actions">
                                <?php momizza_render_purchase_control( $product, 'favourite' ); ?>
                            </div>
                        </article>
                        <?php
                    }
                }
            }
            if ( ! $rendered && 'yes' !== get_option( 'momizza_favourites_configured', '' ) ) {
                $fallback = array(
                    array( 'Double Cheese Margherita', '₹189+' ),
                    array( 'Paneer Special', '₹239+' ),
                    array( 'Veg Momo', '₹100' ),
                    array( 'Cheese Kurkure Momo', '₹225' ),
                    array( 'Aloo Tikki Burger', '₹39+' ),
                    array( 'Veg Fried Rice + Manchurian', '₹229' ),
                );
                foreach ( $fallback as $item ) {
                    echo '<a class="momizza-favourite-card" href="' . esc_url( home_url( '/menu/' ) ) . '"><span>' . esc_html( $item[0] ) . '</span><strong>' . esc_html( $item[1] ) . '</strong></a>';
                }
            }
            ?>
        </div>
        <?php if ( trim( get_the_content() ) ) : ?><div class="momizza-editor-content"><?php the_content(); ?></div><?php endif; ?>
    </section>

    <section class="momizza-cta">
        <div class="momizza-container momizza-cta__inner">
            <h2>Hungry now?</h2>
            <p>Ring the kitchen and we’ll start cooking. Dine-in, takeaway and delivery options can be managed through WooCommerce.</p>
            <a class="momizza-btn momizza-btn--primary momizza-btn--large" href="<?php echo esc_url( momizza_phone_href() ); ?>"><?php echo esc_html( momizza_opt( 'phone' ) ); ?></a>
        </div>
    </section>
</main>
<?php get_footer(); ?>
