(function ($) {
  'use strict';

  const cfg = window.MomizzaConfig || {};
  const q = (s, c = document) => c.querySelector(s);
  const qa = (s, c = document) => Array.from(c.querySelectorAll(s));

  function initMobileNav() {
    const button = q('.momizza-menu-toggle');
    const nav = q('#momizza-mobile-nav');
    if (!button || !nav) return;
    button.addEventListener('click', () => {
      const open = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!open));
      nav.hidden = open;
    });
    qa('a', nav).forEach((link) => link.addEventListener('click', () => {
      button.setAttribute('aria-expanded', 'false');
      nav.hidden = true;
    }));
  }

  function initCategoryScroll() {
    qa('.momizza-category-nav a').forEach((link) => {
      link.addEventListener('click', (event) => {
        const id = link.getAttribute('href');
        if (!id || id.charAt(0) !== '#') return;
        const target = q(id);
        if (!target) return;
        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        history.replaceState(null, '', id);
      });
    });
  }

  function setCartOpen(open) {
    const overlay = q('[data-cart-overlay]');
    if (!overlay) return;
    overlay.hidden = !open;
    document.body.classList.toggle('momizza-cart-open', open);
    if (open) {
      const close = q('.momizza-cart-close', overlay);
      if (close) setTimeout(() => close.focus(), 20);
    }
  }

  function initCartDrawer() {
    document.addEventListener('click', (event) => {
      const trigger = event.target.closest('.momizza-cart-trigger');
      if (trigger) {
        event.preventDefault();
        setCartOpen(true);
        return;
      }
      const close = event.target.closest('.momizza-cart-close');
      if (close) {
        event.preventDefault();
        setCartOpen(false);
        return;
      }
      const overlay = event.target.matches('[data-cart-overlay]') ? event.target : null;
      if (overlay) setCartOpen(false);
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') setCartOpen(false);
    });
  }

  function controlIdentity(control) {
    if (!control) return '';
    return `${parseInt(control.dataset.productId || '0', 10)}:${parseInt(control.dataset.variationId || '0', 10)}`;
  }

  function syncPurchaseControls(items) {
    const cartItems = items || {};
    qa('.momizza-purchase-control').forEach((control) => {
      const item = cartItems[controlIdentity(control)];
      const add = q('.momizza-add-btn', control);
      const stepper = q('.momizza-inline-qty', control);
      const value = q('.momizza-inline-qty__value', control);
      if (item && Number(item.quantity) > 0) {
        control.dataset.cartKey = item.cartKey || '';
        control.dataset.quantity = String(item.quantity);
        if (add) add.hidden = true;
        if (stepper) stepper.hidden = false;
        if (value) value.textContent = String(item.quantity);
        control.classList.add('has-quantity');
      } else {
        delete control.dataset.cartKey;
        control.dataset.quantity = '0';
        if (add) add.hidden = false;
        if (stepper) stepper.hidden = true;
        if (value) value.textContent = '0';
        control.classList.remove('has-quantity');
      }
    });
  }

  function applyCartState(state) {
    if (!state) return;
    qa('.momizza-cart-count').forEach((el) => { el.textContent = String(state.count || 0); });
    qa('.momizza-cart-total').forEach((el) => { el.innerHTML = state.total || ''; });
    const floating = q('.momizza-floating-cart');
    if (floating) floating.classList.toggle('is-empty', !state.count);
    const mini = q('[data-mini-cart]');
    if (mini && typeof state.miniCart === 'string') mini.innerHTML = state.miniCart;
    syncPurchaseControls(state.items || {});
  }

  async function postAjax(action, data) {
    const body = new URLSearchParams({ action, nonce: cfg.nonce || '', ...data });
    const response = await fetch(cfg.ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    });
    const json = await response.json();
    if (!json || !json.success) {
      const msg = json && json.data && json.data.message ? json.data.message : (cfg.errorText || 'Something went wrong.');
      throw new Error(msg);
    }
    return json.data;
  }

  function initMenuAddToCart() {
    if (!cfg.wooActive) return;
    document.addEventListener('click', async (event) => {
      const button = event.target.closest('.momizza-purchase-control .momizza-add-btn');
      if (!button) return;
      const control = button.closest('.momizza-purchase-control');
      if (!control || control.classList.contains('is-busy')) return;
      event.preventDefault();
      const original = button.innerHTML;
      control.classList.add('is-busy');
      button.textContent = cfg.addingText || 'Adding…';
      try {
        const state = await postAjax('momizza_add_to_cart', {
          product_id: control.dataset.productId || '',
          variation_id: control.dataset.variationId || '',
          variation: control.dataset.variation || ''
        });
        button.innerHTML = original;
        applyCartState(state);
      } catch (error) {
        button.innerHTML = original;
        window.alert(error.message || cfg.errorText || 'Could not add this item.');
      } finally {
        control.classList.remove('is-busy');
      }
    });
  }

  function initQuantityControls() {
    if (!cfg.wooActive) return;
    document.addEventListener('click', async (event) => {
      const inlineButton = event.target.closest('.momizza-inline-qty__btn');
      if (inlineButton) {
        event.preventDefault();
        const control = inlineButton.closest('.momizza-purchase-control');
        if (!control || control.classList.contains('is-busy')) return;
        const cartKey = control.dataset.cartKey || '';
        const current = parseInt(control.dataset.quantity || '0', 10);
        const delta = parseInt(inlineButton.dataset.delta || '0', 10);
        if (!cartKey || !delta) return;
        control.classList.add('is-busy');
        try {
          const state = await postAjax('momizza_update_cart_item', {
            cart_key: cartKey,
            quantity: Math.max(0, current + delta)
          });
          applyCartState(state);
        } catch (error) {
          window.alert(error.message || 'Could not update the quantity.');
          refreshCartState();
        } finally {
          control.classList.remove('is-busy');
        }
        return;
      }

      const cartButton = event.target.closest('.momizza-cart-qty__btn');
      if (cartButton) {
        event.preventDefault();
        const control = cartButton.closest('.momizza-cart-qty');
        if (!control || control.classList.contains('is-busy')) return;
        const current = parseInt(control.dataset.quantity || '0', 10);
        const delta = parseInt(cartButton.dataset.delta || '0', 10);
        control.classList.add('is-busy');
        try {
          const state = await postAjax('momizza_update_cart_item', {
            cart_key: control.dataset.cartKey || '',
            quantity: Math.max(0, current + delta)
          });
          applyCartState(state);
        } catch (error) {
          window.alert(error.message || 'Could not update the quantity.');
          refreshCartState();
        }
        return;
      }

      const remove = event.target.closest('.momizza-cart-remove');
      if (remove) {
        event.preventDefault();
        if (remove.classList.contains('is-busy')) return;
        remove.classList.add('is-busy');
        try {
          const state = await postAjax('momizza_update_cart_item', {
            cart_key: remove.dataset.cartKey || '',
            quantity: 0
          });
          applyCartState(state);
        } catch (error) {
          window.alert(error.message || 'Could not remove this item.');
          refreshCartState();
        }
      }
    });
  }

  async function refreshCartState() {
    if (!cfg.wooActive) return;
    try {
      const state = await postAjax('momizza_cart_state', {});
      applyCartState(state);
    } catch (e) {
      // WooCommerce's native fragments can still update basic count/total UI.
    }
  }

  function hookWooEvents() {
    if (!$ || !cfg.wooActive) return;
    $(document.body).on('added_to_cart removed_from_cart wc_fragments_refreshed updated_wc_div', function () {
      refreshCartState();
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initMobileNav();
    initCategoryScroll();
    initCartDrawer();
    initMenuAddToCart();
    initQuantityControls();
    hookWooEvents();
    refreshCartState();
  });
})(window.jQuery);
