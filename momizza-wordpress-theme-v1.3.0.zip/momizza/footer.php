<?php
/** Footer */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<?php $momizza_elementor_footer = function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( 'footer' ); ?>
<?php if ( ! $momizza_elementor_footer ) : ?>
<footer class="momizza-footer">
    <div class="momizza-container momizza-footer__grid">
        <div class="momizza-footer__brand">
            <a class="momizza-footer__logo-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( momizza_opt( 'brand_name' ) ); ?> home">
                <img class="momizza-footer__logo" src="<?php echo esc_url( momizza_logo_url() ); ?>" alt="<?php echo esc_attr( momizza_opt( 'brand_name' ) ); ?>" width="72" height="72" loading="lazy">
            </a>
            <p><?php echo esc_html( momizza_opt( 'tagline' ) ); ?></p>
        </div>

        <div class="momizza-footer__nav-col">
            <h3>Explore</h3>
            <?php
            if ( has_nav_menu( 'footer' ) ) {
                wp_nav_menu(
                    array(
                        'theme_location' => 'footer',
                        'container'      => false,
                        'menu_class'     => 'momizza-footer-nav',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    )
                );
            } else {
                ?>
                <ul class="momizza-footer-nav">
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/menu/' ) ); ?>">Menu</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">Our Story</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Visit</a></li>
                </ul>
                <?php
            }
            ?>
        </div>

        <div>
            <h3>Find us</h3>
            <address><?php echo esc_html( momizza_opt( 'address' ) ); ?></address>
            <p><?php echo esc_html( momizza_opt( 'hours_short' ) ); ?></p>
            <a href="<?php echo esc_url( momizza_opt( 'map_url' ) ); ?>" target="_blank" rel="noopener">View on Google Maps</a>
        </div>

        <div>
            <h3>Order</h3>
            <a class="momizza-footer__phone" href="<?php echo esc_url( momizza_phone_href() ); ?>"><?php echo esc_html( momizza_opt( 'phone' ) ); ?></a>
            <a href="<?php echo esc_url( momizza_menu_pdf_url() ); ?>" download>Download menu PDF</a>
            <?php if ( momizza_opt( 'facebook_url' ) || momizza_opt( 'instagram_url' ) ) : ?>
                <div class="momizza-socials" aria-label="Momizza social media">
                    <?php if ( momizza_opt( 'facebook_url' ) ) : ?>
                        <a class="momizza-social-link" href="<?php echo esc_url( momizza_opt( 'facebook_url' ) ); ?>" target="_blank" rel="noopener" aria-label="Facebook" title="Facebook"><?php echo momizza_svg_icon( 'facebook', 'momizza-social-icon' ); ?></a>
                    <?php endif; ?>
                    <?php if ( momizza_opt( 'instagram_url' ) ) : ?>
                        <a class="momizza-social-link" href="<?php echo esc_url( momizza_opt( 'instagram_url' ) ); ?>" target="_blank" rel="noopener" aria-label="Instagram" title="Instagram"><?php echo momizza_svg_icon( 'instagram', 'momizza-social-icon' ); ?></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <p class="momizza-footer__bottom">© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( momizza_opt( 'brand_name' ) ); ?> · <?php echo esc_html( momizza_opt( 'location_label' ) ); ?></p>
</footer>
<?php endif; ?>
<?php
if ( class_exists( 'WooCommerce' ) && ! is_cart() && ! is_checkout() ) {
    get_template_part( 'template-parts/cart', 'drawer' );
}
wp_footer();
?>
</body>
</html>
