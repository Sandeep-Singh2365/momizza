<?php
/** Header */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php $momizza_elementor_header = function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( 'header' ); ?>
<?php if ( ! $momizza_elementor_header ) : ?>
<header class="momizza-header" data-momizza-header>
    <div class="momizza-container momizza-header__inner">
        <a class="momizza-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( momizza_opt( 'brand_name' ) ); ?> home">
            <img src="<?php echo esc_url( momizza_logo_url() ); ?>" alt="<?php echo esc_attr( momizza_opt( 'brand_name' ) ); ?> logo" width="48" height="48">
            <span class="momizza-brand__location"><?php echo esc_html( momizza_opt( 'header_brand_text', 'MOMIZZA' ) ); ?></span>
        </a>

        <nav class="momizza-nav momizza-nav--desktop" aria-label="Primary navigation">
            <?php
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu(
                    array(
                        'theme_location' => 'primary',
                        'container'      => false,
                        'menu_class'     => 'momizza-nav__list',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    )
                );
            } else {
                ?>
                <ul class="momizza-nav__list">
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/menu/' ) ); ?>">Menu</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">Our Story</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Visit</a></li>
                </ul>
                <?php
            }
            ?>
        </nav>

        <div class="momizza-header__actions">
            <a class="momizza-btn momizza-btn--ghost momizza-header__pdf" href="<?php echo esc_url( momizza_menu_pdf_url() ); ?>" download>
                <?php echo momizza_svg_icon( 'download', 'momizza-icon' ); ?>
                <span>PDF Menu</span>
            </a>
            <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                <button class="momizza-cart-trigger momizza-header-cart" type="button" aria-label="Open cart">
                    <?php echo momizza_svg_icon( 'bag', 'momizza-icon' ); ?>
                    <span class="momizza-cart-count"><?php echo esc_html( WC()->cart ? WC()->cart->get_cart_contents_count() : 0 ); ?></span>
                </button>
            <?php endif; ?>
            <a class="momizza-btn momizza-btn--primary momizza-header__order" href="<?php echo esc_url( momizza_phone_href() ); ?>">
                <?php echo momizza_svg_icon( 'phone', 'momizza-icon' ); ?>
                <span>Order</span>
            </a>
            <button class="momizza-menu-toggle" type="button" aria-controls="momizza-mobile-nav" aria-expanded="false" aria-label="Toggle menu">
                <span class="momizza-menu-toggle__open"><?php echo momizza_svg_icon( 'menu', 'momizza-icon' ); ?></span>
                <span class="momizza-menu-toggle__close"><?php echo momizza_svg_icon( 'x', 'momizza-icon' ); ?></span>
            </button>
        </div>
    </div>

    <nav id="momizza-mobile-nav" class="momizza-nav momizza-nav--mobile" aria-label="Mobile navigation" hidden>
        <div class="momizza-container">
            <?php
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu(
                    array(
                        'theme_location' => 'primary',
                        'container'      => false,
                        'menu_class'     => 'momizza-mobile-list',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    )
                );
            } else {
                ?>
                <ul class="momizza-mobile-list">
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/menu/' ) ); ?>">Menu</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">Our Story</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Visit</a></li>
                </ul>
                <?php
            }
            ?>
            <div class="momizza-mobile-actions">
                <a class="momizza-btn momizza-btn--ghost" href="<?php echo esc_url( momizza_menu_pdf_url() ); ?>" download><?php echo esc_html( momizza_opt( 'menu_pdf_label' ) ); ?></a>
                <a class="momizza-btn momizza-btn--primary" href="<?php echo esc_url( momizza_phone_href() ); ?>">Call to order</a>
            </div>
        </div>
    </nav>
</header>
<?php endif; ?>
